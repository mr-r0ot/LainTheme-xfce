# LAINTheme

Independent XFCE/X11 desktop experience layer. It installs its own theme assets, a floating GTK shell, Plank dock, custom notification service, PAM-backed i3lock screen, terminal profile, keybindings, system controls, workspace HUD, window actions, and two profiles.

## Install

`./laintheme_install.sh --lite` uses XFWM native compositing and avoids picom.

`./laintheme_install.sh --high` uses picom with GLX, dual-kawase blur, rounded corners, shadows, opacity and current animation rules. On systems whose packaged picom is older than the required animation feature set, the installer can build official picom v13 locally.

The official picom v12 release introduced animation support, and v13 is the current stable release as of this project build. Background blur is known to be GPU/driver dependent and can be expensive.

The lock path uses i3lock/PAM rather than a custom password-capturing GTK form. In High, the lock background is a locally captured, blurred screenshot; in Lite it uses a local static lock background.

## CLI

`laintheme status`
`laintheme diagnose`
`laintheme repair`
`laintheme appearance status|dark|light`
`laintheme shell start|stop|restart`
`laintheme notify start|stop`
`laintheme compositor start|stop|restart`
`laintheme launcher`
`laintheme power`
`laintheme lock`
`laintheme screenshot`
`laintheme record`
`laintheme terminal`

`lainconfig` is an alias for `laintheme` inside the supplied zsh profiles.

## Keybindings

Super+Space launcher; Super+Enter terminal; Super+E files; Super+W close; Super+Up maximize; Super+Down minimize; Super+Left/Right snap; Super+Shift+C center; Super+Shift+F fullscreen; Super+Shift+A always-on-top; Super+1..9 workspaces; Super+Shift+R screenshot; Super+Shift+G recording; Super+Shift+L lock; Super+Shift+P power.

## Safety / reversibility

The installer backs up the XFCE panel XML before replacing the visual shell and keeps everything under user-local paths except normal APT packages. `--uninstall` restores the backed-up XFCE panel XML when present and removes LAINTheme user integration. No script contains destructive filesystem operations outside the user's own configuration tree or the explicitly installed APT packages.

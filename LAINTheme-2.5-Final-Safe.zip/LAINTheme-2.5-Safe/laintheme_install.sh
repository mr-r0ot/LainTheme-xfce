#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
MODE=""; DRY=0
HOME_DIR="$HOME"; SHARE="$HOME_DIR/.local/share/laintheme"; BIN="$HOME_DIR/.local/bin"; STATE="$HOME_DIR/.local/state/laintheme"; CACHE="$HOME_DIR/.cache/laintheme"
STAMP=$(date +%Y%m%d-%H%M%S); BACKUP="$STATE/backups/$STAMP"
STEP_NO=0
STEP_TOTAL=11
log(){ printf '[%s] %s\n' "$1" "${*:2}"; }
step(){ STEP_NO=$((STEP_NO+1)); printf '\n[%02d/%02d] %s\n' "$STEP_NO" "$STEP_TOTAL" "$*"; }
done_step(){ printf '[DONE] %s\n' "$*"; }
substep(){ printf '  -> %s\n' "$*"; }
run_step(){ local label="$1"; shift; step "$label"; "$@"; done_step "$label"; }
die(){ log FAIL "$*" >&2; exit 1; }
usage(){ cat <<EOF
LAINTheme 2.5 Safe
  $0 --lite
  $0 --high
  $0 --lite --dry-run
EOF
}
priv(){
  if [[ $EUID -eq 0 ]]; then "$@"; return; fi
  if command -v sudo >/dev/null; then sudo "$@"; return; fi
  if command -v pkexec >/dev/null; then pkexec "$@"; return; fi
  return 127
}
while (($#)); do case "$1" in --lite) MODE=lite;; --high) MODE=high;; --dry-run) DRY=1;; -h|--help) usage; exit 0;; *) die "Unknown option: $1";; esac; shift; done
[[ -n "$MODE" ]] || { usage; exit 2; }
command -v apt-get >/dev/null || die 'apt-get is required on Debian/Ubuntu/Mint.'
if ((DRY)); then
  printf '[00/11] DRY RUN — no files, packages or session settings will be changed.\n'
  printf 'MODE=%s\n' "$MODE"
  exit 0
fi
[[ -n "${DISPLAY:-}" ]] || die 'Run inside the active XFCE X11 session.'
[[ "${XDG_CURRENT_DESKTOP:-}" =~ [Xx][Ff][Cc][Ee] ]] || die 'XFCE session required.'

PKGS=(python3 python3-gi python3-dbus gir1.2-gtk-3.0 dbus-x11 xfconf xfce4-panel xfce4-terminal xfdesktop4 thunar wmctrl xdotool x11-utils x11-xserver-utils network-manager bluez rfkill pulseaudio-utils ffmpeg imagemagick zsh git zsh-autosuggestions zsh-syntax-highlighting fonts-jetbrains-mono i3lock papirus-icon-theme chafa upower brightnessctl scrot)
[[ "$MODE" == high ]] && PKGS+=(picom)
if ((DRY)); then printf 'mode=%s\n' "$MODE"; printf 'package=%s\n' "${PKGS[@]}"; exit 0; fi

step "Preparing backup and state directories"
substep "Creating backup/state directories"
mkdir -p "$STATE" "$BACKUP" "$BIN" "$CACHE" "$HOME_DIR/.config/autostart"
ln -sfn "$BACKUP" "$STATE/current-backup"
backup_file(){ local f="$1"; [[ -e "$f" ]] || return 0; mkdir -p "$BACKUP/$(dirname "${f#$HOME_DIR/}")"; cp -a "$f" "$BACKUP/${f#$HOME_DIR/}"; }
for f in \
  "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml" \
  "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml" \
  "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml" \
  "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-keyboard-shortcuts.xml" \
  "$HOME_DIR/.zshrc" \
  "$HOME_DIR/.profile" \
  "$HOME_DIR/.themes/LAINTheme-Dark" \
  "$HOME_DIR/.config/autostart/xfce4-panel.desktop" \
  "$HOME_DIR/.config/autostart/xfce4-notifyd.desktop"; do backup_file "$f"; done
done_step "Backup and state"

step "Checking installed dependencies"
substep "Checking installed packages"
missing=()
for p in "${PKGS[@]}"; do
  dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q 'install ok installed' || missing+=("$p")
done
if ((${#missing[@]})); then
  substep "Missing: ${missing[*]}"
  log INFO "Installing missing packages in one transaction; apt update runs only because packages are missing."
  priv env DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::Retries=1 -o Acquire::http::Timeout=12 -o Acquire::https::Timeout=12 update
  priv env DEBIAN_FRONTEND=noninteractive apt-get -o Dpkg::Use-Pty=0 -o Acquire::Retries=1 -y --no-install-recommends install "${missing[@]}"
  done_step "System packages"
else
  step "System packages"; log OK "All required packages already installed; skipping apt update."; done_step "System packages"
fi
for c in python3 xfconf-query xdotool wmctrl xprop xrandr nmcli bluetoothctl pactl ffmpeg i3lock zsh git chafa; do command -v "$c" >/dev/null || die "Missing required command after dependency install: $c"; done
done_step "Dependency check"

step "Stopping only known previous LAINTheme components"
# Stop components from previous LAINTheme releases without broad pattern matching.
pkill -u "$USER" -x lain-shell 2>/dev/null || true
pkill -u "$USER" -x lain-notifyd 2>/dev/null || true
pkill -u "$USER" -x lain-theme-settings 2>/dev/null || true
# Stop only components owned by LAINTheme. The stock XFCE panel is quit once for this session; no persistent killer is installed.
pkill -u "$USER" -x picom 2>/dev/null || true
xfce4-panel --quit >/dev/null 2>&1 || true

# Remove only known conflicting user autostarts from older LAINTheme/Step2 profiles. Each file is backed up first.
for f in "$HOME_DIR/.config/autostart/"*.desktop; do
  [[ -f "$f" ]] || continue
  if grep -Eiq 'LAINTheme|lain-shell|lain-notifyd|xfce4-panel|(^|[=/[:space:]])(picom|compton)([[:space:]]|$)' "$f"; then
    backup_file "$f"; rm -f "$f"
  fi
done

# Disable every user-level panel launch and all old LAINTheme panel guards.
for f in "$HOME_DIR/.config/autostart/lain-panel-suppress.desktop" "$HOME_DIR/.config/autostart/laintheme-shell.desktop" "$HOME_DIR/.config/autostart/laintheme-notify.desktop" "$HOME_DIR/.config/autostart/xfce4-panel.desktop"; do [[ -e "$f" ]] && backup_file "$f" && rm -f "$f"; done
cat > "$HOME_DIR/.config/autostart/xfce4-panel.desktop" <<'EOF'
[Desktop Entry]
Hidden=true
EOF

# Disable stock notification daemon at user level; keep a backup for uninstall.
cat > "$HOME_DIR/.config/autostart/xfce4-notifyd.desktop" <<'EOF'
[Desktop Entry]
Hidden=true
EOF
pkill -u "$USER" -x xfce4-notifyd 2>/dev/null || true

done_step "Previous-instance cleanup"
step "Installing LAINTheme runtime and theme files"
# Install theme and runtime files atomically.
rm -rf "$HOME_DIR/.themes/LAINTheme-Dark.tmp" "$SHARE.tmp"
mkdir -p "$HOME_DIR/.themes" "$SHARE.tmp"
cp -a "$ROOT/theme/LAINTheme-Dark" "$HOME_DIR/.themes/LAINTheme-Dark.tmp"
rm -rf "$HOME_DIR/.themes/LAINTheme-Dark"; mv "$HOME_DIR/.themes/LAINTheme-Dark.tmp" "$HOME_DIR/.themes/LAINTheme-Dark"
rm -rf "$SHARE"; mv "$SHARE.tmp" "$SHARE"
cp -a "$ROOT/assets" "$SHARE/assets"
cp -a "$ROOT/zsh" "$SHARE/zsh"
cp -f "$ROOT/theme.css" "$SHARE/theme.css"
cp -f "$ROOT/config/picom-high.conf" "$SHARE/picom-high.conf"
for f in "$ROOT/bin/"*; do cp -f "$f" "$BIN/$(basename "$f")"; chmod +x "$BIN/$(basename "$f")"; done
substep "Installed shell, dock, launcher, lock, capture and window-management commands."
printf '%s\n' "$MODE" > "$SHARE/profile"

done_step "Runtime and theme files"
step "Applying XFCE appearance, wallpaper and work-area"
# XFCE appearance and safe work-area margins. Xfwm supports top/bottom margins as screen struts.
xfconf-query -c xsettings -p /Net/ThemeName -n -t string -s LAINTheme-Dark 2>/dev/null || xfconf-query -c xsettings -p /Net/ThemeName -s LAINTheme-Dark || true
xfconf-query -c xsettings -p /Net/FontName -n -t string -s 'JetBrains Mono 10' 2>/dev/null || true
[[ -d /usr/share/icons/Papirus-Dark ]] && xfconf-query -c xsettings -p /Net/IconThemeName -n -t string -s Papirus-Dark 2>/dev/null || true
WALL="$SHARE/assets/lain-wallpaper.png"; ANIME="$SHARE/assets/anime-terminal.png"
if [[ -f "$WALL" ]]; then
  # Apply the wallpaper to every existing XFCE monitor profile, not only monitor0.
  mapfile -t DESKTOP_PROPS < <(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep -E '/backdrop/.*/image-path$' || true)
  if ((${#DESKTOP_PROPS[@]})); then
    for prop in "${DESKTOP_PROPS[@]}"; do
      xfconf-query -c xfce4-desktop -p "$prop" -s "$WALL" 2>/dev/null || true
      style_prop="${prop%/image-path}/image-style"
      xfconf-query -c xfce4-desktop -p "$style_prop" -n -t int -s 5 2>/dev/null || true
    done
  else
    xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/image-path -n -t string -s "$WALL" 2>/dev/null || true
    xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/image-style -n -t int -s 5 2>/dev/null || true
  fi
  xfdesktop --reload >/dev/null 2>&1 || true
fi
# Xfce Terminal uses background-mode, background-image-file and background-image-style; keep the image dark instead of transparent.
xfconf-query -c xfce4-terminal -p /font-name -n -t string -s 'JetBrains Mono 10' 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /font-use-system -n -t bool -s false 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /background-mode -n -t enum -s TERMINAL_BACKGROUND_IMAGE 2>/dev/null || xfconf-query -c xfce4-terminal -p /background-mode -n -t uint -s 1 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /background-image-file -n -t string -s "$ANIME" 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /background-image-style -n -t enum -s TERMINAL_BACKGROUND_STYLE_SCALED 2>/dev/null || xfconf-query -c xfce4-terminal -p /background-image-style -n -t uint -s 2 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /background-darkness -n -t double -s 0.72 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /background-image-shading -n -t double -s 0.78 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /color-use-theme -n -t bool -s false 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /color-foreground -n -t string -s '#f4efff' 2>/dev/null || true
xfconf-query -c xfce4-terminal -p /color-background -n -t string -s '#080c18' 2>/dev/null || true

# Xfwm integration.
xfconf-query -c xfwm4 -p /general/margin_top -n -t int -s 43 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/margin_bottom -n -t int -s 72 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/snap_to_windows -n -t bool -s true 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/snap_to_border -n -t bool -s true 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/snap_resist -n -t bool -s true 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/snap_width -n -t int -s 10 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/tile_on_move -n -t bool -s true 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/wrap_workspaces -n -t bool -s false 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/workspace_count -n -t int -s 9 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true 2>/dev/null || true

done_step "Appearance and wallpaper"
step "Installing keyboard shortcuts and removing conflicts"
# Remove old XFCE application-menu bindings that stole the old launcher key and use Super+Z exclusively.
while read -r path val; do
  [[ "$path" == /commands/custom/* ]] || continue
  if [[ "$val" == *xfce4-popup-* || "$val" == *xfce4-appfinder* || "$val" == *xfrun4* || "$val" == *xfce4-popup-applicationsmenu* ]]; then
    xfconf-query -c xfce4-keyboard-shortcuts -p "$path" -r 2>/dev/null || true
  fi
done < <(xfconf-query -c xfce4-keyboard-shortcuts -l -v 2>/dev/null || true)
setkey(){ xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/$1" -n -t string -s "$2" 2>/dev/null || xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/$1" -s "$2" 2>/dev/null || true; }
# Remove previous LAINTheme launcher bindings, then use Super+Z.
for key in '<Alt>F1' '<Alt>F2' '<Alt>F3' '<Super>r' '<Super>space' '<Super>p'; do
  xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/$key" -r 2>/dev/null || true
done
xfconf-query -c xfce4-keyboard-shortcuts -p '/commands/custom/<Super>space' -r 2>/dev/null || true
setkey '<Super>z' "$BIN/lain-shell --launcher"
xfconf-query -c xfce4-keyboard-shortcuts -p '/commands/custom/<Super>space' -r 2>/dev/null || true
setkey '<Super>Return' "$BIN/lain-terminal"
setkey '<Super>e' 'thunar'
setkey '<Super>w' "$BIN/lain-window close"
setkey '<Super>Up' "$BIN/lain-window maximize"
setkey '<Super>Down' "$BIN/lain-window minimize"
setkey '<Super>Left' "$BIN/lain-window snap-left"
setkey '<Super>Right' "$BIN/lain-window snap-right"
setkey '<Super><Shift>r' "$BIN/lain-capture screenshot"
setkey '<Super><Shift>g' "$BIN/lain-capture record"
setkey '<Super><Shift>n' "$BIN/lain-shell --notify"
setkey '<Super><Shift>c' "$BIN/lain-shell --control"
setkey '<Super><Shift>p' "$BIN/lain-shell --power"
setkey '<Super><Shift>l' "$BIN/lain-lock"
setkey '<Control><Alt>l' "$BIN/lain-lock"
setkey '<Super>m' "$BIN/lain-window next-monitor"
setkey '<Super>t' "$BIN/lain-window tile-grid"
for n in {1..9}; do setkey "<Super>$n" "$BIN/lain-window workspace $n"; done

done_step "Keyboard shortcuts"
step "Installing autostart entries"

# System lock integration: route XFCE's common lock shortcut to the real LAINTheme locker.
cat > "$BIN/xflock4" <<EOF
#!/usr/bin/env bash
exec "$BIN/lain-lock"
EOF
chmod +x "$BIN/xflock4"
xfconf-query -c xfce4-session -p /general/LockCommand -n -t string -s "$BIN/lain-lock" 2>/dev/null || true
for f in light-locker light-locker-command; do pkill -u "$USER" -x "$f" 2>/dev/null || true; done
# Keep the override user-local: no /usr/bin replacement and no system file modification.
PROFILE_FILE="$HOME_DIR/.profile"
touch "$PROFILE_FILE"
if ! grep -Fq 'export PATH="$HOME/.local/bin:$PATH"' "$PROFILE_FILE"; then
  printf '\n# LAINTheme user-local command path\nexport PATH="$HOME/.local/bin:$PATH"\n' >> "$PROFILE_FILE"
fi

# Autostart only our shell and notification server.
cat > "$HOME_DIR/.config/autostart/laintheme-shell.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=LAINTheme Shell
Exec=$BIN/lain-shell --start
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF
cat > "$HOME_DIR/.config/autostart/laintheme-notify.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=LAINTheme Notifications
Exec=$BIN/lain-notifyd
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF

done_step "Autostart"
step "Configuring Lite/High compositor"
# High compositor config and safe fallback.
mkdir -p "$HOME_DIR/.config/picom"
if [[ "$MODE" == high ]]; then
  cp -f "$ROOT/config/picom-high.conf" "$HOME_DIR/.config/picom/laintheme.conf"
else
  rm -f "$HOME_DIR/.config/picom/laintheme.conf"
  pkill -u "$USER" -x picom 2>/dev/null || true
  pkill -u "$USER" -x compton 2>/dev/null || true
fi

done_step "Compositor"
step "Configuring Zsh and terminal"
# Oh My Zsh: install the real upstream tree when network is available; otherwise retain a fully functional native Zsh prompt and system plugins.
mkdir -p "$SHARE/zsh"
backup_file "$HOME_DIR/.zshrc"
if [[ -f "$HOME_DIR/.zshrc" ]]; then cp -a "$HOME_DIR/.zshrc" "$BACKUP/.zshrc.original"; fi
if [[ -d "$HOME_DIR/.oh-my-zsh" && -f "$HOME_DIR/.oh-my-zsh/oh-my-zsh.sh" ]]; then
  :
elif command -v git >/dev/null && timeout 2s git -c connect.timeout=1 ls-remote https://github.com/ohmyzsh/ohmyzsh.git HEAD >/dev/null 2>&1; then
  rm -rf "$HOME_DIR/.oh-my-zsh.tmp"; timeout 10s git -c http.lowSpeedLimit=1000 -c http.lowSpeedTime=3 clone --depth=1 --filter=blob:none https://github.com/ohmyzsh/ohmyzsh.git "$HOME_DIR/.oh-my-zsh.tmp"; rm -rf "$HOME_DIR/.oh-my-zsh"; mv "$HOME_DIR/.oh-my-zsh.tmp" "$HOME_DIR/.oh-my-zsh"
fi
if [[ -d "$HOME_DIR/.oh-my-zsh" ]]; then mkdir -p "$HOME_DIR/.oh-my-zsh/custom/themes"; cp -f "$ROOT/zsh/ohmyzsh/custom/themes/lain.zsh-theme" "$HOME_DIR/.oh-my-zsh/custom/themes/lain.zsh-theme"; fi
cp -f "$ROOT/zsh/.zshrc" "$HOME_DIR/.zshrc"
chsh -s "$(command -v zsh)" "$USER" 2>/dev/null || true

done_step "Zsh and terminal"
step "Running syntax and safety validation"
# Static validation before runtime start.
for f in "$BIN/lain-capture" "$BIN/lain-lock" "$BIN/lain-terminal" "$BIN/lainconfig" "$BIN/lain-theme-settings" "$BIN/lain-window"; do bash -n "$f"; done
python3 -m py_compile "$BIN/lain-shell" "$BIN/lain-notifyd" "$BIN/lain-window" "$BIN/lain-theme-settings"
rm -rf "$BIN/__pycache__"
bash -n "$ROOT/laintheme_install.sh"
zsh -n "$ROOT/zsh/.zshrc" "$ROOT/zsh/.zshrc-high" || true

done_step "Validation"
step "Starting LAINTheme runtime"
# Runtime processes. Never fail the install if a compositor or graphical shell cannot start in this build environment.
xfce4-panel --quit >/dev/null 2>&1 || true
# do not kill any unknown panel/dock processes here
pkill -u "$USER" -x lain-shell 2>/dev/null || true
pkill -u "$USER" -x lain-notifyd 2>/dev/null || true
"$BIN/lain-notifyd" >/dev/null 2>&1 &
if [[ "$MODE" == high ]]; then "$BIN/lain-compositor" start >/dev/null 2>&1 || true; else "$BIN/lain-compositor" stop >/dev/null 2>&1 || true; fi
"$BIN/lain-shell" --start >/dev/null 2>&1 &
done_step "Runtime start"
log OK "LAINTheme 2.4 installed: $MODE"
log OK "Backup: $BACKUP"

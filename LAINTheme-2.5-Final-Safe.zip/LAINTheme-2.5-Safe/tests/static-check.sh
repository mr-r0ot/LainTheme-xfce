#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
for f in "$ROOT/laintheme_install.sh" "$ROOT/bin/lain-compositor" "$ROOT/bin/lain-repair" "$ROOT/bin/lain-uninstall" "$ROOT/bin/laintheme" "$ROOT/bin/lain-capture" "$ROOT/bin/lain-lock" "$ROOT/bin/lain-terminal" "$ROOT/bin/lainconfig" "$ROOT/bin/lain-fetch"; do bash -n "$f"; done
python3 -m py_compile "$ROOT/bin/lain-shell" "$ROOT/bin/lain-notifyd" "$ROOT/bin/lain-window" "$ROOT/bin/lain-wifi" "$ROOT/bin/lain-theme-settings"
rm -rf "$ROOT/bin/__pycache__"
! grep -R --line-number -E 'WhiteSur|vinceliuice' "$ROOT/bin" "$ROOT/laintheme_install.sh" "$ROOT/theme.css" >/dev/null
! grep -R --line-number -E 'xfce4-panel --restart|xfce4-panel -r|pkill .*xfce4-panel' "$ROOT/bin" "$ROOT/laintheme_install.sh" >/dev/null
grep -q "in_signature='susssasa{sv}i'" "$ROOT/bin/lain-notifyd"
grep -q '_NET_WM_STRUT_PARTIAL' "$ROOT/bin/lain-shell"
printf 'STATIC CHECK PASS\n'

grep -q "workspace-switcher" "$ROOT/bin/lain-shell"

grep -q "<Super>z" "$ROOT/laintheme_install.sh"

grep -q "LockCommand" "$ROOT/laintheme_install.sh"

# Top-panel requirements
grep -q "class StatusCluster" "$ROOT/bin/lain-shell"
grep -q "class NotificationButton" "$ROOT/bin/lain-shell"
grep -q "_NET_WM_STRUT_PARTIAL" "$ROOT/bin/lain-shell"
grep -q "<Super>z" "$ROOT/laintheme_install.sh"
! grep -n "setkey '<Super>space'" "$ROOT/laintheme_install.sh" >/dev/null
grep -q 'LockCommand' "$ROOT/laintheme_install.sh"
grep -q 'lain-wallpaper.png' "$ROOT/laintheme_install.sh"

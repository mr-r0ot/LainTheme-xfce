# LAINTheme 2.5 Safe

XFCE/X11 desktop shell for Debian/Ubuntu/Linux Mint.

## Modes

- `--lite`: XFWM compositor only; no external picom runtime.
- `--high`: optional picom compositor with fallback to XFWM4.

## Installation

```bash
chmod +x laintheme_install.sh
./laintheme_install.sh --lite
# or
./laintheme_install.sh --high
```

Every installation stage prints a numbered status line and `[DONE]` marker. Missing packages are installed in one apt transaction; `apt update` is skipped when all required packages are already installed. `--dry-run` performs no system changes.

## Main shell

Top panel is a thin dock-style bar at the top of the primary monitor and reserves work area using `_NET_WM_STRUT_PARTIAL`. It includes distro icon, Application Manager, workspace switcher, CPU/RAM/disk HUD, centered clock/date, unified Wi-Fi/Bluetooth/battery status, Notification Center, Control Center and Power.

Launcher shortcut: **Super+Z**. `Super+Space` is removed to prevent the old XFCE application menu collision.

Bottom taskbar/dock shows pinned applications and open windows, supports reordering, pinning from the launcher, right-click removal/close, and auto-hide while the active window is maximized/fullscreen.

## Locking

`lain-lock` is configured as XFCE's session lock command and uses `i3lock` with PAM authentication. The visual background is captured and blurred when ImageMagick screenshot support is available, otherwise the bundled LAINTheme wallpaper is used.

## Safety / rollback

User XFCE configuration files and known previous LAINTheme/Step2 autostarts are backed up before modification. No `/etc` files are overwritten. No permanent process-killer guard is installed.

## Runtime limitation

Static syntax, compilation and regression checks are performed by the release build. Actual GTK/X11 rendering still depends on the target machine's XFCE session, GPU/driver and installed desktop services.

#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
HOME_DIR="$HOME"; SHARE="$HOME_DIR/.local/share/laintheme"; BIN="$HOME_DIR/.local/bin"; STATE="$HOME_DIR/.local/state/laintheme"; BACKUP="$STATE/backups/$(date +%Y%m%d-%H%M%S)"; MODE=''; DRY=0
log(){ printf '[%s] %s\n' "$1" "${*:2}"; }; die(){ log FAIL "$*" >&2; exit 1; }
usage(){ cat <<EOF
LAINTheme 2.1.0
./laintheme_install.sh --lite | --high [--dry-run]
Native XFCE theme. Lite never starts picom.
EOF
}
priv(){ if [[ $EUID -eq 0 ]]; then "$@"; elif command -v sudo >/dev/null; then sudo "$@"; elif command -v pkexec >/dev/null; then pkexec "$@"; else return 127; fi; }
while (($#)); do case "$1" in --lite) MODE=lite;; --high) MODE=high;; --dry-run) DRY=1;; --help|-h) usage; exit 0;; *) die "unknown option: $1";; esac; shift; done
[[ $MODE ]] || { usage; exit 2; }
[[ "${XDG_CURRENT_DESKTOP:-XFCE}" =~ [Xx][Ff][Cc][Ee] ]] || die 'XFCE session required.'
[[ -n "${DISPLAY:-}" ]] || die 'Run from an active graphical session.'
command -v apt-get >/dev/null || die 'apt-get required on Debian/Ubuntu/Mint.'
PKGS=(python3 python3-gi python3-dbus gir1.2-gtk-3.0 dbus-x11 xfconf xfce4-panel xfce4-terminal xfdesktop4 thunar wmctrl xdotool x11-utils network-manager bluez rfkill pulseaudio-utils ffmpeg imagemagick zsh git zsh-autosuggestions zsh-syntax-highlighting fonts-jetbrains-mono i3lock papirus-icon-theme chafa upower brightnessctl)
[[ $MODE == high ]] && PKGS+=(picom)
if ((DRY)); then printf '%s\n' "mode=$MODE" "packages=${PKGS[*]}"; exit 0; fi
mkdir -p "$STATE" "$BACKUP" "$BIN" "$HOME_DIR/.config/autostart"; ln -sfn "$BACKUP" "$STATE/current-backup"
missing=(); for p in "${PKGS[@]}"; do dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q 'install ok installed' || missing+=("$p"); done
if ((${#missing[@]})); then priv apt-get update; priv apt-get install -y "${missing[@]}"; fi
for c in python3 xfconf-query xdotool wmctrl xprop xwininfo; do command -v "$c" >/dev/null || die "Missing command: $c"; done
mkdir -p "$SHARE/backup" "$HOME_DIR/.themes" "$HOME_DIR/.local/share/icons" "$HOME_DIR/.cache/laintheme"
# Stop old LAINTheme instances and old XFCE panel before replacing them.
pkill -u "$USER" -f "$HOME_DIR/.local/bin/lain-shell" 2>/dev/null || true
pkill -u "$USER" -f "$HOME_DIR/.local/bin/lain-notifyd" 2>/dev/null || true
xfce4-panel --quit >/dev/null 2>&1 || true
# Back up user-owned files that this installer changes.
for f in "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml" "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml" "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-keyboard-shortcuts.xml" "$HOME_DIR/.zshrc"; do [[ -f "$f" ]] && cp -a "$f" "$BACKUP/$(basename "$f")"; done
# Disable previous LAINTheme/Step2 autostarts safely, keeping backup copies.
for f in "$HOME_DIR/.config/autostart/"*.desktop; do
  [[ -f "$f" ]] || continue
  if grep -Eiq 'LAINTheme|lain-shell|lain-notifyd|(^|[=(])picom([[:space:]]|$)|compton|xfce4-panel' "$f"; then cp -a "$f" "$BACKUP/$(basename "$f").old"; rm -f "$f"; fi
done
# Native theme files.
rm -rf "$HOME_DIR/.themes/LAINTheme-Dark"; cp -a "$ROOT/theme/LAINTheme-Dark" "$HOME_DIR/.themes/LAINTheme-Dark"
rm -rf "$SHARE/assets"; cp -a "$ROOT/assets" "$SHARE/assets"; cp -f "$ROOT/theme.css" "$SHARE/theme.css"; cp -f "$ROOT/config/picom-high.conf" "$SHARE/picom-high.conf"; cp -a "$ROOT/zsh" "$SHARE/zsh"
for f in "$ROOT/bin/"*; do cp -f "$f" "$BIN/"; chmod +x "$BIN/$(basename "$f")"; done
printf '%s\n' "$MODE" > "$SHARE/profile"
# XFCE appearance.
xfconf-query -c xsettings -p /Net/ThemeName -n -t string -s LAINTheme-Dark 2>/dev/null || xfconf-query -c xsettings -p /Net/ThemeName -s LAINTheme-Dark || true
xfconf-query -c xsettings -p /Net/FontName -n -t string -s 'JetBrains Mono 10' 2>/dev/null || true
[[ -d /usr/share/icons/Papirus-Dark ]] && (xfconf-query -c xsettings -p /Net/IconThemeName -n -t string -s Papirus-Dark 2>/dev/null || true)
# Wallpaper: use the generated scenic LAINTheme image, never a theme installer dependency.
WALL="$SHARE/assets/lain-wallpaper.png"
if command -v xfconf-query >/dev/null && [[ -f "$WALL" ]]; then
  xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/image-path -n -t string -s "$WALL" 2>/dev/null || true
  xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/image-style -n -t int -s 5 2>/dev/null || true
fi
# Terminal appearance; chafa renders the anime PNG in-band on terminals that lack native image protocols.
if command -v xfconf-query >/dev/null; then
  xfconf-query -c xfce4-terminal -p /font-name -n -t string -s 'JetBrains Mono 10' 2>/dev/null || true
  xfconf-query -c xfce4-terminal -p /background-darkness -n -t double -s 0.78 2>/dev/null || true
  xfconf-query -c xfce4-terminal -p /background-mode -n -t uint -s 1 2>/dev/null || true
  xfconf-query -c xfce4-terminal -p /background-image-file -n -t string -s "$WALL" 2>/dev/null || true
fi
xfconf-query -c xfwm4 -p /general/margin_top -n -t int -s 50 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/margin_bottom -n -t int -s 84 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/snap_to_windows -n -t bool -s true 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/snap_to_border -n -t bool -s true 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/wrap_workspaces -n -t bool -s false 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/workspace_count -n -t int -s 4 2>/dev/null || true
# Remove default XFCE application-menu shortcuts that steal Super+Space and related bindings.
while read -r path val; do
  [[ $path == /commands/custom/* ]] || continue
  if [[ $val == *xfce4-popup-* || $val == *xfce4-popup-applicationsmenu* ]]; then xfconf-query -c xfce4-keyboard-shortcuts -p "$path" -r 2>/dev/null || true; fi
done < <(xfconf-query -c xfce4-keyboard-shortcuts -l -v 2>/dev/null || true)
setkey(){ xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/$1" -n -t string -s "$2" 2>/dev/null || xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/$1" -s "$2" 2>/dev/null || true; }
setkey '<Super>space' "$BIN/lain-shell --launcher"; setkey '<Super>Return' 'xfce4-terminal'; setkey '<Super>e' 'thunar'; setkey '<Super>w' "$BIN/lain-window close"; setkey '<Super>Up' "$BIN/lain-window maximize"; setkey '<Super>Down' "$BIN/lain-window minimize"; setkey '<Super>Left' "$BIN/lain-window snap-left"; setkey '<Super>Right' "$BIN/lain-window snap-right"; setkey '<Super><Shift>r' "$BIN/lain-capture screenshot"; setkey '<Super><Shift>g' "$BIN/lain-capture record"; setkey '<Super><Shift>n' "$BIN/lain-shell --notify"; setkey '<Super><Shift>c' "$BIN/lain-shell --control"; setkey '<Super><Shift>p' "$BIN/lain-shell --power"; setkey '<Super><Shift>l' "$BIN/lain-lock"; setkey '<Super>m' "$BIN/lain-window next-monitor"; setkey '<Super>t' "$BIN/lain-window tile-grid"; for n in {1..9}; do setkey "<Super>$n" "$BIN/lain-window workspace $n"; done
# One-shot suppression of the stock XFCE panel. No recurring panel-killer is installed.
cat > "$HOME_DIR/.config/autostart/lain-panel-suppress.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=LAINTheme Panel Compatibility
Exec=$BIN/lain-panel-suppress
OnlyShowIn=XFCE;
X-GNOME-Autostart-Phase=Panel
X-GNOME-Autostart-enabled=true
EOF
cat > "$BIN/lain-panel-suppress" <<'SH2'
#!/usr/bin/env bash
xfce4-panel --quit >/dev/null 2>&1 || true
SH2
chmod +x "$BIN/lain-panel-suppress"
cat > "$HOME_DIR/.config/autostart/laintheme-shell.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=LAINTheme Shell
Exec=$BIN/lain-shell --start
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-Phase=Applications
X-GNOME-Autostart-enabled=true
EOF
cat > "$HOME_DIR/.config/autostart/laintheme-notify.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=LAINTheme Notifications
Exec=$BIN/lain-notifyd
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF
# Disable the stock notification daemon so our DBus notification server owns the name.
cat > "$HOME_DIR/.config/autostart/xfce4-notifyd.desktop" <<'EOF'
[Desktop Entry]
Hidden=true
EOF
pkill -u "$USER" -x xfce4-notifyd 2>/dev/null || true
# Lite: hard-disable external compositors. High: optional picom with live rollback.
if [[ $MODE == lite ]]; then pkill -u "$USER" -x picom 2>/dev/null || true; pkill -u "$USER" -x compton 2>/dev/null || true; rm -f "$HOME_DIR/.config/autostart/picom.desktop" "$HOME_DIR/.config/autostart/compton.desktop"; xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true 2>/dev/null || true; else xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true 2>/dev/null || true; fi
cat > "$SHARE/reprofile.sh" <<'EOF'
#!/usr/bin/env bash
set -Eeuo pipefail
m=${1:-lite}; printf '%s\n' "$m" > "$HOME/.local/share/laintheme/profile"; if [[ $m == lite ]]; then "$HOME/.local/bin/lain-compositor" stop || true; else "$HOME/.local/bin/lain-compositor" start || true; fi; pkill -u "$USER" -f "$HOME/.local/bin/lain-shell" 2>/dev/null || true; "$HOME/.local/bin/lain-shell" --start >/dev/null 2>&1 &
EOF
chmod +x "$SHARE/reprofile.sh"
cat > "$SHARE/repair.sh" <<'EOF'
#!/usr/bin/env bash
set -Eeuo pipefail
xfce4-panel --quit >/dev/null 2>&1 || true
pkill -u "$USER" -f "$HOME/.local/bin/lain-shell" 2>/dev/null || true
pkill -u "$USER" -f "$HOME/.local/bin/lain-notifyd" 2>/dev/null || true
"$HOME/.local/bin/lain-notifyd" >/dev/null 2>&1 &
"$HOME/.local/bin/lain-shell" --start >/dev/null 2>&1 &
EOF
chmod +x "$SHARE/repair.sh"
cat > "$SHARE/diagnose.sh" <<'EOF'
#!/usr/bin/env bash
set +e
printf 'LAINTheme diagnose\n'; printf 'XFCE=%s\nDISPLAY=%s\nPROFILE=%s\n' "${XDG_CURRENT_DESKTOP:-}" "${DISPLAY:-}" "$(cat "$HOME/.local/share/laintheme/profile" 2>/dev/null || echo unknown)"
for c in python3 xdotool wmctrl xprop xfconf-query nmcli bluetoothctl pactl ffmpeg i3lock zsh chafa; do printf '%-18s %s\n' "$c" "$(command -v "$c" 2>/dev/null || echo MISSING)"; done
python3 -m py_compile "$HOME/.local/bin/lain-shell" "$HOME/.local/bin/lain-notifyd" "$HOME/.local/bin/lain-window" 2>&1 || true
EOF
chmod +x "$SHARE/diagnose.sh"
cat > "$SHARE/uninstall.sh" <<EOF
#!/usr/bin/env bash
set -u
pkill -u "\$USER" -f "\$HOME/.local/bin/lain-shell" 2>/dev/null || true; pkill -u "\$USER" -f "\$HOME/.local/bin/lain-notifyd" 2>/dev/null || true; pkill -u "\$USER" -x picom 2>/dev/null || true
xfce4-panel --quit >/dev/null 2>&1 || true
rm -f "\$HOME/.config/autostart/laintheme-shell.desktop" "\$HOME/.config/autostart/laintheme-notify.desktop" "\$HOME/.config/autostart/lain-panel-suppress.desktop" "\$HOME/.config/autostart/xfce4-notifyd.desktop"
B="\$HOME/.local/state/laintheme/current-backup"
for f in xfwm4.xml xsettings.xml xfce4-keyboard-shortcuts.xml; do [[ -f "\$B/\$f" ]] && cp -f "\$B/\$f" "\$HOME/.config/xfce4/xfconf/xfce-perchannel-xml/\$f"; done
[[ -f "\$B/.zshrc" ]] && cp -f "\$B/.zshrc" "\$HOME/.zshrc"
for f in "\$B"/*.old; do [[ -f "\$f" ]] || continue; base=$(basename "\$f" .old); cp -f "\$f" "\$HOME/.config/autostart/\$base"; done
rm -rf "\$HOME/.themes/LAINTheme-Dark" "\$HOME/.local/share/laintheme"; rm -f "\$HOME/.local/bin/lain-"* "\$HOME/.local/bin/laintheme" "\$HOME/.local/bin/lainconfig"
xfconf-query -c xfwm4 -p /general/margin_top -s 0 2>/dev/null || true; xfconf-query -c xfwm4 -p /general/margin_bottom -s 0 2>/dev/null || true
printf 'LAINTheme removed. Restored the latest backed-up XFCE settings.\n'
EOF
chmod +x "$SHARE/uninstall.sh"
# High compositor with runtime health check and automatic XFWM fallback.
cat > "$BIN/lain-compositor" <<'EOF'
#!/usr/bin/env bash
set -Eeuo pipefail
CONF="$HOME/.config/picom/laintheme.conf"; mkdir -p "$(dirname "$CONF")"; SHARE="$HOME/.local/share/laintheme"; mode=$(cat "$SHARE/profile" 2>/dev/null || echo lite)
case "${1:-status}" in
 start) [[ $mode == high ]] || exit 0; command -v picom >/dev/null || exit 1; cp "$SHARE/picom-high.conf" "$CONF"; pkill -u "$USER" -x picom 2>/dev/null || true; picom --config "$CONF" >/tmp/laintheme-picom.log 2>&1 & pid=$!; sleep 1; if ! kill -0 "$pid" 2>/dev/null; then rm -f "$CONF"; pkill -u "$USER" -x picom 2>/dev/null || true; echo 'fallback: xfwm compositor'; exit 0; fi; echo "$pid" > "$HOME/.cache/laintheme/picom.pid";;
 stop) pkill -u "$USER" -x picom 2>/dev/null || true; rm -f "$HOME/.cache/laintheme/picom.pid";;
 status) pgrep -u "$USER" -x picom >/dev/null && echo running || echo stopped;; *) exit 2;; esac
EOF
chmod +x "$BIN/lain-compositor"
# Zsh setup: create real Oh My Zsh when network is available; never fail desktop install if network is unavailable.
if command -v zsh >/dev/null; then cp -f "$ROOT/zsh/.zshrc" "$HOME_DIR/.zshrc.lain"; cp -f "$ROOT/zsh/.zshrc" "$HOME_DIR/.zshrc"; "$ROOT/zsh/ohmyzsh-installer.sh" || true; chsh -s "$(command -v zsh)" "$USER" 2>/dev/null || true; fi
# Start cleanly and validate syntax before claiming success.
bash -n "$ROOT/laintheme_install.sh" "$BIN/lain-capture" "$BIN/lain-window" "$BIN/lain-lock" "$BIN/lain-compositor" "$BIN/lainconfig" "$SHARE/reprofile.sh" "$SHARE/repair.sh" "$SHARE/uninstall.sh"
python3 -m py_compile "$BIN/lain-shell" "$BIN/lain-notifyd" "$BIN/lain-window"; rm -rf "$BIN/__pycache__"
"$BIN/lain-notifyd" >/dev/null 2>&1 &
"$BIN/lain-shell" --start >/dev/null 2>&1 &
log OK "LAINTheme 2.1.0 installed in $MODE mode."; log OK "Backup: $BACKUP"; log OK "Lite never runs picom. High falls back to XFWM if picom fails."

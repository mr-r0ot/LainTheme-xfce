#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
for f in "$ROOT/laintheme_install.sh" "$ROOT/bin/lain-capture" "$ROOT/bin/lain-lock" "$ROOT/bin/lain-compositor" "$ROOT/bin/lainconfig" "$ROOT/zsh/ohmyzsh-installer.sh"; do bash -n "$f"; done
python3 -m py_compile "$ROOT/bin/lain-shell" "$ROOT/bin/lain-window" "$ROOT/bin/lain-notifyd"
rm -rf "$ROOT/bin/__pycache__"
! grep -RInE 'xfce4-panel[[:space:]]+-r' "$ROOT" >/dev/null
! grep -RIn 'WhiteSur' "$ROOT" >/dev/null
! grep -RInE 'rm[[:space:]]+-rf[[:space:]]+(/|"/|/etc|/usr|/home/)' "$ROOT/laintheme_install.sh" "$ROOT/bin" "$ROOT/zsh" >/dev/null
./"$(basename "$ROOT/laintheme_install.sh")" --help >/dev/null
printf 'LAINTheme static checks: PASS\n'

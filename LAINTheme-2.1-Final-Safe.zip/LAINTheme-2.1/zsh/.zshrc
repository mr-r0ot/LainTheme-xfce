export ZSH="$HOME/.oh-my-zsh"
export ZSH_CUSTOM="$HOME/.oh-my-zsh/custom"
ZSH_THEME="lain"
plugins=(git)
if [[ -f "$ZSH/oh-my-zsh.sh" ]]; then source "$ZSH/oh-my-zsh.sh"; fi
[[ -f "$ZSH_CUSTOM/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh" ]] && source "$ZSH_CUSTOM/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh" || [[ -f /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh ]] && source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh
[[ -f "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" ]] && source "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" || [[ -f /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh ]] && source /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
setopt HIST_IGNORE_DUPS SHARE_HISTORY AUTO_CD INTERACTIVE_COMMENTS
HISTSIZE=10000; SAVEHIST=10000; HISTFILE="$HOME/.zsh_history"
bindkey -e
autoload -Uz add-zsh-hook
__lain_last_status=0; __lain_start=0
preexec(){ __lain_start=$EPOCHREALTIME; }
precmd(){ __lain_last_status=$?; local dur=0; [[ -n "$__lain_start" ]] && dur=$(( EPOCHREALTIME-__lain_start )); export LAIN_LAST_DURATION=$dur; }
function _lain_git(){ command git rev-parse --is-inside-work-tree >/dev/null 2>&1 || return 0; local b=$(git branch --show-current 2>/dev/null); local s=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' '); print -n "%F{magenta}git:%f%F{cyan}${b:-detached}%f"; ((s>0)) && print -n " %F{yellow}±$s%f" }
function _lain_prompt(){ local st=$__lain_last_status; local mark='%F{green}❯%f'; ((st!=0)) && mark='%F{red}❯%f'; local d=${LAIN_LAST_DURATION:-0}; local sec=${d%.*}; local dur=''; ((sec>1)) && dur=" %F{yellow}${sec}s%f"; print -rP "$mark %F{blue}%~%f $(_lain_git)%f${dur} %F{240}%D{%H:%M:%S}%f" }
precmd_functions+=(_lain_prompt)
PROMPT='%{%}%F{magenta}❯%f %F{cyan}%~%f %F{240}$(print -P "%D{%H:%M:%S}")%f\n%F{violet}╰─%f '
RPROMPT='%F{240}%?%f'
alias ll='ls -lah --color=auto'; alias la='ls -A'; alias l='ls -CF'; alias c='clear'; alias cls='clear'
alias lain='laintheme'; alias lainconfig='$HOME/.local/bin/lainconfig'; alias lltheme='$HOME/.local/bin/laintheme status'
fastfetch() { command -v fastfetch >/dev/null && command fastfetch "$@" || { command -v neofetch >/dev/null && command neofetch "$@" || print -P "OS: $(. /etc/os-release; print $PRETTY_NAME) | Kernel: $(uname -r)"; }; }
if [[ -t 1 && -z "$LAIN_NO_GREETING" ]]; then
  if command -v chafa >/dev/null && [[ -f "$HOME/.local/share/laintheme/assets/anime-terminal.png" ]]; then chafa --format symbols --symbols vhalf --size 30x13 "$HOME/.local/share/laintheme/assets/anime-terminal.png" 2>/dev/null; fi
  fastfetch 2>/dev/null | head -n 18
fi

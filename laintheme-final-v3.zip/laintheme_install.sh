#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE=""; DRY_RUN=0; SKIP_UPDATE=0; NO_TERMINAL=0; NO_LOCKER=0; NO_DOCK=0; NO_SOUNDS=0; REPAIR=0; UNINSTALL=0
STATE="${XDG_STATE_HOME:-$HOME/.local/state}/laintheme"; BACKUP="$STATE/backups/$(date +%Y%m%d-%H%M%S)"; LOG="$STATE/install.log"
LOCAL="$HOME/.local"; BIN="$LOCAL/bin"; SHARE="$LOCAL/share/laintheme"; PICOM_OPT="$LOCAL/opt/picom-v13"; AUTOSTART="$HOME/.config/autostart"
mkdir -p "$STATE" "$BACKUP" "$BIN" "$SHARE" "$AUTOSTART"; exec > >(tee -a "$LOG") 2>&1
trap 'echo "[FAIL] line $LINENO. See $LOG" >&2' ERR
info(){ echo "[INFO] $*"; }; ok(){ echo "[ OK ] $*"; }; warn(){ echo "[WARN] $*" >&2; }; fail(){ echo "[FAIL] $*" >&2; exit 1; }
usage(){ cat <<USAGE
LAINTheme installer
  laintheme_install.sh --lite|--high
Options: --repair --uninstall --dry-run --skip-update --no-terminal --no-locker --no-dock --no-sounds
USAGE
}
while (($#)); do case "$1" in
 --lite) MODE=lite;; --high) MODE=high;; --repair) REPAIR=1;; --uninstall) UNINSTALL=1;; --dry-run) DRY_RUN=1;; --skip-update) SKIP_UPDATE=1;; --no-terminal) NO_TERMINAL=1;; --no-locker) NO_LOCKER=1;; --no-dock) NO_DOCK=1;; --no-sounds) NO_SOUNDS=1;; -h|--help) usage; exit 0;; *) usage; fail "Unknown option: $1";; esac; shift; done
[[ $EUID -ne 0 ]] || fail 'Run as the normal desktop user, not with sudo.'
command -v sudo >/dev/null || fail 'sudo is required.'
command -v apt-get >/dev/null || fail 'apt-get not found.'
command -v xfconf-query >/dev/null || fail 'XFCE is not available.'
command -v xfce4-panel >/dev/null || fail 'xfce4-panel is missing.'
[[ -n "${DISPLAY:-}" ]] || fail 'X11 DISPLAY is missing.'
[[ "${XDG_CURRENT_DESKTOP:-}" =~ [Xx][Ff][Cc][Ee] ]] || fail 'LAINTheme requires XFCE.'
if ((UNINSTALL)); then
  rm -f "$AUTOSTART"/laintheme-*.desktop "$HOME/.local/share/dbus-1/services/org.freedesktop.Notifications.service"
  pkill -f "$BIN/lain-shell" >/dev/null 2>&1 || true; pkill -f "$BIN/lain-notifyd" >/dev/null 2>&1 || true; pkill -x picom >/dev/null 2>&1 || true
  if [[ -f "$SHARE/backups/latest/panel.xml" ]]; then mkdir -p "$HOME/.config/xfce4/xfconf/xfce-perchannel-xml"; cp -a "$SHARE/backups/latest/panel.xml" "$HOME/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"; fi
  rm -rf "$SHARE" "$PICOM_OPT"; rm -f "$BIN/laintheme" "$BIN/laintheme_install.sh" "$BIN/lain-capture" "$BIN/lain-lock" "$BIN/lain-notifyd" "$BIN/lain-shell" "$BIN/lain-wifi" "$BIN/lain-window" "$BIN/picom-laintheme"; xfce4-panel >/dev/null 2>&1 & true; ok 'LAINTheme user integration removed.'; exit 0
fi
if ((REPAIR)); then MODE="$(cat "$SHARE/profile" 2>/dev/null || true)"; fi
[[ "$MODE" == lite || "$MODE" == high ]] || fail 'Choose --lite or --high, or use --repair.'
PKGS=(python3 python3-gi python3-gi-cairo gir1.2-gtk-3.0 python3-dbus python3-cairo dbus-x11 xfce4-panel xfce4-terminal xfce4-screensaver xfce4-screenshooter plank wmctrl xdotool x11-utils network-manager network-manager-gnome bluez bluetooth rfkill pulseaudio-utils pavucontrol brightnessctl ffmpeg imagemagick zsh git curl ca-certificates fonts-jetbrains-mono sassc libglib2.0-dev-bin libglib2.0-dev libxml2-utils optipng inkscape bc policykit-1 upower libcanberra-gtk3-0 libcanberra-gtk3-module)
((NO_LOCKER)) || PKGS+=(i3lock)
if [[ "$MODE" == high ]]; then PKGS+=(picom mesa-utils); fi
if ((DRY_RUN)); then printf 'Profile: %s\nPackages:\n' "$MODE"; printf '  %s\n' "${PKGS[@]}"; exit 0; fi
if (( ! SKIP_UPDATE )); then sudo apt-get update; fi
AV=(); for p in "${PKGS[@]}"; do apt-cache show "$p" >/dev/null 2>&1 && AV+=("$p") || warn "Package unavailable: $p"; done
((${#AV[@]})) && sudo apt-get install -y "${AV[@]}"
for c in python3 git curl xfconf-query xfce4-panel wmctrl xdotool; do command -v "$c" >/dev/null || fail "Missing command: $c"; done
export PATH="$HOME/.local/bin:$PATH"
mkdir -p "$SHARE" "$HOME/.local/share/dbus-1/services" "$HOME/.config/picom"
cp -a "$PROJECT_DIR/bin/." "$BIN/"; cp -a "$PROJECT_DIR/assets/." "$SHARE/assets/"; cp -a "$PROJECT_DIR/config/." "$SHARE/config/"; cp -a "$PROJECT_DIR/zsh/." "$SHARE/zsh/"; cp -f "$PROJECT_DIR/laintheme_install.sh" "$BIN/laintheme_install.sh"; chmod +x "$BIN"/*
printf '%s\n' "$MODE" > "$SHARE/profile"
mkdir -p "$SHARE/backups/latest"
PANEL="$HOME/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"; [[ -f "$PANEL" ]] && cp -a "$PANEL" "$SHARE/backups/latest/panel.xml" || true
# WhiteSur assets; project remains independent of any former Step1.
TS="$SHARE/third_party"; mkdir -p "$TS"
clone_or_pin_repo(){
  local url="$1" name="$2" ref="${3:-}"
  local dir="$TS/$name"
  if [[ -d "$dir/.git" ]]; then
    if [[ -n "$ref" ]]; then
      git -C "$dir" fetch --depth=1 origin "refs/tags/$ref:refs/tags/$ref" >/dev/null 2>&1 || true
      git -C "$dir" checkout -f "$ref" >/dev/null 2>&1 || git -C "$dir" reset --hard "$ref" >/dev/null 2>&1 || fail "Could not select required $name version: $ref"
    fi
  else
    rm -rf "$dir"
    if [[ -n "$ref" ]]; then
      git clone --depth=1 --branch "$ref" "$url" "$dir" || fail "Could not clone required theme repository: $name"
    else
      git clone --depth=1 "$url" "$dir" || fail "Could not clone required theme repository: $name"
    fi
  fi
}
clone_or_pin_repo 'https://github.com/vinceliuice/WhiteSur-gtk-theme.git' 'WhiteSur-gtk-theme' '2026-07-07'
clone_or_pin_repo 'https://github.com/vinceliuice/WhiteSur-icon-theme.git' 'WhiteSur-icon-theme'
clone_or_pin_repo 'https://github.com/vinceliuice/WhiteSur-cursors.git' 'WhiteSur-cursors'
THEMES="$HOME/.themes"; ICONS="$HOME/.local/share/icons"; mkdir -p "$THEMES" "$ICONS"
[[ -x "$TS/WhiteSur-gtk-theme/install.sh" ]] || fail 'WhiteSur GTK installer is missing.'
patch_whitesur_xfce(){
  local repo="$TS/WhiteSur-gtk-theme"
  local lib="$repo/libs/lib-install.sh"
  [[ -f "$lib" ]] || fail 'WhiteSur lib-install.sh is missing.'
  python3 - "$lib" <<'PY_PATCH'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text()
pat = re.compile(r'^(\s*)install_shelly "\$\{color\}" "\$\{opacity\}" "\$\{alt\}" "\$\{theme\}" "\$\{scheme\}" "\$\{icon\}"\s*$', re.M)
s, n = pat.subn(r'\1if has_command gnome-shell; then install_shelly "${color}" "${opacity}" "${alt}" "${theme}" "${scheme}" "${icon}"; fi', s)
if n not in (0, 1):
    raise SystemExit(f'Expected zero or one install_themes install_shelly call; found {n}')
pat2 = re.compile(r'^(\s*)xfce4-panel -r\s*$', re.M)
s, n2 = pat2.subn(r'\1xfce4-panel -r || true', s)
if n2 < 1:
    raise SystemExit('Expected at least one xfce4-panel -r call; none found')
p.write_text(s)
PY_PATCH
  bash -n "$lib" || fail 'Patched WhiteSur lib-install.sh failed syntax validation.'
  if ! command -v gnome-shell >/dev/null 2>&1; then
    if grep -Eq '^[[:space:]]*install_shelly "\$\{color\}" "\$\{opacity\}" "\$\{alt\}" "\$\{theme\}" "\$\{scheme\}" "\$\{icon\}"[[:space:]]*$' "$lib"; then
      fail 'WhiteSur XFCE patch verification failed: unguarded install_shelly remains.'
    fi
  fi
}
patch_whitesur_xfce
bash "$TS/WhiteSur-gtk-theme/install.sh" -d "$THEMES" -c dark -c light || fail 'WhiteSur GTK installation failed even after the XFCE compatibility patch.'
[[ -x "$TS/WhiteSur-icon-theme/install.sh" ]] || fail 'WhiteSur icon installer is missing.'
bash "$TS/WhiteSur-icon-theme/install.sh" -d "$ICONS" || fail 'WhiteSur icon installation failed.'
[[ -f "$TS/WhiteSur-cursors/build.sh" ]] || fail 'WhiteSur cursor build script is missing.'
sudo apt-get install -y xorg-xcursorgen librsvg2-bin >/dev/null 2>&1 || fail 'Cursor build dependencies could not be installed.'
(cd "$TS/WhiteSur-cursors" && bash build.sh && bash install.sh) || fail 'WhiteSur cursor build/install failed.'
GTK_THEME=''
for t in WhiteSur-Dark WhiteSur-dark; do
  if [[ -d "$THEMES/$t" ]]; then GTK_THEME="$t"; break; fi
done
[[ -n "$GTK_THEME" ]] || fail 'WhiteSur dark GTK theme was not installed.'
xfconf-query -c xsettings -p /Net/ThemeName -n -t string -s "$GTK_THEME" || xfconf-query -c xsettings -p /Net/ThemeName -s "$GTK_THEME"
ICON_THEME=''
for i in WhiteSur-dark WhiteSur; do
  if [[ -d "$ICONS/$i" ]]; then ICON_THEME="$i"; break; fi
done
[[ -n "$ICON_THEME" ]] || fail 'WhiteSur icon theme was not installed.'
xfconf-query -c xsettings -p /Net/IconThemeName -n -t string -s "$ICON_THEME" || xfconf-query -c xsettings -p /Net/IconThemeName -s "$ICON_THEME"
[[ -d "$ICONS/WhiteSur-cursors/cursors" ]] || fail 'WhiteSur cursor theme was not installed.'
xfconf-query -c xsettings -p /Gtk/CursorThemeName -n -t string -s WhiteSur-cursors || xfconf-query -c xsettings -p /Gtk/CursorThemeName -s WhiteSur-cursors
xfconf-query -c xsettings -p /Gtk/FontName -n -t string -s 'JetBrains Mono 10' || true
xfconf-query -c xsettings -p /Gtk/MonospaceFontName -n -t string -s 'JetBrains Mono 10' || true
mkdir -p "$HOME/Pictures/LAINTheme"; cp "$SHARE/assets/lain-anime.svg" "$HOME/Pictures/LAINTheme/"; cp "$SHARE/assets/lain-terminal.svg" "$HOME/Pictures/LAINTheme/"; cp "$SHARE/assets/lain-lock.svg" "$HOME/Pictures/LAINTheme/"
xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/last-image -n -t string -s "$HOME/Pictures/LAINTheme/lain-anime.svg" 2>/dev/null || true; xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/image-style -n -t int -s 5 2>/dev/null || true
# Window integration and snap behavior. Keep positional installer arguments untouched.
set_xfwm_bool(){ local prop="$1" value="$2"; xfconf-query -c xfwm4 -p "/general/$prop" -n -t bool -s "$value" 2>/dev/null || xfconf-query -c xfwm4 -p "/general/$prop" -s "$value" 2>/dev/null || true; }
set_xfwm_bool snap_to_windows true
set_xfwm_bool snap_to_border true
set_xfwm_bool wrap_windows false
[[ -n "$(command -v zsh || true)" ]] && chsh -s "$(command -v zsh)" "$USER" 2>/dev/null || true
if [[ "$MODE" == high && ! -x "$BIN/picom-laintheme" ]]; then
  v=$(picom --version 2>/dev/null | sed -n 's/.*v\([0-9][0-9]*\).*/\1/p' | head -1 || true)
  if [[ "$v" =~ ^(12|13)$ ]]; then ln -sf "$(command -v picom)" "$BIN/picom-laintheme"; else
    sudo apt-get install -y meson ninja-build gcc pkg-config libconfig-dev libdbus-1-dev libegl-dev libev-dev libgl-dev libepoxy-dev libpcre2-dev libpixman-1-dev libx11-xcb-dev libxcb1-dev libxcb-composite0-dev libxcb-damage0-dev libxcb-glx0-dev libxcb-image0-dev libxcb-present0-dev libxcb-randr0-dev libxcb-render0-dev libxcb-render-util0-dev libxcb-shape0-dev libxcb-util-dev libxcb-xfixes0-dev uthash-dev
    SRC="$STATE/picom-v13"; [[ -d "$SRC/.git" ]] || git clone --depth=1 --branch v13 https://github.com/yshui/picom.git "$SRC"; rm -rf "$SRC/build"; meson setup "$SRC/build" "$SRC" --buildtype=release -Dprefix="$PICOM_OPT"; meson compile -C "$SRC/build"; meson install -C "$SRC/build"; ln -sf "$PICOM_OPT/bin/picom" "$BIN/picom-laintheme"
  fi
fi
if [[ "$MODE" == lite ]]; then
  xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true 2>/dev/null || xfconf-query -c xfwm4 -p /general/use_compositing -s true 2>/dev/null || true
  rm -f "$HOME/.config/autostart/laintheme-picom.desktop"
  if [[ -f "$HOME/.config/autostart/picom.desktop" ]]; then
    cp -a "$HOME/.config/autostart/picom.desktop" "$SHARE/backups/latest/picom.desktop"
    rm -f "$HOME/.config/autostart/picom.desktop"
  fi
  pkill -x picom >/dev/null 2>&1 || true
else
  xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s false 2>/dev/null || true
  if ! "$BIN/laintheme" compositor install-high; then fail 'High profile requires picom v12/v13. Local build/install failed.'; fi
  cp "$SHARE/config/picom-high.conf" "$HOME/.config/picom/laintheme.conf"
  cat > "$HOME/.config/autostart/laintheme-picom.desktop" <<EOF2
[Desktop Entry]
Type=Application
Name=LAINTheme Compositor
Exec=$BIN/laintheme compositor start
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF2
  "$BIN/laintheme" compositor start || fail 'High profile picom failed to start with the installed configuration. Run laintheme diagnose after restoring the backup.'
fi
# Replace XFCE panel visual with LAINTheme shell; backup already exists.
xfce4-panel --quit >/dev/null 2>&1 || true
cat > "$AUTOSTART/laintheme-shell.desktop" <<EOF2
[Desktop Entry]
Type=Application
Name=LAINTheme Shell
Exec=$BIN/laintheme shell start
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF2
rm -f "$AUTOSTART/xfce4-notifyd.desktop" "$AUTOSTART/xfce-notifyd.desktop"; pkill -x xfce4-notifyd >/dev/null 2>&1 || true
rm -f "$AUTOSTART/laintheme-panel-guard.desktop"
cat > "$AUTOSTART/laintheme-notify.desktop" <<EOF2
[Desktop Entry]
Type=Application
Name=LAINTheme Notifications
Exec=$BIN/laintheme notify start
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF2
cat > "$HOME/.local/share/dbus-1/services/org.freedesktop.Notifications.service" <<EOF2
[D-BUS Service]
Name=org.freedesktop.Notifications
Exec=$BIN/lain-notifyd
EOF2
if (( ! NO_DOCK )); then mkdir -p "$HOME/.local/share/plank/themes"; [[ -d "$TS/WhiteSur-gtk-theme/src/other/plank" ]] && cp -a "$TS/WhiteSur-gtk-theme/src/other/plank/." "$HOME/.local/share/plank/themes/" || true; cat > "$AUTOSTART/laintheme-plank.desktop" <<EOF2
[Desktop Entry]
Type=Application
Name=LAINTheme Dock
Exec=plank
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF2
pkill plank >/dev/null 2>&1 || true; plank >/dev/null 2>&1 & sleep .7; gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ position bottom 2>/dev/null || true; gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ icon-size 48 2>/dev/null || true; gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ zoom-enabled true 2>/dev/null || true; gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ zoom-percent 145 2>/dev/null || true; fi
if (( ! NO_TERMINAL )); then mkdir -p "$HOME/.zsh/plugins"; [[ -d "$HOME/.oh-my-zsh/.git" ]] || git clone --depth=1 https://github.com/ohmyzsh/ohmyzsh.git "$HOME/.oh-my-zsh" || true; [[ -d "$HOME/.zsh/plugins/zsh-autosuggestions/.git" ]] || git clone --depth=1 https://github.com/zsh-users/zsh-autosuggestions.git "$HOME/.zsh/plugins/zsh-autosuggestions" || true; [[ -d "$HOME/.zsh/plugins/zsh-syntax-highlighting/.git" ]] || git clone --depth=1 https://github.com/zsh-users/zsh-syntax-highlighting.git "$HOME/.zsh/plugins/zsh-syntax-highlighting" || true; if [[ "$MODE" == high ]]; then [[ -d "$HOME/.oh-my-zsh/custom/themes/powerlevel10k/.git" ]] || git clone --depth=1 https://github.com/romkatv/powerlevel10k.git "$HOME/.oh-my-zsh/custom/themes/powerlevel10k" || true; cp "$SHARE/zsh/.zshrc-high" "$HOME/.zshrc"; else cp "$SHARE/zsh/.zshrc" "$HOME/.zshrc"; fi; mkdir -p "$HOME/.config/xfce4/terminal"; cp "$SHARE/assets/lain-terminal.svg" "$HOME/Pictures/LAINTheme/lain-terminal.svg"; cat > "$HOME/.config/xfce4/terminal/terminalrc" <<EOF2
[Configuration]
FontName=JetBrains Mono 11
MiscMenubarDefault=FALSE
MiscToolbarDefault=FALSE
BackgroundMode=TERMINAL_BACKGROUND_IMAGE
BackgroundImageFile=$HOME/Pictures/LAINTheme/lain-terminal.svg
BackgroundImageStyle=TERMINAL_BACKGROUND_STYLE_SCALED
BackgroundDarkness=0.30
BackgroundImageShading=0.20
EOF2
fi
if (( ! NO_LOCKER )); then rm -f "$AUTOSTART/xfce4-screensaver.desktop"; fi
if (( ! NO_SOUNDS )); then mkdir -p "$HOME/.local/share/sounds/LAINTheme/stereo"; cat > "$AUTOSTART/laintheme-login-sound.desktop" <<EOF2
[Desktop Entry]
Type=Application
Name=LAINTheme Login Sound
Exec=canberra-gtk-play -i desktop-login
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF2
 cp "$SHARE/assets/sound-theme.index" "$HOME/.local/share/sounds/LAINTheme/index.theme"; cp "$SHARE/assets/sounds/"*.wav "$HOME/.local/share/sounds/LAINTheme/stereo/"; xfconf-query -c xsettings -p /Net/EnableEventSounds -n -t bool -s true 2>/dev/null || true; fi
set_key(){ xfconf-query -c xfce4-keyboard-shortcuts -p "$1" -n -t string -s "$2" 2>/dev/null || true; }
set_key '/commands/custom/<Super>space' "$BIN/laintheme launcher"; set_key '/commands/custom/<Super>Return' xfce4-terminal; set_key '/commands/custom/<Super>e' thunar; set_key '/commands/custom/<Super>w' 'wmctrl -c :ACTIVE:'; set_key '/commands/custom/<Super>Up' "$BIN/lain-window maximize"; set_key '/commands/custom/<Super>Down' "$BIN/lain-window minimize"; set_key '/commands/custom/<Super>Left' "$BIN/lain-window snap-left"; set_key '/commands/custom/<Super>Right' "$BIN/lain-window snap-right"; set_key '/commands/custom/<Super><Shift>c' "$BIN/lain-window center"; set_key '/commands/custom/<Super><Shift>f' "$BIN/lain-window fullscreen"; set_key '/commands/custom/<Super><Shift>a' "$BIN/lain-window always-on-top"; set_key '/commands/custom/<Super><Shift>m' "$BIN/lain-window next-monitor"; for n in {1..9}; do set_key "/commands/custom/<Super>$n" "$BIN/lain-window workspace $((n-1))"; done; set_key '/commands/custom/<Super><Shift>r' "$BIN/lain-capture screenshot"; set_key '/commands/custom/<Super><Shift>g' "$BIN/lain-capture record"; set_key '/commands/custom/<Super><Shift>l' "$BIN/lain-lock"; set_key '/commands/custom/<Super><Shift>p' "$BIN/laintheme power"
pkill -f "$BIN/lain-shell" >/dev/null 2>&1 || true; pkill -f "$BIN/lain-notifyd" >/dev/null 2>&1 || true; "$BIN/laintheme" notify start || true; "$BIN/laintheme" shell start || true
python3 -m py_compile "$BIN/laintheme" "$BIN/lain-shell" "$BIN/lain-lock" "$BIN/lain-notifyd" "$BIN/lain-capture"; bash -n "$BIN/lain-window" "$BIN/lain-wifi" "$BIN/lain-capture"
ok "LAINTheme $MODE installation complete. Log: $LOG"

#!/usr/bin/env bash
set -Eeuo pipefail

STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
STATE_DIR="$STATE_HOME/lain-theme"
CURRENT_BACKUP="$STATE_DIR/current-backup"
stop_owned_tools() {
  local plank_tool="$HOME/.local/bin/lain-plank"
  local compositor_tool="$HOME/.local/bin/lain-compositor"
  if [[ -x "$plank_tool" ]]; then "$plank_tool" stop >/dev/null 2>&1 || true
  elif command -v lain-plank >/dev/null 2>&1; then lain-plank stop >/dev/null 2>&1 || true
  fi
  if [[ -x "$compositor_tool" ]]; then "$compositor_tool" stop >/dev/null 2>&1 || true
  elif command -v lain-compositor >/dev/null 2>&1; then lain-compositor stop >/dev/null 2>&1 || true
  fi
  if [[ -x "$HOME/.local/bin/lain-eww" ]]; then "$HOME/.local/bin/lain-eww" stop >/dev/null 2>&1 || true; fi
  local sxhkd_config="${XDG_CONFIG_HOME:-$HOME/.config}/sxhkd/lain-theme/sxhkdrc"
  for proc in /proc/[0-9]*/cmdline; do
    [[ -r "$proc" ]] || continue
    local pid="${proc#/proc/}"; pid="${pid%/cmdline}"
    [[ "$pid" != "$$" ]] || continue
    [[ "$(stat -c %u "/proc/$pid" 2>/dev/null || true)" == "$(id -u)" ]] || continue
    tr '\0' ' ' <"$proc" 2>/dev/null | grep -Fq -- "$sxhkd_config" && kill -TERM "$pid" 2>/dev/null || true
  done
  pkill -x dunst >/dev/null 2>&1 || true
  pkill -x copyq >/dev/null 2>&1 || true
}
if [[ ! -f "$CURRENT_BACKUP" ]]; then
  # The release archive itself is also a valid cleanup entry point. A prior
  # installer may have been interrupted before writing its manifest, so remove
  # only explicitly-owned LAINTheme paths and never touch arbitrary user data.
  printf '[1/2] Removing orphaned LAINTheme components\n'
  systemctl --user stop lain-shell.service >/dev/null 2>&1 || true
  gapplication quit io.github.laintheme.XfceShell >/dev/null 2>&1 || true
  stop_owned_tools
  rm -rf -- "${XDG_DATA_HOME:-$HOME/.local/share}/lain-theme" "${XDG_CONFIG_HOME:-$HOME/.config}/lain-theme" \
    "${XDG_DATA_HOME:-$HOME/.local/share}/sounds/LAINTheme" "$HOME/.themes/LAINTheme-Dark"
  rm -rf -- "${XDG_CONFIG_HOME:-$HOME/.config}/eww/lain-theme" \
    "${XDG_CONFIG_HOME:-$HOME/.config}/sxhkd/lain-theme"
  for managed_file in \
    "${XDG_CONFIG_HOME:-$HOME/.config}/dunst/dunstrc" \
    "${XDG_CONFIG_HOME:-$HOME/.config}/rofi/lain-theme.rasi" \
    "${XDG_CONFIG_HOME:-$HOME/.config}/kitty/kitty.conf"; do
    if [[ -f "$managed_file" ]] && grep -q 'Managed by LAINTheme-Xfce' "$managed_file" 2>/dev/null; then
      rm -f -- "$managed_file"
    fi
  done
  rm -f -- "${XDG_CONFIG_HOME:-$HOME/.config}/fontconfig/conf.d/50-lain-jetbrains-mono.conf" \
    "${XDG_CONFIG_HOME:-$HOME/.config}/autostart/lain-shell.desktop" \
    "${XDG_CONFIG_HOME:-$HOME/.config}/autostart/xfce4-panel.desktop" \
    "${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user/lain-shell.service"
  rm -f -- "$HOME/.local/bin/lain-shell" "$HOME/.local/bin/lain-plank" "$HOME/.local/bin/lain-launcher" \
    "$HOME/.local/bin/lain-eww" "$HOME/.local/bin/lain-hotkeys" "$HOME/.local/bin/lain-workspace" "$HOME/.local/bin/lain-status" "$HOME/.local/bin/lain-action" "$HOME/.local/bin/eww" "$HOME/.local/bin/lain-wallpaper" \
    "$HOME/.local/bin/lain-terminal" "$HOME/.local/bin/lain-lock" "$HOME/.local/bin/lain-session-start" \
    "$HOME/.local/bin/lain-apply-settings" "$HOME/.local/bin/lain-compositor" "$HOME/.local/bin/lain-settings" \
    "$HOME/.local/bin/lainctl"
  for launcher in "${XDG_CONFIG_HOME:-$HOME/.config}/plank/dock1/launchers"/lain-*.dockitem; do
    [[ -e "$launcher" ]] && rm -f -- "$launcher"
  done
  if command -v xfconf-query >/dev/null 2>&1; then
    xfconf-query -c xfwm4 -p /general/button_layout -n -t string -s 'O|HMC' >/dev/null 2>&1 || true
  fi
  command -v xfce4-panel >/dev/null 2>&1 && [[ -n "${DISPLAY:-}" ]] && xfce4-panel >/dev/null 2>&1 &
  printf '[DONE] Orphaned LAINTheme components removed; XFCE panel/window controls restored.\n'
  exit 0
fi
BACKUP_ROOT="$(<"$CURRENT_BACKUP")"
MANIFEST="$BACKUP_ROOT/manifest.tsv"
if [[ ! -f "$MANIFEST" ]]; then
  printf 'Backup manifest is missing; performing owned-path cleanup.\n' >&2
  rm -f -- "$CURRENT_BACKUP"
  exec "$0"
fi

printf '[1/4] Stopping LAINTheme services\n'
systemctl --user stop lain-shell.service >/dev/null 2>&1 || true
if command -v gapplication >/dev/null 2>&1; then gapplication quit io.github.laintheme.XfceShell >/dev/null 2>&1 || true; fi
stop_owned_tools

printf '[2/4] Restoring user configuration\n'
while IFS=$'\t' read -r kind path; do
  [[ -n "$path" ]] || continue
  saved="$BACKUP_ROOT/user/${path#/}"
  if [[ "$kind" == "E" ]]; then
    rm -rf -- "$path"
    mkdir -p "$(dirname "$path")"
    cp -a -- "$saved" "$path"
  else
    rm -rf -- "$path"
  fi
done <"$MANIFEST"

printf '[3/4] Restoring LightDM override\n'
system_backup="$BACKUP_ROOT/system"
if [[ -f "$system_backup/manifest.tsv" ]] && command -v sudo >/dev/null 2>&1; then
  while IFS=$'\t' read -r kind path key; do
    [[ -n "$path" && -n "$key" ]] || continue
    sudo rm -rf -- "$path"
    if [[ "$kind" == E ]]; then
      sudo install -d -m 0755 "$(dirname "$path")"
      sudo cp -a -- "$system_backup/$key" "$path"
    fi
  done <"$system_backup/manifest.tsv"
fi
if [[ -s "$BACKUP_ROOT/plank.dconf" ]] && command -v dconf >/dev/null 2>&1; then
  dconf load /net/launchpad/plank/ <"$BACKUP_ROOT/plank.dconf" >/dev/null 2>&1 || true
fi

printf '[4/4] Restoring XFCE session components\n'
if command -v xfdesktop >/dev/null 2>&1; then xfdesktop --reload >/dev/null 2>&1 || true; fi
systemctl --user daemon-reload >/dev/null 2>&1 || true
if command -v xfce4-panel >/dev/null 2>&1 && [[ -n "${DISPLAY:-}" ]]; then xfce4-panel >/dev/null 2>&1 & fi
rm -f -- "$CURRENT_BACKUP" "$STATE_DIR/install-state"
printf '[DONE] Previous XFCE configuration restored. Backup retained at %s\n' "$BACKUP_ROOT"

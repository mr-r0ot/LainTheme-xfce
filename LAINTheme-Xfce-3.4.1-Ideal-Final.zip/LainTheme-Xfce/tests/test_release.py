from __future__ import annotations

import ast
import hashlib
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class ReleaseContractTests(unittest.TestCase):
    def text(self, path: str) -> str:
        return (ROOT / path).read_text(encoding="utf-8")

    def test_every_python_file_parses(self):
        for path in (ROOT / "src").rglob("*.py"):
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    def test_installer_has_exactly_eleven_visible_steps(self):
        calls = re.findall(r'^step\s+(\d+)\s+"', self.text("install.sh"), re.M)
        self.assertEqual(calls, [str(number) for number in range(1, 12)])

    def test_shortcut_contract(self):
        installer = self.text("install.sh")
        self.assertIn("/commands/custom/<Super>z", installer)
        self.assertIn("lain-launcher", installer)
        self.assertIn("workspace_${workspace}_key", installer)
        self.assertNotIn("/commands/custom/<Super>space' -n", installer)

    def test_no_destructive_panel_loop(self):
        all_shell = "\n".join(path.read_text(encoding="utf-8") for path in ROOT.rglob("*.sh"))
        self.assertNotIn("pkill -f", all_shell)
        self.assertNotIn("xfce4-panel -r", all_shell)
        self.assertNotIn("while true", all_shell)

    def test_notification_signature(self):
        source = self.text("src/lain_shell/notifications.py")
        signature = re.findall(r'<arg direction="in" type="([^"]+)"', source)
        self.assertEqual(signature[:8], ["s", "u", "s", "s", "s", "as", "a{sv}", "i"])
        self.assertIn("ToastWindow", self.text("src/lain_shell/app.py"))

    def test_bluetooth_agent_supports_pin_and_confirmation(self):
        source = self.text("src/lain_shell/bluez_agent.py")
        self.assertIn("KeyboardDisplay", source)
        self.assertIn("RequestPinCode", source)
        self.assertIn("RequestPasskey", source)
        self.assertIn("RequestConfirmation", source)

    def test_multimonitor_construction_and_strut(self):
        app = self.text("src/lain_shell/app.py")
        x11 = self.text("src/lain_shell/x11.py")
        self.assertIn("for monitor in monitors:", app)
        self.assertIn("_NET_WM_STRUT_PARTIAL", x11)
        self.assertIn("monitor.x + monitor.width - 1", x11)

    def test_bottom_dock_is_plank_only(self):
        app = self.text("src/lain_shell/app.py")
        session = self.text("bin/lain-session-start")
        installer = self.text("install.sh")
        self.assertNotIn("DockWindow", app)
        self.assertIn("lain-plank sync", session)
        self.assertIn("lain-plank start", session)
        self.assertIn("plank", installer)

    def test_eww_topbar_and_sxhkd_are_primary(self):
        session = self.text("bin/lain-session-start")
        eww = self.text("bin/lain-eww")
        sxhkd = self.text("config/sxhkd/lain-theme/sxhkdrc")
        yuck = self.text("config/eww/lain-theme/eww.yuck")
        self.assertIn("lain-eww start", session)
        self.assertIn("lain-hotkeys", session)
        self.assertIn("defwindow topbar", yuck)
        self.assertIn("defwindow control", yuck)
        self.assertIn("eww", eww)
        self.assertIn("active-windows", eww)
        self.assertIn("super + z", sxhkd)
        self.assertIn("lain-workspace switch 9", sxhkd)
        self.assertIn("xdotool", self.text("bin/lain-workspace"))
        self.assertNotIn(":windowtype \"popup\"", yuck)
        self.assertNotIn("calc(", yuck)
        self.assertIn("eww_cmd open --toggle", eww)

    def test_eww_config_is_balanced_and_boot_is_fail_visible(self):
        yuck = self.text("config/eww/lain-theme/eww.yuck")
        self.assertEqual(yuck.count("("), yuck.count(")"))
        session = self.text("bin/lain-session-start")
        self.assertIn("if ! lain-eww start; then", session)
        self.assertNotIn("safe GTK fallback", session)
        installer = self.text("install.sh")
        self.assertIn("v0.6.0", installer)
        self.assertIn("cargo build --locked --release --no-default-features --features x11", installer)
        self.assertIn('LAIN_EWW_BUILD_TIMEOUT:-3600', installer)
        self.assertIn('LAIN_EWW_BUILD_JOBS:-1', installer)
        self.assertIn('progress was preserved', installer)
        self.assertNotIn('rm -rf -- "$build_root"', installer)

    def test_panel_popovers_are_not_confined_to_panel_height(self):
        ui = self.text("src/lain_shell/ui.py")
        self.assertIn("if self.get_mapped()", ui)
        self.assertNotIn("if self.get_visible():\n            self.popdown()", ui)
        self.assertIn("self.status_control = ControlCenterPopover", ui)
        self.assertIn("self.control_center = ControlCenterPopover", ui)
        self.assertIn("self.power_menu = PowerPopover", ui)
        self.assertIn("class ManagedPopover(Gtk.Window)", ui)
        self.assertIn("_place_below_anchor", ui)
        self.assertNotIn("Gtk.Popover", ui)

    def test_panel_controls_have_real_click_targets(self):
        ui = self.text("src/lain_shell/ui.py")
        self.assertIn('apps_button.connect("clicked"', ui)
        self.assertIn('self.status_button.connect("clicked"', ui)
        self.assertIn('self.notify_button.connect("clicked"', ui)
        self.assertIn('cc_button.connect("clicked"', ui)
        self.assertIn('power_button.connect("clicked"', ui)
        self.assertIn("overlay.set_overlay_pass_through(self.clock, True)", ui)

    def test_reference_visual_stack_is_installed(self):
        installer = self.text("install.sh")
        self.assertIn("LAINTheme-Dark", installer)
        self.assertIn("papirus-icon-theme", installer)
        self.assertIn("Papirus-Dark", installer)
        self.assertIn("/Gtk/FontName", installer)
        self.assertIn("JetBrains Mono 10", installer)
        self.assertTrue((ROOT / "theme/LAINTheme-Dark/gtk-3.0/gtk.css").is_file())
        self.assertTrue((ROOT / "theme/LAINTheme-Dark/xfwm4/themerc").is_file())
        session = self.text("bin/lain-session-start")
        self.assertIn("lain-apply-settings", session)
        expected = {
            "assets/terminal-art.png": "8d39a8736530b126f06151393750abb929e781d4da24e0c9153b2a1d9f17c8ad",
            "assets/wallpaper.png": "6128480865ae7e7ccbfa6572fcd31ff13d39e3ea09ea54025f9a3eaab6c086e4",
            "theme/LAINTheme-Dark/gtk-3.0/gtk.css": "ffef0577d235c48c15480c52e3c037608662279271b6a85824d858b5f0335d88",
            "theme/LAINTheme-Dark/xfwm4/themerc": "26f5113887e9a7e1e8613489fd5426aaca5a5ed9a53f1d67501a5e2733ac59a3",
        }
        for path, digest in expected.items():
            self.assertEqual(hashlib.sha256((ROOT / path).read_bytes()).hexdigest(), digest)

    def test_dock_uses_large_theme_icons(self):
        plank = self.text("bin/lain-plank")
        self.assertIn("set_gsetting icon-size 56", plank)
        self.assertIn("set_gsetting zoom-percent 125", plank)
        self.assertIn("Theme=LAINTheme", plank)
        self.assertIn(".dockitem", plank)
        self.assertIn("find \"$DATA_HOME/applications\"", plank)

    def test_user_assets_are_editable_and_preserved(self):
        installer = self.text("install.sh")
        self.assertIn('PICTURES_DIR="$HOME/Pictures/LAINTheme"', installer)
        self.assertIn('[[ -e "$PICTURES_DIR/$asset" ]] || cp -a', installer)
        self.assertIn('lock_source="$PICTURES_DIR/lock.png"', installer)
        self.assertIn('wallpaper_source="$pictures_dir/wallpaper.png"', self.text("bin/lain-apply-settings"))

    def test_zsh_is_isolated_not_appended(self):
        installer = self.text("install.sh")
        zshrc = self.text("config/zsh/zshrc")
        self.assertNotIn("BEGIN LAINTHEME", installer)
        self.assertIn('install -m 0644 "$PROJECT_ROOT/config/zsh/zshrc" "$HOME/.zshrc"', installer)
        self.assertIn('lain-theme/oh-my-zsh', zshrc)
        self.assertNotIn('$HOME/.oh-my-zsh', zshrc)
        terminal = self.text("config/xfce-terminal/terminalrc")
        self.assertIn("RunCustomCommand=TRUE", terminal)
        self.assertIn("CustomCommand=zsh", terminal)
        kitty = self.text("config/kitty/kitty.conf")
        self.assertIn("font_family JetBrains Mono", kitty)
        self.assertIn("font_size 11", kitty)

    def test_real_lightdm_seat_and_greeter(self):
        installer = self.text("install.sh")
        locker = self.text("bin/lain-lock")
        self.assertIn("greeter-session=lightdm-gtk-greeter", installer)
        self.assertIn("theme-name=LAINTheme-Dark", installer)
        self.assertIn("icon-theme-name=Papirus-Dark", installer)
        self.assertIn("backup_system_path", installer)
        self.assertIn("dm-tool lock", locker)
        self.assertLess(locker.index("dm-tool lock"), locker.index("i3lock --nofork"))

    def test_xfwm_controls_and_channels(self):
        installer = self.text("install.sh")
        apply_settings = self.text("bin/lain-apply-settings")
        themerc = self.text("theme/LAINTheme-Dark/xfwm4/themerc")
        self.assertIn("xfconf-query -c xfwm4 -p /general/theme", installer)
        self.assertNotIn("xsettings -p /general/theme", installer)
        self.assertIn("/general/button_layout", installer)
        self.assertIn("button_layout=O|HMC", themerc)
        self.assertIn("/general/button_layout", apply_settings)

    def test_shell_has_failure_supervision(self):
        service = self.text("config/lain-shell.service")
        self.assertIn("Restart=on-failure", service)
        self.assertIn("RestartSec=2", service)
        control = self.text("bin/lainctl")
        self.assertIn('Eww topbar window', control)
        self.assertIn('active-windows', control)
        self.assertIn('pgrep -u "$(id -u)" -x eww', control)
        self.assertIn('Plank window', control)

    def test_lite_never_starts_picom(self):
        session = self.text("bin/lain-session-start")
        self.assertIn("profile.json", session)
        self.assertRegex(session, r'profile.*high')
        self.assertNotRegex(session, r'picom\s*&')
        self.assertIn("lain-compositor stop", session)

    def test_no_legacy_theme_dependency(self):
        banned = "white" + "sur"
        for path in ROOT.rglob("*"):
            if path.is_file() and path.suffix not in {".png", ".zip", ".pyc"}:
                self.assertNotIn(banned, path.read_text(encoding="utf-8", errors="ignore").lower())

    def test_required_assets(self):
        for name in ("wallpaper.png", "lock.png", "terminal-art.png"):
            path = ROOT / "assets" / name
            self.assertGreater(path.stat().st_size, 1024)
        for name in ("desktop-login.wav", "message-new-instant.wav", "bell-terminal.wav"):
            path = ROOT / "assets/sounds/LAINTheme/stereo" / name
            self.assertGreater(path.stat().st_size, 1024)


if __name__ == "__main__":
    unittest.main()

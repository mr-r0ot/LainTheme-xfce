from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from lain_shell.command import desktop_exec
from lain_shell.models import Monitor, Window, group_windows, overlaps
from lain_shell.notifications import NotificationStore
from lain_shell.x11 import parse_wmctrl


class CommandTests(unittest.TestCase):
    def test_desktop_exec_drops_field_codes(self):
        self.assertEqual(desktop_exec('app --name "two words" %U'), ["app", "--name", "two words"])

    def test_desktop_exec_rejects_broken_quotes(self):
        self.assertEqual(desktop_exec("app 'broken"), [])


class WindowModelTests(unittest.TestCase):
    def test_wmctrl_parser(self):
        text = "0x04200007  2 host firefox.Firefox Browser title\ninvalid"
        windows = parse_wmctrl(text)
        self.assertEqual(len(windows), 1)
        self.assertEqual(windows[0].xid, 0x04200007)
        self.assertEqual(windows[0].desktop, 2)
        self.assertEqual(windows[0].wm_class, "firefox.Firefox")

    def test_pinned_and_running_are_one_group(self):
        window = Window(1, 0, "host", "firefox.Firefox", "Browser")
        metadata = {"firefox.desktop": ("Firefox", "firefox", ("Firefox", "firefox"))}
        groups = group_windows([window], ["firefox.desktop"], metadata)
        self.assertEqual(len(groups), 1)
        self.assertTrue(groups[0].pinned)
        self.assertEqual(groups[0].windows, [window])

    def test_unmatched_window_is_preserved(self):
        window = Window(2, 0, "host", "custom.App", "Custom")
        groups = group_windows([window], [], {})
        self.assertEqual(len(groups), 1)
        self.assertIsNone(groups[0].desktop_id)

    def test_overlap_is_monitor_local(self):
        monitor = Monitor(0, 1920, 0, 1920, 1080, True)
        covering = Window(1, 0, "h", "a.A", "A", geometry=(2000, 20, 800, 1060))
        other = Window(2, 0, "h", "b.B", "B", geometry=(100, 20, 800, 1060))
        self.assertTrue(overlaps(covering, monitor, 38, 58))
        self.assertFalse(overlaps(other, monitor, 38, 58))


class NotificationTests(unittest.TestCase):
    def test_replace_history_and_read_state(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "notifications.json"
            store = NotificationStore(path)
            first = store.notify("app", 0, "icon", "one", "body", [])
            replaced = store.notify("app", first.id, "icon", "two", "new", ["open", "Open"])
            self.assertEqual(first.id, replaced.id)
            self.assertEqual(len(store.items), 1)
            self.assertEqual(store.unread_count, 1)
            store.mark_read()
            self.assertEqual(store.unread_count, 0)
            reloaded = NotificationStore(path)
            self.assertEqual(reloaded.items[0].summary, "two")
            self.assertEqual(reloaded.items[0].actions, ["open", "Open"])

    def test_history_limit(self):
        with tempfile.TemporaryDirectory() as directory:
            store = NotificationStore(Path(directory) / "n.json", limit=3)
            for index in range(5):
                store.notify("app", 0, "", str(index), "", [])
            self.assertEqual([item.summary for item in store.items], ["2", "3", "4"])


if __name__ == "__main__":
    unittest.main()


#!/usr/bin/env python3
"""Render deterministic PNG fallbacks without network or SVG delegates."""
from __future__ import annotations

import math
import struct
import wave
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont


ROOT = Path(__file__).resolve().parents[1]


def font(size: int):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationMono-Regular.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()


def gradient(size: tuple[int, int], left=(8, 10, 18), right=(17, 20, 38)) -> Image.Image:
    width, height = size
    image = Image.new("RGB", size)
    pixels = image.load()
    for y in range(height):
        for x in range(width):
            ratio = (x / width + y / height) / 2
            pixels[x, y] = tuple(round(a + (b - a) * ratio) for a, b in zip(left, right))
    return image


def wallpaper() -> None:
    size = (2560, 1440)
    image = gradient(size)
    draw = ImageDraw.Draw(image, "RGBA")
    for x in range(0, size[0], 64):
        draw.line((x, 0, x, size[1]), fill=(101, 114, 160, 18))
    for y in range(0, size[1], 64):
        draw.line((0, y, size[0], y), fill=(101, 114, 160, 18))
    halo = Image.new("RGBA", size)
    hd = ImageDraw.Draw(halo, "RGBA")
    hd.ellipse((1300, 10, 2560, 1370), fill=(122, 101, 255, 80))
    halo = halo.filter(ImageFilter.GaussianBlur(120))
    image = Image.alpha_composite(image.convert("RGBA"), halo)
    draw = ImageDraw.Draw(image, "RGBA")
    center = (1930, 680)
    for radius in (250, 390, 460):
        draw.ellipse((center[0]-radius, center[1]-radius, center[0]+radius, center[1]+radius), outline=(127, 114, 255, 48), width=2)
    draw.line((1390, 680, 2470, 680), fill=(127, 114, 255, 48), width=2)
    draw.line((1930, 140, 1930, 1220), fill=(127, 114, 255, 48), width=2)
    # Original, abstract wireframe portrait.
    line = (216, 212, 255, 205)
    accent = (101, 220, 233, 230)
    draw.ellipse((1705, 290, 2205, 810), outline=line, width=8)
    draw.arc((1685, 205, 2235, 760), 190, 350, fill=(140, 125, 255, 230), width=18)
    draw.line((1770, 500, 1840, 500), fill=accent, width=8)
    draw.line((2055, 500, 2125, 500), fill=accent, width=8)
    draw.arc((1900, 555, 2020, 640), 20, 160, fill=line, width=6)
    draw.line((1770, 800, 1600, 1240), fill=line, width=10)
    draw.line((2140, 800, 2310, 1240), fill=line, width=10)
    draw.line((1865, 800, 1930, 930, 1995, 800), fill=accent, width=7)
    draw.text((150, 1110), "PRESENT DAY", font=font(44), fill=(217, 215, 255), spacing=8)
    draw.text((153, 1172), "PRESENT TIME", font=font(20), fill=accent)
    draw.line((150, 1225, 810, 1225), fill=(127, 114, 255, 180), width=3)
    draw.text((150, 1260), "LAINTheme / XFCE · connected to the wired", font=font(18), fill=(139, 145, 167))
    image.convert("RGB").save(ROOT / "assets/wallpaper.png", optimize=True)


def lock() -> None:
    size = (2560, 1440)
    image = gradient(size, (6, 7, 13), (23, 19, 45)).convert("RGBA")
    draw = ImageDraw.Draw(image, "RGBA")
    for radius in (350, 470):
        draw.ellipse((1280-radius, 650-radius, 1280+radius, 650+radius), outline=(140, 123, 255, 55), width=3)
    title = "LAIN"
    title_font = font(76)
    bbox = draw.textbbox((0, 0), title, font=title_font)
    draw.text(((2560-(bbox[2]-bbox[0]))/2, 570), title, font=title_font, fill=(239, 239, 255))
    subtitle = "AUTHENTICATION REQUIRED"
    sub_font = font(20)
    bbox = draw.textbbox((0, 0), subtitle, font=sub_font)
    draw.text(((2560-(bbox[2]-bbox[0]))/2, 700), subtitle, font=sub_font, fill=(101, 220, 233))
    draw.rounded_rectangle((990, 790, 1570, 794), radius=2, fill=(140, 123, 255, 160))
    footer = "PRESENT DAY · PRESENT TIME"
    bbox = draw.textbbox((0, 0), footer, font=font(17))
    draw.text(((2560-(bbox[2]-bbox[0]))/2, 1320), footer, font=font(17), fill=(119, 125, 148))
    image.convert("RGB").save(ROOT / "assets/lock.png", optimize=True)


def terminal() -> None:
    image = gradient((900, 540)).convert("RGBA")
    draw = ImageDraw.Draw(image, "RGBA")
    draw.text((54, 55), "LAIN OS", font=font(28), fill=(228, 226, 255))
    draw.text((54, 104), "wired://present-day", font=font(15), fill=(101, 220, 233))
    for radius in (155, 210):
        draw.ellipse((650-radius, 270-radius, 650+radius, 270+radius), outline=(119, 104, 232, 60), width=2)
    draw.ellipse((570, 100, 760, 320), outline=(220, 216, 255, 220), width=5)
    draw.arc((550, 55, 785, 330), 190, 350, fill=(136, 121, 255), width=12)
    draw.line((610, 195, 650, 195), fill=(101, 220, 233), width=6)
    draw.line((685, 195, 725, 195), fill=(101, 220, 233), width=6)
    draw.line((615, 320, 550, 500), fill=(194, 188, 255), width=7)
    draw.line((715, 320, 785, 500), fill=(194, 188, 255), width=7)
    draw.text((54, 205), "SYSTEM", font=font(16), fill=(119, 125, 148))
    draw.text((54, 245), "xfce / x11\nshell / connected\nprofile / adaptive", font=font(16), fill=(187, 184, 212), spacing=12)
    draw.text((54, 455), "No matter where you go, everyone's connected.", font=font(14), fill=(101, 220, 233))
    image.convert("RGB").save(ROOT / "assets/terminal-art.png", optimize=True)


def sound_theme() -> None:
    target = ROOT / "assets/sounds/LAINTheme/stereo"
    target.mkdir(parents=True, exist_ok=True)
    events = {
        "desktop-login.wav": ((440.0, 660.0), 0.42),
        "message-new-instant.wav": ((720.0, 920.0), 0.18),
        "bell-terminal.wav": ((540.0, 410.0), 0.20),
    }
    rate = 44100
    for name, (tones, duration) in events.items():
        frames = bytearray()
        count = int(rate * duration)
        for index in range(count):
            t = index / rate
            envelope = math.sin(math.pi * index / count) ** 2
            sample = sum(math.sin(2 * math.pi * tone * t) for tone in tones) / len(tones)
            frames.extend(struct.pack("<h", round(sample * envelope * 9000)))
        with wave.open(str(target / name), "wb") as output:
            output.setnchannels(1)
            output.setsampwidth(2)
            output.setframerate(rate)
            output.writeframes(frames)


if __name__ == "__main__":
    # Reference artwork is release input. Generate placeholders only when an
    # asset is absent so maintenance never silently replaces user-approved art.
    if not (ROOT / "assets/wallpaper.png").exists():
        wallpaper()
    if not (ROOT / "assets/lock.png").exists():
        lock()
    if not (ROOT / "assets/terminal-art.png").exists():
        terminal()
    sound_theme()

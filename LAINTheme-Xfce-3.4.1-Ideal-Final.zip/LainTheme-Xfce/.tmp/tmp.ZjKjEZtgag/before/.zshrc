original-zshrc

#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROFILE="lite"
DRY_RUN=0
INSTALL_PACKAGES=1
INSTALL_LIGHTDM=1
START_NOW=1
OH_MY_ZSH=1
SYSTEM_ROOT="${LAIN_SYSTEM_ROOT:-}"

while (($#)); do
  case "$1" in
    --profile) PROFILE="${2:-}"; shift 2 ;;
    --profile=*) PROFILE="${1#*=}"; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    --no-packages) INSTALL_PACKAGES=0; shift ;;
    --no-lightdm) INSTALL_LIGHTDM=0; shift ;;
    --no-start) START_NOW=0; shift ;;
    --skip-shell-network) OH_MY_ZSH=0; shift ;;
    -h|--help)
      printf 'Usage: %s [--profile lite|high] [--dry-run] [--no-packages] [--no-lightdm] [--no-start] [--skip-shell-network]\n' "$0"
      exit 0 ;;
    *) printf 'Unknown option: %s\n' "$1" >&2; exit 2 ;;
  esac
done

[[ "$PROFILE" == "lite" || "$PROFILE" == "high" ]] || { printf 'Profile must be lite or high.\n' >&2; exit 2; }

CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
BIN_HOME="$HOME/.local/bin"
PICTURES_DIR="$HOME/Pictures/LAINTheme"
DATA_DIR="$DATA_HOME/lain-theme"
CONFIG_DIR="$CONFIG_HOME/lain-theme"
STATE_DIR="$STATE_HOME/lain-theme"
AUTOSTART_DIR="$CONFIG_HOME/autostart"
BACKUP_ROOT="$STATE_DIR/backups/$(date +%Y%m%d-%H%M%S)-$$"
MANIFEST="$BACKUP_ROOT/manifest.tsv"
CURRENT_BACKUP="$STATE_DIR/current-backup"
INSTALL_STATE="$STATE_DIR/install-state"
PREVIOUS_BACKUP=""
if [[ -f "$CURRENT_BACKUP" ]]; then
  candidate="$(<"$CURRENT_BACKUP")"
  [[ -f "$candidate/manifest.tsv" ]] && PREVIOUS_BACKUP="$candidate"
fi
ROLLBACK_ARMED=0

step() { printf '\n[%02d/11] %s\n' "$1" "$2"; }
note() { printf '         %s\n' "$*"; }
run_mutation() {
  if ((DRY_RUN)); then printf '         DRY-RUN:'; printf ' %q' "$@"; printf '\n'; else "$@"; fi
}

display_manager_name() {
  if [[ -r "$SYSTEM_ROOT/etc/X11/default-display-manager" ]]; then
    basename "$(<"$SYSTEM_ROOT/etc/X11/default-display-manager")"
  else
    basename "$(readlink -f "$SYSTEM_ROOT/etc/systemd/system/display-manager.service" 2>/dev/null || true)"
  fi
}

stop_owned_process_for_path() {
  local needle="$1" proc pid
  for proc in /proc/[0-9]*/cmdline; do
    [[ -r "$proc" ]] || continue
    pid="${proc#/proc/}"; pid="${pid%/cmdline}"
    [[ "$pid" != "$$" ]] || continue
    [[ "$(stat -c %u "/proc/$pid" 2>/dev/null || true)" == "$(id -u)" ]] || continue
    tr '\0' ' ' <"$proc" 2>/dev/null | grep -Fq -- "$needle" || continue
    kill -TERM "$pid" 2>/dev/null || true
  done
}

backup_path() {
  local path="$1"
  local relative="${path#/}"
  local saved="$BACKUP_ROOT/user/$relative"
  if [[ -e "$path" || -L "$path" ]]; then
    printf 'E\t%s\n' "$path" >>"$MANIFEST"
    mkdir -p "$(dirname "$saved")"
    cp -a -- "$path" "$saved"
  else
    printf 'M\t%s\n' "$path" >>"$MANIFEST"
  fi
}

restore_user_backup() {
  local kind path saved
  [[ -f "$MANIFEST" ]] || return 0
  while IFS=$'\t' read -r kind path; do
    [[ -n "$path" ]] || continue
    saved="$BACKUP_ROOT/user/${path#/}"
    if [[ "$kind" == "E" ]]; then
      rm -rf -- "$path"
      mkdir -p "$(dirname "$path")"
      cp -a -- "$saved" "$path"
    else
      rm -rf -- "$path"
    fi
  done <"$MANIFEST"
}

restore_plank_backup() {
  local dump="$BACKUP_ROOT/plank.dconf"
  if [[ -s "$dump" ]] && command -v dconf >/dev/null 2>&1; then
    dconf load /net/launchpad/plank/ <"$dump" >/dev/null 2>&1 || true
  fi
}

restore_system_backup() {
  local system_backup="$BACKUP_ROOT/system"
  local system_manifest="$system_backup/manifest.tsv"
  [[ -f "$system_manifest" ]] || return 0
  local kind path key saved
  while IFS=$'\t' read -r kind path key; do
    [[ -n "$path" && -n "$key" ]] || continue
    saved="$system_backup/$key"
    sudo rm -rf -- "$path"
    if [[ "$kind" == E ]]; then
      sudo install -d -m 0755 "$(dirname "$path")"
      sudo cp -a -- "$saved" "$path"
    fi
  done <"$system_manifest"
}

backup_system_path() {
  local path="$1" key="$2" system_backup="$BACKUP_ROOT/system"
  mkdir -p "$system_backup"
  if sudo test -e "$path" || sudo test -L "$path"; then
    printf 'E\t%s\t%s\n' "$path" "$key" >>"$system_backup/manifest.tsv"
    sudo cp -a -- "$path" "$system_backup/$key"
  else
    printf 'M\t%s\t%s\n' "$path" "$key" >>"$system_backup/manifest.tsv"
  fi
}

merge_upgrade_backups() {
  local previous="$1" current="$2" kind path key
  while IFS=$'\t' read -r kind path; do
    [[ -n "$path" ]] || continue
    if ! grep -Fq $'\t'"$path" "$previous/manifest.tsv"; then
      printf '%s\t%s\n' "$kind" "$path" >>"$previous/manifest.tsv"
      if [[ "$kind" == E ]]; then
        mkdir -p "$previous/user/$(dirname "${path#/}")"
        cp -a -- "$current/user/${path#/}" "$previous/user/${path#/}"
      fi
    fi
  done <"$current/manifest.tsv"

  local previous_system="$previous/system" current_system="$current/system"
  mkdir -p "$previous_system"
  touch "$previous_system/manifest.tsv"
  # Migrate the 3.0 backup layout before adding the new seat and theme paths.
  if [[ -f "$previous_system/greeter.state" ]] && ! grep -Fq $'\t/etc/lightdm/lightdm-gtk-greeter.conf.d/90-lain-theme.conf\t' "$previous_system/manifest.tsv"; then
    kind="$(<"$previous_system/greeter.state")"
    printf '%s\t%s\t%s\n' "$kind" /etc/lightdm/lightdm-gtk-greeter.conf.d/90-lain-theme.conf greeter.conf >>"$previous_system/manifest.tsv"
  fi
  if [[ -f "$previous_system/wallpaper.state" ]] && ! grep -Fq $'\t/usr/local/share/backgrounds/lain-lock.png\t' "$previous_system/manifest.tsv"; then
    kind="$(<"$previous_system/wallpaper.state")"
    printf '%s\t%s\t%s\n' "$kind" /usr/local/share/backgrounds/lain-lock.png lain-lock.png >>"$previous_system/manifest.tsv"
  fi
  if [[ -f "$current_system/manifest.tsv" ]]; then
    while IFS=$'\t' read -r kind path key; do
      [[ -n "$path" && -n "$key" ]] || continue
      if ! grep -Fq $'\t'"$path"$'\t' "$previous_system/manifest.tsv"; then
        printf '%s\t%s\t%s\n' "$kind" "$path" "$key" >>"$previous_system/manifest.tsv"
        [[ "$kind" == E ]] && cp -a -- "$current_system/$key" "$previous_system/$key"
      fi
    done <"$current_system/manifest.tsv"
  fi
  # Keep the first pre-install Plank schema dump just like the user-file
  # manifest. A repair must never replace the rollback point with LAINTheme's
  # own dock values.
  if [[ ! -s "$previous/plank.dconf" && -s "$current/plank.dconf" ]]; then
    cp -a -- "$current/plank.dconf" "$previous/plank.dconf"
  fi
}

rollback_on_error() {
  local code=$?
  trap - ERR
  if ((ROLLBACK_ARMED && !DRY_RUN)); then
    printf '\n[ROLLBACK] Installation failed; restoring the captured user state.\n' >&2
    restore_system_backup || true
    restore_user_backup || true
    restore_plank_backup || true
    if [[ -n "$PREVIOUS_BACKUP" ]]; then printf '%s\n' "$PREVIOUS_BACKUP" >"$CURRENT_BACKUP"; else rm -f -- "$CURRENT_BACKUP"; fi
  fi
  exit "$code"
}
trap rollback_on_error ERR

step 1 "Preflight and target validation"
[[ -f "$PROJECT_ROOT/src/lain_shell/app.py" ]] || { note "Invalid release: shell source is missing"; exit 1; }
[[ -f "$PROJECT_ROOT/assets/wallpaper.png" ]] || { note "Invalid release: wallpaper is missing"; exit 1; }
[[ -f "$PROJECT_ROOT/theme/LAINTheme-Dark/gtk-3.0/gtk.css" ]] || { note "Invalid release: GTK theme is missing"; exit 1; }
if [[ "${XDG_CURRENT_DESKTOP:-XFCE}" != *XFCE* && "${XDG_CURRENT_DESKTOP:-XFCE}" != *Xfce* ]]; then
  note "Warning: this release targets XFCE/X11; installation continues for the next XFCE login."
fi
if [[ "${XDG_SESSION_TYPE:-x11}" != "x11" ]]; then
  note "Warning: the shell will stay inactive outside an X11 session."
fi
note "Profile: $PROFILE"

step 2 "Transactional backup"
if ((DRY_RUN)); then
  note "Would snapshot managed user files under $BACKUP_ROOT"
else
  mkdir -p "$BACKUP_ROOT" "$STATE_DIR"
  : >"$MANIFEST"
  if command -v dconf >/dev/null 2>&1; then
    dconf dump /net/launchpad/plank/ >"$BACKUP_ROOT/plank.dconf" 2>/dev/null || true
  fi
  for path in \
    "$DATA_DIR" "$CONFIG_DIR" "$DATA_HOME/sounds/LAINTheme" "$HOME/.themes/LAINTheme-Dark" \
    "$DATA_HOME/laintheme" "$CONFIG_HOME/laintheme" "$HOME/.cache/laintheme" "$CONFIG_HOME/plank" \
    "$PICTURES_DIR/lain-logo.svg" "$PICTURES_DIR/avatar.svg" "$PICTURES_DIR/wallpaper.png" \
    "$PICTURES_DIR/terminal-art.png" "$PICTURES_DIR/lock.png" \
    "$CONFIG_HOME/fontconfig/conf.d/50-lain-jetbrains-mono.conf" \
    "$BIN_HOME/lain-shell" "$BIN_HOME/lain-launcher" "$BIN_HOME/lain-terminal" \
    "$BIN_HOME/lain-eww" "$BIN_HOME/lain-hotkeys" \
    "$BIN_HOME/lain-lock" "$BIN_HOME/lain-session-start" "$BIN_HOME/lain-apply-settings" "$BIN_HOME/lain-compositor" "$BIN_HOME/lain-settings" "$BIN_HOME/lainctl" \
    "$BIN_HOME/lain-capture" "$BIN_HOME/lain-fetch" "$BIN_HOME/lain-notifyd" "$BIN_HOME/lain-repair" \
    "$BIN_HOME/lain-uninstall" "$BIN_HOME/laintheme" "$BIN_HOME/lainconfig" "$BIN_HOME/xflock4" \
    "$BIN_HOME/lain-window" "$BIN_HOME/lain-wifi" "$BIN_HOME/lain-theme-settings" \
    "$AUTOSTART_DIR/lain-shell.desktop" "$AUTOSTART_DIR/xfce4-panel.desktop" \
    "$AUTOSTART_DIR/lain-panel-suppress.desktop" "$AUTOSTART_DIR/laintheme-shell.desktop" \
    "$AUTOSTART_DIR/laintheme-notify.desktop" "$AUTOSTART_DIR/laintheme-compositor.desktop" \
    "$CONFIG_HOME/picom/laintheme.conf" \
    "$CONFIG_HOME/eww" "$CONFIG_HOME/sxhkd" "$CONFIG_HOME/dunst" "$CONFIG_HOME/rofi" "$CONFIG_HOME/kitty" "$CONFIG_HOME/copyq" \
    "$CONFIG_HOME/systemd/user/lain-shell.service" \
    "$CONFIG_HOME/xfce4/terminal/terminalrc" "$HOME/.zshrc" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-keyboard-shortcuts.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-terminal.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml"; do
    backup_path "$path"
  done
  ROLLBACK_ARMED=1
fi

step 3 "Dependencies (missing packages only)"
install_debian_packages() {
  local packages=(python3 python3-gi python3-xlib gir1.2-gtk-3.0 libglib2.0-bin dconf-cli wmctrl xdotool x11-utils network-manager bluez rfkill pulseaudio-utils brightnessctl ffmpeg xfconf xfce4-settings xfce4-terminal xfdesktop4 xfce4-screenshooter plank eww sxhkd dunst rofi kitty copyq blueman btop feh i3lock chafa git zsh zsh-autosuggestions zsh-syntax-highlighting fonts-jetbrains-mono papirus-icon-theme libnotify-bin)
  [[ "$PROFILE" == "high" ]] && packages+=(picom)
  if [[ "$INSTALL_LIGHTDM" == 1 ]] && { [[ -d "$SYSTEM_ROOT/etc/lightdm" ]] || [[ "$(display_manager_name)" == lightdm ]]; }; then
    packages+=(lightdm lightdm-gtk-greeter)
  fi
  local missing=() package
  for package in "${packages[@]}"; do dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q 'install ok installed' || missing+=("$package"); done
  if ((${#missing[@]})); then
    note "Installing ${#missing[@]} missing packages"
    run_mutation sudo apt-get update -qq
    run_mutation sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${missing[@]}"
  else
    note "All required packages already installed; apt update skipped"
  fi
}
install_arch_packages() {
  local packages=(python python-gobject python-xlib gtk3 glib2 dconf wmctrl xdotool xorg-xprop xorg-xwininfo xorg-xdpyinfo networkmanager bluez bluez-utils rfkill libpulse brightnessctl ffmpeg xfconf xfce4-settings xfce4-terminal xfdesktop plank eww sxhkd dunst rofi kitty copyq blueman btop feh i3lock chafa git zsh zsh-autosuggestions zsh-syntax-highlighting ttf-jetbrains-mono papirus-icon-theme libnotify)
  if [[ "$INSTALL_LIGHTDM" == 1 ]] && { [[ -d "$SYSTEM_ROOT/etc/lightdm" ]] || [[ "$(basename "$(readlink -f "$SYSTEM_ROOT/etc/systemd/system/display-manager.service" 2>/dev/null || true)")" == lightdm.service ]]; }; then
    packages+=(lightdm lightdm-gtk-greeter)
  fi
  [[ "$PROFILE" == "high" ]] && packages+=(picom)
  local missing=() package
  for package in "${packages[@]}"; do pacman -Q "$package" >/dev/null 2>&1 || missing+=("$package"); done
  ((${#missing[@]})) && run_mutation sudo pacman -S --needed --noconfirm "${missing[@]}" || note "All required packages already installed"
}
if ((INSTALL_PACKAGES)); then
  if command -v apt-get >/dev/null 2>&1; then install_debian_packages
  elif command -v pacman >/dev/null 2>&1; then install_arch_packages
  else note "Unsupported package manager; diagnose will report any missing runtime command"
  fi
else note "Package installation disabled"
fi

step 4 "Atomic application files"
if ((DRY_RUN)); then
  note "Would install shell, assets and commands into user directories"
else
  systemctl --user stop lain-shell.service >/dev/null 2>&1 || true
  command -v gapplication >/dev/null 2>&1 && gapplication quit io.github.laintheme.XfceShell >/dev/null 2>&1 || true
  stop_owned_process_for_path "$BIN_HOME/lain-shell"
  stop_owned_process_for_path "$BIN_HOME/lain-notifyd"
  stop_owned_process_for_path "$CONFIG_HOME/picom/laintheme.conf"
  staging="$DATA_DIR.staging-$$"
  rm -rf -- "$staging"
  mkdir -p "$staging" "$BIN_HOME"
  cp -a "$PROJECT_ROOT/src" "$PROJECT_ROOT/assets" "$PROJECT_ROOT/config" "$PROJECT_ROOT/theme" "$PROJECT_ROOT/bin" "$PROJECT_ROOT/install.sh" "$PROJECT_ROOT/uninstall.sh" "$staging/"
  [[ -d "$PROJECT_ROOT/oh-my-zsh" ]] && cp -a "$PROJECT_ROOT/oh-my-zsh" "$staging/" || true
  rm -rf -- "$DATA_DIR"
  mv -- "$staging" "$DATA_DIR"
  install -m 0755 "$PROJECT_ROOT"/bin/* "$BIN_HOME/"
  install -m 0755 "$PROJECT_ROOT/bin/lainctl" "$BIN_HOME/lainctl"
  mkdir -p "$DATA_HOME/sounds"
  cp -a "$PROJECT_ROOT/assets/sounds/LAINTheme" "$DATA_HOME/sounds/"
  mkdir -p "$PICTURES_DIR" "$CONFIG_DIR"
  for asset in lain-logo.svg avatar.svg wallpaper.png terminal-art.png lock.png; do
    [[ -e "$PICTURES_DIR/$asset" ]] || cp -a "$PROJECT_ROOT/assets/$asset" "$PICTURES_DIR/$asset"
  done
  if [[ ! -e "$CONFIG_DIR/settings.json" ]]; then
    cat >"$CONFIG_DIR/settings.json" <<'EOF'
{
  "pinned": ["exo-terminal-emulator.desktop", "thunar.desktop", "firefox.desktop"],
  "workspaces": 9,
  "dock_autohide": true,
  "panel_height": 38,
  "dock_height": 78
}
EOF
  fi
  mkdir -p "$HOME/.themes"
  rm -rf -- "$HOME/.themes/LAINTheme-Dark"
  cp -a "$PROJECT_ROOT/theme/LAINTheme-Dark" "$HOME/.themes/LAINTheme-Dark"
  mkdir -p "$CONFIG_HOME/fontconfig/conf.d"
  install -m 0644 "$PROJECT_ROOT/config/fontconfig/50-lain-jetbrains-mono.conf" "$CONFIG_HOME/fontconfig/conf.d/50-lain-jetbrains-mono.conf"
  command -v fc-cache >/dev/null 2>&1 && fc-cache -f >/dev/null 2>&1 || true
fi

step 5 "Lite/High compositor policy"
if ((DRY_RUN)); then
  note "Would write $PROFILE profile and compositor policy"
else
  mkdir -p "$CONFIG_DIR"
  printf '{"name":"%s"}\n' "$PROFILE" >"$CONFIG_DIR/profile.json"
  install -m 0644 "$PROJECT_ROOT/config/picom.conf" "$CONFIG_DIR/picom.conf"
  "$BIN_HOME/lain-compositor" stop >/dev/null 2>&1 || true
  if command -v xfconf-query >/dev/null 2>&1; then
    if [[ "$PROFILE" == "lite" ]]; then
      xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true >/dev/null 2>&1 || true
    fi
  fi
fi

step 6 "Panel replacement and autostart"
if ((DRY_RUN)); then
  note "Would disable only the stock XFCE panel autostart and enable LAINTheme Shell"
else
  mkdir -p "$AUTOSTART_DIR"
  systemctl --user disable --now lain-shell.service >/dev/null 2>&1 || true
  rm -f -- "$AUTOSTART_DIR/lain-panel-suppress.desktop" "$AUTOSTART_DIR/laintheme-shell.desktop" \
    "$AUTOSTART_DIR/laintheme-notify.desktop" "$AUTOSTART_DIR/laintheme-compositor.desktop" \
    "$CONFIG_HOME/picom/laintheme.conf"
  rm -rf -- "$DATA_HOME/laintheme" "$CONFIG_HOME/laintheme" "$HOME/.cache/laintheme"
  rm -f -- "$BIN_HOME/lain-capture" "$BIN_HOME/lain-fetch" "$BIN_HOME/lain-notifyd" "$BIN_HOME/lain-repair" \
    "$BIN_HOME/lain-uninstall" "$BIN_HOME/laintheme" "$BIN_HOME/lainconfig" "$BIN_HOME/xflock4" \
    "$BIN_HOME/lain-window" "$BIN_HOME/lain-wifi" "$BIN_HOME/lain-theme-settings"
  install -m 0644 "$PROJECT_ROOT/config/autostart/lain-shell.desktop" "$AUTOSTART_DIR/lain-shell.desktop"
  install -m 0644 "$PROJECT_ROOT/config/autostart/xfce4-panel.desktop" "$AUTOSTART_DIR/xfce4-panel.desktop"
  mkdir -p "$CONFIG_HOME/systemd/user"
  sed "s|@LAIN_SHELL@|$BIN_HOME/lain-shell|g" "$PROJECT_ROOT/config/lain-shell.service" >"$CONFIG_HOME/systemd/user/lain-shell.service"
  systemctl --user daemon-reload >/dev/null 2>&1 || true
  mkdir -p "$CONFIG_HOME/eww/lain-theme" "$CONFIG_HOME/sxhkd/lain-theme" "$CONFIG_HOME/dunst" "$CONFIG_HOME/rofi"
  cp -a "$PROJECT_ROOT/config/eww/lain-theme/." "$CONFIG_HOME/eww/lain-theme/"
  cp -a "$PROJECT_ROOT/config/sxhkd/lain-theme/." "$CONFIG_HOME/sxhkd/lain-theme/"
  install -m 0644 "$PROJECT_ROOT/config/dunst/dunstrc" "$CONFIG_HOME/dunst/dunstrc"
  install -m 0644 "$PROJECT_ROOT/config/rofi/lain-theme.rasi" "$CONFIG_HOME/rofi/lain-theme.rasi"
fi

step 7 "Workspaces and conflict-free shortcuts"
if ((DRY_RUN)); then
  note "Would bind Super+Z to LAIN launcher and Ctrl+Alt+L to LAIN lock"
elif command -v xfconf-query >/dev/null 2>&1; then
  xfconf-query -c xfwm4 -p /general/workspace_count -n -t int -s 9 >/dev/null 2>&1 || true
  shortcut_properties="$(xfconf-query -c xfce4-keyboard-shortcuts -l 2>/dev/null || true)"
  while IFS= read -r property; do
    [[ -n "$property" ]] || continue
    value="$(xfconf-query -c xfce4-keyboard-shortcuts -p "$property" 2>/dev/null || true)"
    case "$property" in
      *\<Super\>*space*|*\<Super\>)
        [[ "$value" == *xfce4-appfinder* || "$value" == *xfce4-popup-applicationsmenu* ]] && xfconf-query -c xfce4-keyboard-shortcuts -p "$property" -r >/dev/null 2>&1 || true ;;
    esac
  done <<<"$shortcut_properties"
  xfconf-query -c xfce4-keyboard-shortcuts -p '/commands/custom/<Super>z' -n -t string -s 'lain-launcher' >/dev/null 2>&1 || true
  xfconf-query -c xfce4-keyboard-shortcuts -p '/commands/custom/<Primary><Alt>l' -n -t string -s 'lain-lock' >/dev/null 2>&1 || true
  for workspace in {1..9}; do
    xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Super>$workspace" -n -t string -s "workspace_${workspace}_key" >/dev/null 2>&1 || true
  done
  xfconf-query -c xfce4-session -p /general/LockCommand -n -t string -s 'lain-lock' >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Net/SoundThemeName -n -t string -s 'LAINTheme' >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Net/EnableEventSounds -n -t bool -s true >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Net/ThemeName -n -t string -s 'LAINTheme-Dark' >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Net/IconThemeName -n -t string -s 'Papirus-Dark' >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Gtk/FontName -n -t string -s 'JetBrains Mono 10' >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Gtk/MonospaceFontName -n -t string -s 'JetBrains Mono 10' >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Net/FontName -n -t string -s 'JetBrains Mono 10' >/dev/null 2>&1 || true
  xfconf-query -c xfwm4 -p /general/theme -n -t string -s 'LAINTheme-Dark' >/dev/null 2>&1 || true
  xfconf-query -c xfwm4 -p /general/button_layout -n -t string -s 'O|HMC' >/dev/null 2>&1 || true
  xfconf-query -c xfwm4 -p /general/title_font -n -t string -s 'JetBrains Mono 10' >/dev/null 2>&1 || true
fi

step 8 "Desktop wallpaper and terminal profile"
if ((DRY_RUN)); then
  note "Would apply wallpaper to every existing XFCE monitor/workspace property"
else
  terminal_dir="$CONFIG_HOME/xfce4/terminal"
  mkdir -p "$terminal_dir"
  terminal_art="$PICTURES_DIR/terminal-art.png"
  [[ -s "$terminal_art" ]] || terminal_art="$DATA_DIR/assets/terminal-art.png"
  sed "s|@TERMINAL_ART@|$terminal_art|g" "$PROJECT_ROOT/config/xfce-terminal/terminalrc" >"$terminal_dir/terminalrc"
  mkdir -p "$CONFIG_HOME/kitty"
  sed "s|@TERMINAL_ART@|$terminal_art|g" "$PROJECT_ROOT/config/kitty/kitty.conf" >"$CONFIG_HOME/kitty/kitty.conf"
  if command -v xfconf-query >/dev/null 2>&1; then
    wallpaper_source="$PICTURES_DIR/wallpaper.png"
    [[ -s "$wallpaper_source" ]] || wallpaper_source="$DATA_DIR/assets/wallpaper.png"
    wallpaper_properties="$(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep '/last-image$' || true)"
    [[ -n "$wallpaper_properties" ]] || wallpaper_properties=/backdrop/screen0/monitor0/workspace0/last-image
    while IFS= read -r property; do
      [[ -n "$property" ]] || continue
      xfconf-query -c xfce4-desktop -p "$property" -n -t string -s "$wallpaper_source" >/dev/null 2>&1 || true
      style_property="${property%/last-image}/image-style"
      xfconf-query -c xfce4-desktop -p "$style_property" -n -t int -s 5 >/dev/null 2>&1 || true
    done <<<"$wallpaper_properties"
    xfdesktop --reload >/dev/null 2>&1 || true
    # Xfce Terminal 1.1+ uses xfconf; terminalrc remains the older-version fallback.
    xfconf-query -c xfce4-terminal -p /font-name -n -t string -s 'JetBrains Mono 11' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /run-custom-command -n -t bool -s true >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /custom-command -n -t string -s 'zsh' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /color-foreground -n -t string -s '#E8EAF2' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /color-background -n -t string -s '#080A12' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /background-mode -n -t string -s 'TERMINAL_BACKGROUND_IMAGE' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /background-image-file -n -t string -s "$terminal_art" >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /background-image-style -n -t string -s 'TERMINAL_BACKGROUND_STYLE_SCALED' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /background-darkness -n -t double -s 0.86 >/dev/null 2>&1 || true
  fi
fi

step 9 "Zsh, prompt and optional Oh My Zsh"
if ((DRY_RUN)); then
  note "Would install an isolated .zshrc and private Oh My Zsh tree"
else
  mkdir -p "$CONFIG_DIR/zsh"
  install -m 0644 "$PROJECT_ROOT/config/zsh/lain.zsh" "$CONFIG_DIR/zsh/lain.zsh"
  install -m 0644 "$PROJECT_ROOT/config/zsh/lain.zsh-theme" "$CONFIG_DIR/zsh/lain.zsh-theme"
  if ((OH_MY_ZSH)) && command -v git >/dev/null 2>&1 && [[ ! -d "$DATA_DIR/oh-my-zsh/.git" ]]; then
    note "Trying shallow Oh My Zsh install (20-second limit)"
    timeout 20 git clone --depth=1 https://github.com/ohmyzsh/ohmyzsh.git "$DATA_DIR/oh-my-zsh" >/dev/null 2>&1 || note "Network unavailable; packaged shell integration remains active"
  fi
  if [[ -d "$DATA_DIR/oh-my-zsh" ]]; then
    mkdir -p "$DATA_DIR/oh-my-zsh/custom/themes"
    install -m 0644 "$PROJECT_ROOT/config/zsh/lain.zsh-theme" "$DATA_DIR/oh-my-zsh/custom/themes/lain.zsh-theme"
  fi
  install -m 0644 "$PROJECT_ROOT/config/zsh/zshrc" "$HOME/.zshrc"
fi

step 10 "Secure session lock and real LightDM login"
if ((DRY_RUN)); then
  note "Would install LightDM GTK greeter override with rollback metadata"
elif ((INSTALL_LIGHTDM)); then
  command -v sudo >/dev/null 2>&1 || { note "ERROR: sudo is required for the real login screen"; false; }
  command -v lightdm >/dev/null 2>&1 || { note "ERROR: LightDM is unavailable; use --no-lightdm only if you accept no boot-login theming"; false; }
  active_dm="$(display_manager_name)"
  [[ -z "$active_dm" || "$active_dm" == lightdm || "$active_dm" == lightdm.service ]] || { note "ERROR: active display manager is $active_dm, not LightDM; refusing an unsafe automatic switch"; false; }
  system_backup="$BACKUP_ROOT/system"
  mkdir -p "$system_backup"
  sudo rm -f -- "$system_backup/manifest.tsv"
  seat_conf="$SYSTEM_ROOT/etc/lightdm/lightdm.conf.d/90-lain-theme.conf"
  greeter_conf="$SYSTEM_ROOT/etc/lightdm/lightdm-gtk-greeter.conf.d/90-lain-theme.conf"
  system_wallpaper="$SYSTEM_ROOT/usr/local/share/backgrounds/lain-lock.png"
  system_theme="$SYSTEM_ROOT/usr/local/share/themes/LAINTheme-Dark"
  backup_system_path "$seat_conf" seat.conf
  backup_system_path "$greeter_conf" greeter.conf
  backup_system_path "$system_wallpaper" lain-lock.png
  backup_system_path "$system_theme" LAINTheme-Dark
  sudo install -d -m 0755 "$SYSTEM_ROOT/etc/lightdm/lightdm.conf.d" "$SYSTEM_ROOT/etc/lightdm/lightdm-gtk-greeter.conf.d" "$SYSTEM_ROOT/usr/local/share/backgrounds" "$SYSTEM_ROOT/usr/local/share/themes"
  lock_source="$PICTURES_DIR/lock.png"
  [[ -s "$lock_source" ]] || lock_source="$PROJECT_ROOT/assets/lock.png"
  sudo install -m 0644 "$lock_source" "$system_wallpaper"
  sudo rm -rf -- "$system_theme"
  sudo cp -a "$PROJECT_ROOT/theme/LAINTheme-Dark" "$system_theme"
  printf '[Seat:*]\ngreeter-session=lightdm-gtk-greeter\n' | sudo tee "$seat_conf" >/dev/null
  printf '[greeter]\nbackground=/usr/local/share/backgrounds/lain-lock.png\nuser-background=false\ntheme-name=LAINTheme-Dark\nicon-theme-name=Papirus-Dark\nfont-name=JetBrains Mono 10\nclock-format=%%A · %%d %%B · %%H:%%M\nindicators=~host;~spacer;~clock;~spacer;~session;~language;~a11y;~power\nposition=50%%,center 50%%,center\n' | sudo tee "$greeter_conf" >/dev/null
  sudo chown -R "$(id -u):$(id -g)" "$system_backup" 2>/dev/null || true
  note "LightDM login configured; it will appear after logout/reboot (display manager was not restarted)"
else
  note "LightDM integration explicitly disabled; secure session lock remains installed"
fi

step 11 "Validation and session activation"
if ((DRY_RUN)); then
  note "Dry run complete; no files were changed"
  trap - ERR
  exit 0
fi
if [[ -n "$PREVIOUS_BACKUP" ]]; then
  # Preserve the first pre-install snapshot across upgrades and repairs.
  merge_upgrade_backups "$PREVIOUS_BACKUP" "$BACKUP_ROOT"
  ACTIVE_BACKUP="$PREVIOUS_BACKUP"
  UPGRADE_STAGING="$BACKUP_ROOT"
else
  ACTIVE_BACKUP="$BACKUP_ROOT"
  UPGRADE_STAGING=""
fi
printf '%s\n' "$ACTIVE_BACKUP" >"$CURRENT_BACKUP"
if ((START_NOW)) && [[ -n "${DISPLAY:-}" ]]; then
  "$BIN_HOME/lain-session-start" >/dev/null 2>&1 &
  healthy=0
  for _ in {1..24}; do
    if "$BIN_HOME/lainctl" health --quiet; then healthy=1; break; fi
    sleep 0.25
  done
  ((healthy)) || { note "ERROR: shell windows did not become healthy; rolling back"; false; }
fi
if ! "$BIN_HOME/lainctl" diagnose --quiet; then
  note "Installed, but runtime diagnostics found issues. Run: lainctl diagnose"
else
  note "Runtime diagnostics passed"
fi
cat >"$INSTALL_STATE" <<EOF
PROFILE=$PROFILE
BACKUP_ROOT=$ACTIVE_BACKUP
VERSION=3.2.0
EOF
chmod 600 "$INSTALL_STATE"
[[ -n "$UPGRADE_STAGING" ]] && rm -rf -- "$UPGRADE_STAGING"
ROLLBACK_ARMED=0
trap - ERR
printf '\n[DONE] LAINTheme-Xfce 3.2.0 installed with profile %s.\n' "$PROFILE"

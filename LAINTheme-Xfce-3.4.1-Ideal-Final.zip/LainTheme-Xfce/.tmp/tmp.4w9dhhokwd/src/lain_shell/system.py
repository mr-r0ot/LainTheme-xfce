from __future__ import annotations

import json
import os
import re
import signal
import time
from dataclasses import dataclass
from pathlib import Path

from .command import Result, available, run, spawn
from .config import RUNTIME_DIR, STATE_DIR


@dataclass(frozen=True)
class Metrics:
    cpu_percent: int
    memory_percent: int
    disk_percent: int
    battery_percent: int | None
    charging: bool


@dataclass(frozen=True)
class WifiNetwork:
    active: bool
    ssid: str
    security: str
    signal: int


@dataclass(frozen=True)
class BluetoothDevice:
    address: str
    name: str
    paired: bool = False
    trusted: bool = False
    connected: bool = False


_last_cpu: tuple[int, int] | None = None


def _cpu_percent() -> int:
    global _last_cpu
    try:
        line = Path("/proc/stat").read_text(encoding="ascii").splitlines()[0]
        values = [int(value) for value in line.split()[1:]]
    except (OSError, ValueError, IndexError):
        return 0
    idle = values[3] + (values[4] if len(values) > 4 else 0)
    total = sum(values)
    current = (idle, total)
    if _last_cpu is None:
        _last_cpu = current
        return 0
    idle_delta = idle - _last_cpu[0]
    total_delta = total - _last_cpu[1]
    _last_cpu = current
    return max(0, min(100, round(100 * (1 - idle_delta / total_delta)))) if total_delta else 0


def _memory_percent() -> int:
    try:
        entries = {}
        for line in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
            key, value = line.split(":", 1)
            entries[key] = int(value.split()[0])
        return round(100 * (1 - entries["MemAvailable"] / entries["MemTotal"]))
    except (OSError, ValueError, KeyError):
        return 0


def _disk_percent() -> int:
    try:
        usage = os.statvfs(Path.home())
        total = usage.f_blocks * usage.f_frsize
        available_bytes = usage.f_bavail * usage.f_frsize
        return round(100 * (1 - available_bytes / total)) if total else 0
    except OSError:
        return 0


def _battery() -> tuple[int | None, bool]:
    capacities: list[int] = []
    charging = False
    for path in Path("/sys/class/power_supply").glob("BAT*"):
        try:
            capacities.append(int((path / "capacity").read_text().strip()))
            charging |= (path / "status").read_text().strip().lower() == "charging"
        except (OSError, ValueError):
            continue
    return (round(sum(capacities) / len(capacities)), charging) if capacities else (None, False)


def metrics() -> Metrics:
    battery, charging = _battery()
    return Metrics(_cpu_percent(), _memory_percent(), _disk_percent(), battery, charging)


def wifi_enabled() -> bool:
    result = run(["nmcli", "-t", "-f", "WIFI", "general"], timeout=3)
    return result.ok and result.stdout.lower() == "enabled"


def set_wifi(enabled: bool) -> Result:
    return run(["nmcli", "radio", "wifi", "on" if enabled else "off"], timeout=8)


def scan_wifi() -> list[WifiNetwork]:
    run(["nmcli", "device", "wifi", "rescan"], timeout=12)
    result = run(["nmcli", "-t", "--escape", "yes", "-f", "IN-USE,SSID,SECURITY,SIGNAL", "device", "wifi", "list", "--rescan", "yes"], timeout=15)
    networks: dict[str, WifiNetwork] = {}
    for line in result.stdout.splitlines():
        fields = re.split(r"(?<!\\):", line)
        if len(fields) < 4:
            continue
        active, ssid, security, signal_value = fields[:4]
        ssid = ssid.replace(r"\:", ":").replace(r"\\", "\\")
        if not ssid:
            continue
        try:
            signal_level = int(signal_value)
        except ValueError:
            signal_level = 0
        candidate = WifiNetwork(active == "*", ssid, security or "Open", signal_level)
        if ssid not in networks or candidate.signal > networks[ssid].signal:
            networks[ssid] = candidate
    return sorted(networks.values(), key=lambda item: (not item.active, -item.signal, item.ssid.lower()))


def connect_wifi(ssid: str, password: str = "") -> Result:
    args = ["nmcli", "--wait", "20", "device", "wifi", "connect", ssid]
    if password:
        args.extend(["password", password])
    return run(args, timeout=25)


def disconnect_wifi() -> Result:
    result = run(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device"], timeout=4)
    for line in result.stdout.splitlines():
        parts = line.split(":", 2)
        if len(parts) == 3 and parts[1] == "wifi" and parts[2].startswith("connected"):
            return run(["nmcli", "device", "disconnect", parts[0]], timeout=10)
    return Result(("nmcli",), 0)


def bluetooth_enabled() -> bool:
    result = run(["bluetoothctl", "show"], timeout=4)
    return "Powered: yes" in result.stdout


def set_bluetooth(enabled: bool) -> Result:
    return run(["bluetoothctl", "power", "on" if enabled else "off"], timeout=8)


def scan_bluetooth(seconds: int = 5) -> list[BluetoothDevice]:
    run(["bluetoothctl", "--timeout", str(max(1, seconds)), "scan", "on"], timeout=seconds + 3)
    result = run(["bluetoothctl", "devices"], timeout=5)
    devices: list[BluetoothDevice] = []
    for line in result.stdout.splitlines():
        match = re.match(r"Device\s+([0-9A-Fa-f:]{17})\s+(.+)", line)
        if not match:
            continue
        address, name = match.groups()
        info = run(["bluetoothctl", "info", address], timeout=4).stdout
        devices.append(BluetoothDevice(
            address, name,
            paired="Paired: yes" in info,
            trusted="Trusted: yes" in info,
            connected="Connected: yes" in info,
        ))
    return sorted(devices, key=lambda item: (not item.connected, not item.paired, item.name.lower()))


def connect_bluetooth(address: str) -> Result:
    info = run(["bluetoothctl", "info", address], timeout=4).stdout
    if "Paired: yes" not in info:
        paired = run(["bluetoothctl", "--timeout", "25", "pair", address], timeout=28)
        if not paired.ok:
            return paired
    trusted = run(["bluetoothctl", "trust", address], timeout=7)
    if not trusted.ok:
        return trusted
    return run(["bluetoothctl", "--timeout", "15", "connect", address], timeout=18)


def disconnect_bluetooth(address: str) -> Result:
    return run(["bluetoothctl", "disconnect", address], timeout=10)


def airplane_enabled() -> bool:
    if available("rfkill"):
        result = run(["rfkill", "-J"], timeout=4)
        try:
            devices = json.loads(result.stdout).get("rfkilldevices", [])
            radios = [item for item in devices if item.get("type") in {"wlan", "bluetooth"}]
            return bool(radios) and all(item.get("soft") == "blocked" for item in radios)
        except (ValueError, AttributeError):
            pass
    return not wifi_enabled() and not bluetooth_enabled()


def set_airplane(enabled: bool) -> Result:
    if available("rfkill"):
        return run(["rfkill", "block" if enabled else "unblock", "all"], timeout=8)
    wifi = set_wifi(not enabled)
    bluetooth = set_bluetooth(not enabled)
    return wifi if not wifi.ok else bluetooth


def volume() -> int:
    if available("wpctl"):
        result = run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], timeout=3)
        match = re.search(r"Volume:\s+([0-9.]+)", result.stdout)
        return round(float(match.group(1)) * 100) if match else 0
    result = run(["pactl", "get-sink-volume", "@DEFAULT_SINK@"], timeout=3)
    match = re.search(r"(\d+)%", result.stdout)
    return int(match.group(1)) if match else 0


def set_volume(percent: int) -> Result:
    value = max(0, min(150, int(percent)))
    if available("wpctl"):
        return run(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{value}%"], timeout=4)
    return run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{value}%"], timeout=4)


def brightness() -> int:
    result = run(["brightnessctl", "-m"], timeout=3)
    fields = result.stdout.split(",")
    if len(fields) >= 4:
        try:
            return int(fields[3].rstrip("%"))
        except ValueError:
            pass
    return 0


def set_brightness(percent: int) -> Result:
    return run(["brightnessctl", "set", f"{max(1, min(100, int(percent)))}%"], timeout=5)


def take_screenshot() -> Result:
    pictures = Path.home() / "Pictures" / "Screenshots"
    pictures.mkdir(parents=True, exist_ok=True)
    target = pictures / time.strftime("Screenshot-%Y%m%d-%H%M%S.png")
    if available("xfce4-screenshooter"):
        return run(["xfce4-screenshooter", "-f", "-s", str(target)], timeout=15)
    if available("maim"):
        return run(["maim", str(target)], timeout=15)
    if available("import"):
        return run(["import", "-window", "root", str(target)], timeout=15)
    return Result(("screenshot",), 127, stderr="No screenshot backend installed")


def _record_pid_path() -> Path:
    return RUNTIME_DIR / "recording.pid"


def recording_active() -> bool:
    path = _record_pid_path()
    try:
        pid = int(path.read_text().strip())
        os.kill(pid, 0)
        return True
    except (OSError, ValueError):
        path.unlink(missing_ok=True)
        return False


def start_recording() -> Result:
    if recording_active():
        return Result(("ffmpeg",), 1, stderr="Recording already active")
    if not available("ffmpeg"):
        return Result(("ffmpeg",), 127, stderr="ffmpeg is not installed")
    videos = Path.home() / "Videos" / "Recordings"
    videos.mkdir(parents=True, exist_ok=True)
    target = videos / time.strftime("Recording-%Y%m%d-%H%M%S.mkv")
    display = os.environ.get("DISPLAY", ":0.0")
    geometry = run(["xdpyinfo"], timeout=3).stdout
    match = re.search(r"dimensions:\s+(\d+x\d+)", geometry)
    size = match.group(1) if match else "1920x1080"
    encoder = "libx264" if "libx264" in run(["ffmpeg", "-hide_banner", "-encoders"], timeout=8).stdout else "mpeg4"
    args = [
        "ffmpeg", "-nostdin", "-y", "-f", "x11grab", "-framerate", "30",
        "-video_size", size, "-i", f"{display}+0,0", "-c:v", encoder,
    ]
    if encoder == "libx264":
        args.extend(["-preset", "veryfast", "-crf", "23"])
    else:
        args.extend(["-q:v", "5"])
    args.append(str(target))
    proc = spawn(args)
    time.sleep(0.35)
    if proc.poll() is not None:
        return Result(("ffmpeg",), proc.returncode or 1, stderr="ffmpeg exited during startup")
    _record_pid_path().write_text(str(proc.pid), encoding="ascii")
    (STATE_DIR / "last-recording").write_text(str(target), encoding="utf-8")
    return Result(("ffmpeg",), 0, stdout=str(target))


def stop_recording() -> Result:
    path = _record_pid_path()
    try:
        pid = int(path.read_text().strip())
        os.kill(pid, signal.SIGINT)
        for _ in range(30):
            try:
                os.kill(pid, 0)
            except OSError:
                break
            time.sleep(0.1)
        else:
            os.kill(pid, signal.SIGTERM)
        path.unlink(missing_ok=True)
        return Result(("ffmpeg",), 0)
    except (OSError, ValueError) as exc:
        path.unlink(missing_ok=True)
        return Result(("ffmpeg",), 1, stderr=str(exc))

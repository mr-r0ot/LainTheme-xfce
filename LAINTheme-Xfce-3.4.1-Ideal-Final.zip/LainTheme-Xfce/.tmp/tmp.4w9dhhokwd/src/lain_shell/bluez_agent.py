from __future__ import annotations

from typing import Callable

from gi.repository import Gio, GLib, Gtk


AGENT_PATH = "/io/github/laintheme/BluetoothAgent"
AGENT_XML = """
<node>
  <interface name="org.bluez.Agent1">
    <method name="Release"/>
    <method name="RequestPinCode"><arg direction="in" type="o"/><arg direction="out" type="s"/></method>
    <method name="DisplayPinCode"><arg direction="in" type="o"/><arg direction="in" type="s"/></method>
    <method name="RequestPasskey"><arg direction="in" type="o"/><arg direction="out" type="u"/></method>
    <method name="DisplayPasskey"><arg direction="in" type="o"/><arg direction="in" type="u"/><arg direction="in" type="q"/></method>
    <method name="RequestConfirmation"><arg direction="in" type="o"/><arg direction="in" type="u"/></method>
    <method name="RequestAuthorization"><arg direction="in" type="o"/></method>
    <method name="AuthorizeService"><arg direction="in" type="o"/><arg direction="in" type="s"/></method>
    <method name="Cancel"/>
  </interface>
</node>
"""


class BluezAgent:
    def __init__(self, parent: Callable[[], Gtk.Window | None]):
        self.parent = parent
        self.connection = None
        self.registration_id = 0
        self.manager = None

    def start(self) -> None:
        try:
            self.connection = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
            interface = Gio.DBusNodeInfo.new_for_xml(AGENT_XML).interfaces[0]
            self.registration_id = self.connection.register_object(
                AGENT_PATH, interface, self._method_call, None, None
            )
            self.manager = Gio.DBusProxy.new_sync(
                self.connection, Gio.DBusProxyFlags.NONE, None,
                "org.bluez", "/org/bluez", "org.bluez.AgentManager1", None,
            )
            self.manager.call_sync(
                "RegisterAgent", GLib.Variant("(os)", (AGENT_PATH, "KeyboardDisplay")),
                Gio.DBusCallFlags.NONE, 5000, None,
            )
            self.manager.call_sync(
                "RequestDefaultAgent", GLib.Variant("(o)", (AGENT_PATH,)),
                Gio.DBusCallFlags.NONE, 5000, None,
            )
        except GLib.Error:
            self.stop()

    def stop(self) -> None:
        if self.manager:
            try:
                self.manager.call_sync(
                    "UnregisterAgent", GLib.Variant("(o)", (AGENT_PATH,)),
                    Gio.DBusCallFlags.NONE, 3000, None,
                )
            except GLib.Error:
                pass
        if self.connection and self.registration_id:
            self.connection.unregister_object(self.registration_id)
        self.registration_id = 0
        self.manager = None
        self.connection = None

    @staticmethod
    def _device_name(path: str) -> str:
        return path.rsplit("/", 1)[-1].removeprefix("dev_").replace("_", ":")

    def _entry_dialog(self, title: str, prompt: str, numeric: bool = False) -> str | None:
        dialog = Gtk.Dialog(title=title, transient_for=self.parent(), modal=True)
        dialog.add_button("Reject", Gtk.ResponseType.CANCEL)
        dialog.add_button("Confirm", Gtk.ResponseType.OK)
        box = dialog.get_content_area()
        label = Gtk.Label(label=prompt, xalign=0)
        label.set_margin_top(12)
        label.set_margin_start(12)
        label.set_margin_end(12)
        entry = Gtk.Entry(visibility=False)
        entry.set_input_purpose(Gtk.InputPurpose.DIGITS if numeric else Gtk.InputPurpose.PASSWORD)
        entry.set_activates_default(True)
        entry.set_margin_top(8)
        entry.set_margin_bottom(12)
        entry.set_margin_start(12)
        entry.set_margin_end(12)
        box.pack_start(label, False, False, 0)
        box.pack_start(entry, False, False, 0)
        dialog.set_default_response(Gtk.ResponseType.OK)
        dialog.show_all()
        response = dialog.run()
        value = entry.get_text().strip()
        dialog.destroy()
        return value if response == Gtk.ResponseType.OK and value else None

    def _confirm(self, title: str, message: str) -> bool:
        dialog = Gtk.MessageDialog(
            transient_for=self.parent(), modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=title,
        )
        dialog.format_secondary_text(message)
        accepted = dialog.run() == Gtk.ResponseType.YES
        dialog.destroy()
        return accepted

    @staticmethod
    def _reject(invocation) -> None:
        invocation.return_dbus_error("org.bluez.Error.Rejected", "Pairing rejected")

    def _method_call(self, _connection, _sender, _path, _interface, method, parameters, invocation) -> None:
        values = parameters.unpack()
        device = self._device_name(values[0]) if values else "Bluetooth device"
        if method in {"Release", "Cancel"}:
            invocation.return_value(None)
            return
        if method == "RequestPinCode":
            pin = self._entry_dialog("Bluetooth pairing", f"Enter the PIN shown by {device}")
            invocation.return_value(GLib.Variant("(s)", (pin,))) if pin else self._reject(invocation)
            return
        if method == "RequestPasskey":
            passkey = self._entry_dialog("Bluetooth pairing", f"Enter the numeric passkey for {device}", True)
            if passkey and passkey.isdigit() and int(passkey) <= 999999:
                invocation.return_value(GLib.Variant("(u)", (int(passkey),)))
            else:
                self._reject(invocation)
            return
        if method == "RequestConfirmation":
            passkey = values[1]
            if self._confirm("Confirm Bluetooth pairing", f"Does {device} show {passkey:06d}?"):
                invocation.return_value(None)
            else:
                self._reject(invocation)
            return
        if method in {"RequestAuthorization", "AuthorizeService"}:
            if self._confirm("Authorize Bluetooth device", f"Allow access for {device}?"):
                invocation.return_value(None)
            else:
                self._reject(invocation)
            return
        if method in {"DisplayPinCode", "DisplayPasskey"}:
            code = values[1]
            self._show_code(device, f"{code:06d}" if isinstance(code, int) else str(code))
            invocation.return_value(None)
            return
        invocation.return_dbus_error("org.bluez.Error.NotSupported", method)

    def _show_code(self, device: str, code: str) -> None:
        dialog = Gtk.MessageDialog(
            transient_for=self.parent(), modal=False,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=f"Bluetooth code: {code}",
        )
        dialog.format_secondary_text(f"Enter this code on {device}.")
        dialog.connect("response", lambda widget, _response: widget.destroy())
        dialog.show_all()


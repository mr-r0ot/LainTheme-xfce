from __future__ import annotations

import re
from dataclasses import replace

from .command import run
from .models import Monitor, Window


WINDOW_RE = re.compile(r"^(0x[0-9a-fA-F]+)\s+(-?\d+)\s+(\S+)\s+(\S+)\s+(.*)$")
GEOMETRY_RE = re.compile(r"Position:\s+(-?\d+),(-?\d+).*Geometry:\s+(\d+)x(\d+)", re.S)


def parse_wmctrl(text: str) -> list[Window]:
    windows: list[Window] = []
    for line in text.splitlines():
        match = WINDOW_RE.match(line.strip())
        if not match:
            continue
        xid, desktop, host, wm_class, title = match.groups()
        if desktop == "-1" and wm_class in {"lain-shell.Lain-shell", "lain-shell"}:
            continue
        windows.append(Window(int(xid, 16), int(desktop), host, wm_class, title))
    return windows


def list_windows() -> list[Window]:
    result = run(["wmctrl", "-lx"], timeout=3)
    if not result.ok:
        return []
    windows = parse_wmctrl(result.stdout)
    active_result = run(["xprop", "-root", "_NET_ACTIVE_WINDOW"], timeout=2)
    active_xid = 0
    match = re.search(r"0x[0-9a-fA-F]+", active_result.stdout)
    if match:
        active_xid = int(match.group(0), 16)
    enriched: list[Window] = []
    for item in windows:
        state = run(["xprop", "-id", hex(item.xid), "_NET_WM_STATE", "_NET_WM_DESKTOP", "_NET_WM_PID"], timeout=1.5)
        geometry = run(["xwininfo", "-id", hex(item.xid)], timeout=1.5)
        state_text = state.stdout
        if "_NET_WM_STATE_SKIP_TASKBAR" in state_text:
            continue
        geo_match = GEOMETRY_RE.search(geometry.stdout)
        geo = tuple(map(int, geo_match.groups())) if geo_match else None
        pid_match = re.search(r"_NET_WM_PID\(CARDINAL\) = (\d+)", state_text)
        enriched.append(replace(
            item,
            active=item.xid == active_xid,
            minimized="_NET_WM_STATE_HIDDEN" in state_text,
            urgent="_NET_WM_STATE_DEMANDS_ATTENTION" in state_text,
            fullscreen="_NET_WM_STATE_FULLSCREEN" in state_text,
            maximized=("_NET_WM_STATE_MAXIMIZED_VERT" in state_text and
                       "_NET_WM_STATE_MAXIMIZED_HORZ" in state_text),
            geometry=geo,
            pid=int(pid_match.group(1)) if pid_match else None,
        ))
    return enriched


def activate_window(xid: int) -> bool:
    return run(["wmctrl", "-ia", hex(xid)], timeout=2).ok


def close_window(xid: int) -> bool:
    return run(["wmctrl", "-ic", hex(xid)], timeout=2).ok


def switch_workspace(index: int) -> bool:
    return run(["wmctrl", "-s", str(index)], timeout=2).ok


def active_workspace() -> int:
    result = run(["wmctrl", "-d"], timeout=2)
    for line in result.stdout.splitlines():
        parts = line.split()
        if len(parts) > 1 and parts[1] == "*":
            return int(parts[0])
    return 0


def set_strut(gdk_window, monitor: Monitor, *, top: int = 0, bottom: int = 0) -> None:
    """Set EWMH struts in root coordinates, including partial ranges."""
    try:
        from Xlib import X, display
    except ImportError:
        return
    xid = gdk_window.get_xid()
    dsp = display.Display()
    try:
        window = dsp.create_resource_object("window", xid)
        atom_partial = dsp.intern_atom("_NET_WM_STRUT_PARTIAL")
        atom_strut = dsp.intern_atom("_NET_WM_STRUT")
        cardinal = dsp.intern_atom("CARDINAL")
        root_height = dsp.screen().height_in_pixels
        top_value = monitor.y + top if top else 0
        bottom_value = root_height - monitor.y - monitor.height + bottom if bottom else 0
        partial = [
            0, 0, top_value, bottom_value,
            0, 0, 0, 0,
            monitor.x, monitor.x + monitor.width - 1,
            monitor.x, monitor.x + monitor.width - 1,
        ]
        window.change_property(atom_partial, cardinal, 32, partial, X.PropModeReplace)
        window.change_property(atom_strut, cardinal, 32, [0, 0, top_value, bottom_value], X.PropModeReplace)
        dsp.sync()
    finally:
        dsp.close()


def clear_strut(gdk_window) -> None:
    try:
        from Xlib import X, display
    except ImportError:
        return
    dsp = display.Display()
    try:
        window = dsp.create_resource_object("window", gdk_window.get_xid())
        cardinal = dsp.intern_atom("CARDINAL")
        window.change_property(dsp.intern_atom("_NET_WM_STRUT_PARTIAL"), cardinal, 32, [0] * 12, X.PropModeReplace)
        window.change_property(dsp.intern_atom("_NET_WM_STRUT"), cardinal, 32, [0] * 4, X.PropModeReplace)
        dsp.sync()
    finally:
        dsp.close()

from __future__ import annotations

import configparser
import os
from dataclasses import dataclass
from pathlib import Path

from .command import desktop_exec, spawn


@dataclass(frozen=True)
class DesktopApp:
    desktop_id: str
    name: str
    icon: str
    command: tuple[str, ...]
    wm_classes: tuple[str, ...]
    comment: str = ""

    def launch(self) -> bool:
        if not self.command:
            return False
        try:
            spawn(self.command)
            return True
        except OSError:
            return False


def _application_dirs() -> list[Path]:
    data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))
    data_dirs = [Path(item) for item in os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":") if item]
    return [data_home / "applications", *(path / "applications" for path in data_dirs)]


def load_apps() -> dict[str, DesktopApp]:
    apps: dict[str, DesktopApp] = {}
    for directory in reversed(_application_dirs()):
        if not directory.is_dir():
            continue
        for path in directory.rglob("*.desktop"):
            desktop_id = str(path.relative_to(directory)).replace("/", "-")
            parser = configparser.ConfigParser(interpolation=None, strict=False)
            try:
                parser.read(path, encoding="utf-8")
                entry = parser["Desktop Entry"]
            except (OSError, KeyError, configparser.Error):
                continue
            if entry.get("Type", "Application") != "Application":
                continue
            if entry.getboolean("Hidden", fallback=False) or entry.getboolean("NoDisplay", fallback=False):
                continue
            command = desktop_exec(entry.get("Exec", ""))
            if not command:
                continue
            name = entry.get("Name", path.stem)
            icon = entry.get("Icon", "application-x-executable")
            startup = entry.get("StartupWMClass", "")
            classes = tuple(filter(None, (startup, path.stem, command[0].split("/")[-1])))
            apps[desktop_id] = DesktopApp(desktop_id, name, icon, tuple(command), classes, entry.get("Comment", ""))
    return dict(sorted(apps.items(), key=lambda item: item[1].name.casefold()))


def app_metadata(apps: dict[str, DesktopApp]) -> dict[str, tuple[str, str, tuple[str, ...]]]:
    return {desktop_id: (app.name, app.icon, app.wm_classes) for desktop_id, app in apps.items()}


from __future__ import annotations

import os
import shlex
import shutil
import subprocess
from dataclasses import dataclass
from typing import Iterable, Mapping


@dataclass(frozen=True)
class Result:
    argv: tuple[str, ...]
    code: int
    stdout: str = ""
    stderr: str = ""

    @property
    def ok(self) -> bool:
        return self.code == 0


def available(program: str) -> bool:
    return shutil.which(program) is not None


def run(argv: Iterable[str], *, timeout: float = 8.0,
        env: Mapping[str, str] | None = None) -> Result:
    args = tuple(str(part) for part in argv)
    if not args:
        return Result(args, 127, stderr="empty command")
    merged = os.environ.copy()
    if env:
        merged.update(env)
    try:
        proc = subprocess.run(
            args, text=True, capture_output=True, timeout=timeout,
            env=merged, check=False,
        )
        return Result(args, proc.returncode, proc.stdout.strip(), proc.stderr.strip())
    except FileNotFoundError:
        return Result(args, 127, stderr=f"command not found: {args[0]}")
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        err = exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return Result(args, 124, out.strip(), (err or "timeout").strip())


def spawn(argv: Iterable[str], *, start_new_session: bool = True) -> subprocess.Popen:
    args = tuple(str(part) for part in argv)
    return subprocess.Popen(
        args,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=start_new_session,
        close_fds=True,
    )


def desktop_exec(command: str) -> list[str]:
    """Parse a Desktop Entry Exec value and drop field codes."""
    try:
        parts = shlex.split(command)
    except ValueError:
        return []
    return [part for part in parts if not part.startswith("%")]


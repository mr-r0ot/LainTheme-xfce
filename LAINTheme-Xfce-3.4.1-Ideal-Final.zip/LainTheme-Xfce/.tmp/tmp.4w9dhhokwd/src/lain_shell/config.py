from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path


APP_ID = "io.github.laintheme.XfceShell"
PACKAGE_ROOT = Path(__file__).resolve().parents[2]
ASSET_DIR = Path(os.environ.get("LAIN_ASSET_DIR", PACKAGE_ROOT / "assets"))
CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "lain-theme"
STATE_DIR = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local/state")) / "lain-theme"
CACHE_DIR = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "lain-theme"
RUNTIME_DIR = Path(os.environ.get("XDG_RUNTIME_DIR", f"/tmp/lain-theme-{os.getuid()}"))


@dataclass(frozen=True)
class Profile:
    name: str = "lite"
    animations: bool = True
    animation_ms: int = 120
    blur: bool = False
    shadows: bool = False
    dock_hide_delay_ms: int = 350
    poll_ms: int = 1500

    @classmethod
    def load(cls) -> "Profile":
        path = CONFIG_DIR / "profile.json"
        if not path.exists():
            return cls()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return cls()
        name = "high" if raw.get("name") == "high" else "lite"
        if name == "high":
            return cls(name="high", animation_ms=240, blur=True, shadows=True,
                       dock_hide_delay_ms=550, poll_ms=1000)
        return cls()


@dataclass
class UserConfig:
    pinned: list[str] = field(default_factory=lambda: [
        "exo-terminal-emulator.desktop",
        "thunar.desktop",
        "firefox.desktop",
    ])
    workspaces: int = 9
    dock_autohide: bool = True
    panel_height: int = 38
    dock_height: int = 78

    @classmethod
    def load(cls) -> "UserConfig":
        path = CONFIG_DIR / "settings.json"
        if not path.exists():
            return cls()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return cls()
        defaults = cls()
        pinned = raw.get("pinned", defaults.pinned)
        if not isinstance(pinned, list):
            pinned = defaults.pinned
        return cls(
            pinned=[str(x) for x in pinned if str(x).endswith(".desktop")],
            workspaces=max(1, min(12, int(raw.get("workspaces", 9)))),
            dock_autohide=bool(raw.get("dock_autohide", True)),
            panel_height=max(30, min(64, int(raw.get("panel_height", 38)))),
            dock_height=max(62, min(112, int(raw.get("dock_height", 78)))),
        )

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        target = CONFIG_DIR / "settings.json"
        temporary = target.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.__dict__, indent=2), encoding="utf-8")
        temporary.replace(target)


def ensure_runtime_dirs() -> None:
    for directory in (CONFIG_DIR, STATE_DIR, CACHE_DIR, RUNTIME_DIR):
        directory.mkdir(parents=True, exist_ok=True)
    try:
        RUNTIME_DIR.chmod(0o700)
    except OSError:
        pass

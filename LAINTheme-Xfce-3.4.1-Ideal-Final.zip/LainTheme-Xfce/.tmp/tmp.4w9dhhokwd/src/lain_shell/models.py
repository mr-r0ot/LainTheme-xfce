from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable


@dataclass(frozen=True)
class Monitor:
    index: int
    x: int
    y: int
    width: int
    height: int
    primary: bool = False


@dataclass(frozen=True)
class Window:
    xid: int
    desktop: int
    host: str
    wm_class: str
    title: str
    pid: int | None = None
    active: bool = False
    minimized: bool = False
    urgent: bool = False
    fullscreen: bool = False
    maximized: bool = False
    geometry: tuple[int, int, int, int] | None = None


@dataclass
class AppGroup:
    key: str
    desktop_id: str | None
    name: str
    icon: str
    pinned: bool = False
    windows: list[Window] = field(default_factory=list)

    @property
    def active(self) -> bool:
        return any(window.active for window in self.windows)

    @property
    def urgent(self) -> bool:
        return any(window.urgent for window in self.windows)


def normalize_class(value: str) -> str:
    return value.strip().lower().replace(" ", "-").replace("_", "-")


def group_windows(
    windows: Iterable[Window],
    pinned_ids: Iterable[str],
    app_metadata: dict[str, tuple[str, str, tuple[str, ...]]],
) -> list[AppGroup]:
    """Return one stable group per app; pinned and running apps never duplicate."""
    class_to_id: dict[str, str] = {}
    for desktop_id, (_, _, classes) in app_metadata.items():
        class_to_id[normalize_class(desktop_id.removesuffix(".desktop"))] = desktop_id
        for candidate in classes:
            class_to_id[normalize_class(candidate)] = desktop_id

    groups: dict[str, AppGroup] = {}
    order: list[str] = []
    for desktop_id in pinned_ids:
        name, icon, _ = app_metadata.get(desktop_id, (desktop_id.removesuffix(".desktop"), "application-x-executable", ()))
        key = desktop_id
        groups[key] = AppGroup(key, desktop_id, name, icon, pinned=True)
        order.append(key)

    for window in windows:
        raw_class = normalize_class(window.wm_class.split(".")[-1])
        desktop_id = class_to_id.get(raw_class)
        key = desktop_id or f"class:{raw_class or window.xid}"
        if key not in groups:
            name, icon, _ = app_metadata.get(
                desktop_id or "", (window.wm_class or window.title, "application-x-executable", ())
            )
            groups[key] = AppGroup(key, desktop_id, name, icon)
            order.append(key)
        groups[key].windows.append(window)
    return [groups[key] for key in order]


def overlaps(window: Window, monitor: Monitor, reserved_top: int, dock_height: int) -> bool:
    if window.geometry is None:
        return window.maximized or window.fullscreen
    x, y, width, height = window.geometry
    dock_y = monitor.y + monitor.height - dock_height
    return (
        x < monitor.x + monitor.width
        and x + width > monitor.x
        and y < monitor.y + monitor.height
        and y + height > dock_y
        and y + height > monitor.y + reserved_top
    )


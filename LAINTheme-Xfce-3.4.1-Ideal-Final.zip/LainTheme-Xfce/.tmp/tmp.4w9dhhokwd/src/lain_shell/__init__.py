"""LAINTheme XFCE shell."""

__version__ = "3.2.0"

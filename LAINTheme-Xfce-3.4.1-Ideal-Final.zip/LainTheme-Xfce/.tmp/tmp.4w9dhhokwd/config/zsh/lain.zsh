# LAINTheme shell extensions. This file is loaded by the dedicated zshrc only.
setopt hist_ignore_all_dups share_history auto_cd interactive_comments
HISTFILE="${XDG_STATE_HOME:-$HOME/.local/state}/zsh/history"
mkdir -p "${HISTFILE:h}"
HISTSIZE=20000
SAVEHIST=20000
bindkey -e

alias ll='ls -lah --color=auto'
alias la='ls -A --color=auto'
alias l='ls -CF --color=auto'
alias c='clear'
alias ..='cd ..'
alias ...='cd ../..'
alias grep='grep --color=auto'

# Prefer distro packages. Syntax highlighting is deliberately sourced last.
[[ -r /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh ]] && source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh
[[ -r /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh ]] && source /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh
[[ -r /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh ]] && source /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
[[ -r /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh ]] && source /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh

if [[ -o interactive && -t 1 && -z "${LAIN_FETCH_SHOWN:-}" ]]; then
  export LAIN_FETCH_SHOWN=1
  art="${XDG_DATA_HOME:-$HOME/.local/share}/lain-theme/assets/terminal-art.png"
  command -v chafa >/dev/null 2>&1 && [[ -f "$art" ]] && chafa --size 42x18 "$art"
  if command -v fastfetch >/dev/null 2>&1; then fastfetch
  elif command -v neofetch >/dev/null 2>&1; then neofetch --off
  fi
fi

# The project never sources the pre-install .zshrc. User additions belong here.
[[ -r "${XDG_CONFIG_HOME:-$HOME/.config}/lain-theme/zsh/local.zsh" ]] && source "${XDG_CONFIG_HOME:-$HOME/.config}/lain-theme/zsh/local.zsh"

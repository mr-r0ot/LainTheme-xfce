autoload -Uz colors add-zsh-hook
colors
zmodload zsh/datetime 2>/dev/null || true
typeset -g LAIN_CMD_STARTED=0
typeset -g LAIN_LAST_STATUS=0

_lain_preexec() { LAIN_CMD_STARTED=$EPOCHREALTIME }

_lain_git() {
  command git rev-parse --is-inside-work-tree >/dev/null 2>&1 || return 0
  local branch dirty
  branch="$(command git branch --show-current 2>/dev/null)"
  [[ -n "$branch" ]] || branch="detached"
  dirty="$(command git status --porcelain 2>/dev/null)"
  print -n "%F{141} git:${branch}%f"
  [[ -n "$dirty" ]] && print -n " %F{221}±%f"
}

_lain_precmd() {
  LAIN_LAST_STATUS=$?
  local elapsed="" status="" marker='%F{81}❯%f'
  if (( LAIN_CMD_STARTED > 0 )); then
    local seconds=$(( EPOCHREALTIME - LAIN_CMD_STARTED ))
    (( seconds >= 1 )) && elapsed=" %F{244}${seconds}s%f"
  fi
  if (( LAIN_LAST_STATUS != 0 )); then
    status=" %F{203}exit:${LAIN_LAST_STATUS}%f"
    marker='%F{203}❯%f'
  fi
  PROMPT="%F{81}╭─%f %F{111}%n%f@%F{147}%m%f %F{75}%~%f$(_lain_git)${elapsed}${status}\n%F{81}╰─%f ${marker} "
  RPROMPT='%F{245}%D{%H:%M:%S}%f'
  LAIN_CMD_STARTED=0
}

add-zsh-hook preexec _lain_preexec
add-zsh-hook precmd _lain_precmd

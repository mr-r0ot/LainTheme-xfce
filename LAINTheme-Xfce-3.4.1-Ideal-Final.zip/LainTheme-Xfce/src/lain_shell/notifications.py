from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

from .config import STATE_DIR


INTROSPECTION_XML = """
<node>
  <interface name="org.freedesktop.Notifications">
    <method name="GetCapabilities"><arg direction="out" type="as"/></method>
    <method name="Notify">
      <arg direction="in" type="s" name="app_name"/>
      <arg direction="in" type="u" name="replaces_id"/>
      <arg direction="in" type="s" name="app_icon"/>
      <arg direction="in" type="s" name="summary"/>
      <arg direction="in" type="s" name="body"/>
      <arg direction="in" type="as" name="actions"/>
      <arg direction="in" type="a{sv}" name="hints"/>
      <arg direction="in" type="i" name="expire_timeout"/>
      <arg direction="out" type="u" name="id"/>
    </method>
    <method name="CloseNotification"><arg direction="in" type="u" name="id"/></method>
    <method name="GetServerInformation">
      <arg direction="out" type="s"/><arg direction="out" type="s"/>
      <arg direction="out" type="s"/><arg direction="out" type="s"/>
    </method>
    <signal name="NotificationClosed"><arg type="u" name="id"/><arg type="u" name="reason"/></signal>
    <signal name="ActionInvoked"><arg type="u" name="id"/><arg type="s" name="action_key"/></signal>
  </interface>
</node>
"""


@dataclass
class Notice:
    id: int
    app_name: str
    app_icon: str
    summary: str
    body: str
    actions: list[str]
    created: float
    unread: bool = True


class NotificationStore:
    def __init__(self, path: Path | None = None, limit: int = 100):
        self.path = path or STATE_DIR / "notifications.json"
        self.limit = limit
        self.items: list[Notice] = []
        self.next_id = 1
        self.load()

    def load(self) -> None:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            self.items = [Notice(**item) for item in raw if isinstance(item, dict)][-self.limit:]
            self.next_id = max((item.id for item in self.items), default=0) + 1
        except (OSError, ValueError, TypeError):
            self.items = []

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps([asdict(item) for item in self.items[-self.limit:]], ensure_ascii=False), encoding="utf-8")
        temporary.replace(self.path)

    def notify(self, app_name: str, replaces_id: int, app_icon: str,
               summary: str, body: str, actions: list[str]) -> Notice:
        if replaces_id:
            for index, item in enumerate(self.items):
                if item.id == replaces_id:
                    notice = Notice(item.id, app_name, app_icon, summary, body, actions, time.time())
                    self.items[index] = notice
                    self.save()
                    return notice
        notice = Notice(self.next_id, app_name, app_icon, summary, body, actions, time.time())
        self.next_id += 1
        self.items.append(notice)
        self.items = self.items[-self.limit:]
        self.save()
        return notice

    def close(self, notification_id: int) -> bool:
        before = len(self.items)
        self.items = [item for item in self.items if item.id != notification_id]
        if len(self.items) != before:
            self.save()
            return True
        return False

    def mark_read(self) -> None:
        for item in self.items:
            item.unread = False
        self.save()

    def clear(self) -> None:
        self.items.clear()
        self.save()

    @property
    def unread_count(self) -> int:
        return sum(item.unread for item in self.items)


class NotificationServer:
    """Freedesktop notification service implemented with Gio.DBus."""

    def __init__(self, store: NotificationStore, on_change: Callable[[Notice | None, int], None]):
        self.store = store
        self.on_change = on_change
        self.connection = None
        self.registration_id = 0
        self.owner_id = 0

    def start(self) -> None:
        from gi.repository import Gio
        node = Gio.DBusNodeInfo.new_for_xml(INTROSPECTION_XML)
        self.interface = node.interfaces[0]
        self.owner_id = Gio.bus_own_name(
            Gio.BusType.SESSION, "org.freedesktop.Notifications",
            Gio.BusNameOwnerFlags.REPLACE | Gio.BusNameOwnerFlags.ALLOW_REPLACEMENT,
            self._bus_acquired, None, None,
        )

    def _bus_acquired(self, connection, _name) -> None:
        self.connection = connection
        self.registration_id = connection.register_object(
            "/org/freedesktop/Notifications", self.interface, self._method_call, None, None
        )

    def _method_call(self, connection, sender, object_path, interface_name, method_name, parameters, invocation) -> None:
        from gi.repository import GLib
        if method_name == "GetCapabilities":
            invocation.return_value(GLib.Variant("(as)", (["actions", "body", "icon-static", "persistence"],)))
            return
        if method_name == "GetServerInformation":
            invocation.return_value(GLib.Variant("(ssss)", ("LAINTheme", "LAINTheme-Xfce", "3.3.0", "1.3")))
            return
        if method_name == "Notify":
            app_name, replaces_id, app_icon, summary, body, actions, _hints, _timeout = parameters.unpack()
            notice = self.store.notify(app_name, replaces_id, app_icon, summary, body, list(actions))
            self.on_change(notice, _timeout)
            invocation.return_value(GLib.Variant("(u)", (notice.id,)))
            return
        if method_name == "CloseNotification":
            notification_id = parameters.unpack()[0]
            if self.store.close(notification_id):
                connection.emit_signal(None, object_path, interface_name, "NotificationClosed", GLib.Variant("(uu)", (notification_id, 3)))
                self.on_change(None, 0)
            invocation.return_value(None)
            return
        invocation.return_dbus_error("org.freedesktop.DBus.Error.UnknownMethod", method_name)

    def invoke_action(self, notification_id: int, action: str) -> None:
        from gi.repository import GLib
        if self.connection:
            self.connection.emit_signal(
                None, "/org/freedesktop/Notifications", "org.freedesktop.Notifications",
                "ActionInvoked", GLib.Variant("(us)", (notification_id, action)),
            )

    def dismiss_all(self) -> None:
        from gi.repository import GLib
        ids = [item.id for item in self.store.items]
        self.store.clear()
        if self.connection:
            for notification_id in ids:
                self.connection.emit_signal(
                    None, "/org/freedesktop/Notifications", "org.freedesktop.Notifications",
                    "NotificationClosed", GLib.Variant("(uu)", (notification_id, 2)),
                )
        self.on_change(None, 0)

    def stop(self) -> None:
        from gi.repository import Gio
        if self.connection and self.registration_id:
            self.connection.unregister_object(self.registration_id)
        if self.owner_id:
            Gio.bus_unown_name(self.owner_id)

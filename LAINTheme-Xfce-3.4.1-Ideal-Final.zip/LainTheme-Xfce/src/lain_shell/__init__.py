"""LAINTheme XFCE shell."""

__version__ = "3.3.0"

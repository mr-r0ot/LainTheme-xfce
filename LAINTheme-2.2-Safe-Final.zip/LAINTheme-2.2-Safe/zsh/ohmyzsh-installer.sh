#!/usr/bin/env bash
set -Eeuo pipefail
ZSH="$HOME/.oh-my-zsh"
if [[ -d "$ZSH/.git" ]]; then exit 0; fi
if command -v git >/dev/null && git ls-remote https://github.com/ohmyzsh/ohmyzsh.git HEAD >/dev/null 2>&1; then git clone --depth=1 https://github.com/ohmyzsh/ohmyzsh.git "$ZSH"; fi
if [[ -d "$ZSH" ]]; then mkdir -p "$ZSH/custom/themes"; cp -f "$HOME/.local/share/laintheme/zsh/ohmyzsh/custom/themes/lain.zsh-theme" "$ZSH/custom/themes/lain.zsh-theme" 2>/dev/null || true; fi
for repo in zsh-users/zsh-autosuggestions zsh-users/zsh-syntax-highlighting; do
  name=${repo##*/}; dest="$HOME/.oh-my-zsh/custom/plugins/$name";
  [[ -d "$dest" ]] && continue
  if command -v git >/dev/null && git ls-remote "https://github.com/$repo.git" HEAD >/dev/null 2>&1; then git clone --depth=1 "https://github.com/$repo.git" "$dest" || true; fi
done

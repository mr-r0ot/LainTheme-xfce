export ZSH="$HOME/.oh-my-zsh"
export ZSH_CUSTOM="$ZSH/custom"
ZSH_THEME="lain"
plugins=(git)
if [[ -f "$ZSH/oh-my-zsh.sh" ]]; then source "$ZSH/oh-my-zsh.sh"; fi
[[ -f "$ZSH_CUSTOM/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh" ]] && source "$ZSH_CUSTOM/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh"
[[ -f "/usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh" ]] && source "/usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh"
[[ -f "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" ]] && source "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh"
[[ -f "/usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" ]] && source "/usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh"
setopt HIST_IGNORE_DUPS SHARE_HISTORY AUTO_CD INTERACTIVE_COMMENTS
HISTSIZE=20000
SAVEHIST=20000
HISTFILE="$HOME/.zsh_history"
bindkey -e
autoload -Uz add-zsh-hook
__lain_cmd_start=0
__lain_last_status=0
preexec(){ __lain_cmd_start=$EPOCHREALTIME }
precmd(){
  __lain_last_status=$?
  local duration=0
  if [[ -n "$__lain_cmd_start" ]]; then duration=$((EPOCHREALTIME-__lain_cmd_start)); fi
  local secs=${duration%.*}
  (( secs > 0 )) && export LAIN_DURATION="${secs}s" || export LAIN_DURATION=""
}
_lain_git(){
  command git rev-parse --is-inside-work-tree >/dev/null 2>&1 || return 0
  local b s
  b=$(command git branch --show-current 2>/dev/null)
  s=$(command git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
  print -n "%F{141}󰊢 ${b:-detached}%f"
  (( s > 0 )) && print -n " %F{221}±${s}%f"
}
_lain_prompt(){
  local st=$__lain_last_status mark='%F{42}❯%f'
  (( st != 0 )) && mark='%F{203}❯%f'
  local d=""; [[ -n "$LAIN_DURATION" ]] && d=" %F{221}${LAIN_DURATION}%f"
  PROMPT="${mark} %F{117}%~%f $(_lain_git)${d}\n%F{141}╰─%f "
  RPROMPT="%F{245}${st} %D{%H:%M:%S}%f"
}
precmd_functions+=(_lain_prompt)

alias ll='ls -lah --color=auto'
alias la='ls -A'
alias l='ls -CF'
alias c='clear'
alias cls='clear'
alias ..='cd ..'
alias ...='cd ../..'
alias lain='laintheme'
alias lainconfig='$HOME/.local/bin/lainconfig'
alias lltheme='$HOME/.local/bin/laintheme status'
alias screenshot='$HOME/.local/bin/lain-capture screenshot'
alias record='$HOME/.local/bin/lain-capture record'
alias fetch='$HOME/.local/bin/lain-fetch'

if [[ -t 1 && -z "${LAIN_NO_GREETING:-}" ]]; then
  "$HOME/.local/bin/lain-fetch" 2>/dev/null
fi

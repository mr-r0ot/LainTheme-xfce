# LAINTheme 2.2 Safe

Native XFCE/X11 desktop shell with its own theme and shell; installation does not depend on a third-party GTK theme installer.

## Install

```bash
unzip LAINTheme-2.2-Safe-Final.zip
cd LAINTheme-2.2
chmod +x laintheme_install.sh
./laintheme_install.sh --lite
```

High mode:

```bash
./laintheme_install.sh --high
```

## Management

```text
laintheme status
laintheme diagnose
laintheme repair
laintheme profile lite
laintheme profile high
laintheme launcher
laintheme control
laintheme notify
laintheme power
laintheme terminal
laintheme lock
laintheme screenshot
laintheme record
laintheme uninstall
```

Lite never starts an external compositor. High uses picom only as an optional enhancement and falls back to Xfwm4 compositing if picom exits.

The installer creates a timestamped backup under `~/.local/state/laintheme/backups/` before changing Xfwm4, Xsettings, keyboard shortcuts, autostart overrides, theme files, or `.zshrc`.

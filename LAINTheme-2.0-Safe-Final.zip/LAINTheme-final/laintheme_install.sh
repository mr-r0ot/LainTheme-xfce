#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"; HOME_DIR="$HOME"; LOCAL="$HOME_DIR/.local"; BIN="$LOCAL/bin"; SHARE="$LOCAL/share/laintheme"; STATE="${XDG_STATE_HOME:-$LOCAL/state}/laintheme"; BACKUP="$STATE/backups/$(date +%Y%m%d-%H%M%S)"; PROFILE=''; DRY=0; UNINSTALL=0
mkdir -p "$STATE" "$BACKUP" "$BIN" "$SHARE"
log(){ printf '[%s] %s\n' "$1" "${*:2}"; }
fail(){ log FAIL "$*" >&2; exit 1; }
usage(){ cat <<EOF
LAINTheme 2.0 — native XFCE shell
Usage: ./laintheme_install.sh --lite|--high [--dry-run] [--uninstall] [--no-lock]
No WhiteSur dependency. Lite never starts picom.
EOF
}
priv(){ if command -v sudo >/dev/null 2>&1; then sudo "$@"; elif command -v pkexec >/dev/null 2>&1; then pkexec "$@"; elif [[ $EUID -eq 0 ]]; then "$@"; else return 127; fi; }
while (($#)); do case "$1" in --lite) PROFILE=lite;; --high) PROFILE=high;; --dry-run) DRY=1;; --uninstall) UNINSTALL=1;; --no-lock) NOLOCK=1;; -h|--help) usage; exit 0;; *) fail "unknown option: $1";; esac; shift; done
[[ $EUID -ne 0 ]] || [[ -n "${SUDO_USER:-}" ]] || true
if ((UNINSTALL)); then
  rm -f "$HOME_DIR/.config/autostart/laintheme-shell.desktop" "$HOME_DIR/.config/autostart/laintheme-notify.desktop" "$HOME_DIR/.config/autostart/xfce4-notifyd.desktop"
  pkill -u "$USER" -f "$BIN/lain-shell" 2>/dev/null || true; pkill -u "$USER" -f "$BIN/lain-notifyd" 2>/dev/null || true; pkill -u "$USER" -x picom 2>/dev/null || true
  if [[ -f "$SHARE/backup/xfwm4.xml" ]]; then mkdir -p "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml"; cp "$SHARE/backup/xfwm4.xml" "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml"; fi
  rm -rf "$SHARE"; rm -f "$BIN"/{lain-shell,lain-notifyd,lain-window,lain-wifi,lain-capture,lain-lock,lain-compositor,laintheme,lainconfig}
  xfconf-query -c xfwm4 -p /general/margin_top -s 0 2>/dev/null || true; xfconf-query -c xfwm4 -p /general/margin_bottom -s 0 2>/dev/null || true
  log OK 'LAINTheme removed. Existing XFCE files were not deleted.'; exit 0
fi
[[ "$PROFILE" == lite || "$PROFILE" == high ]] || { usage; exit 2; }
[[ "${XDG_CURRENT_DESKTOP:-}" =~ [Xx][Ff][Cc][Ee] ]] || fail 'Run this from an XFCE session.'
[[ -n "${DISPLAY:-}" ]] || fail 'DISPLAY is missing; run from the graphical session.'
command -v xfconf-query >/dev/null || fail 'xfconf-query is missing.'
PKGS=(python3 python3-gi gir1.2-gtk-3.0 python3-dbus python3-cairo dbus-x11 xfconf xfce4-panel xfce4-terminal thunar wmctrl xdotool network-manager bluez rfkill pulseaudio-utils ffmpeg imagemagick zsh git fonts-jetbrains-mono i3lock papirus-icon-theme)
[[ "$PROFILE" == high ]] && PKGS+=(picom)
if ((DRY)); then printf '%s\n' "profile=$PROFILE" "packages=${PKGS[*]}"; exit 0; fi
# Install only missing packages; if the user already has a working stack, no root access is needed.
missing=(); for p in "${PKGS[@]}"; do dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q 'install ok installed' || missing+=("$p"); done
if ((${#missing[@]})); then command -v apt-get >/dev/null || fail 'apt-get is missing and dependencies are not installed.'; priv apt-get update || fail 'Package index update failed.'; priv apt-get install -y "${missing[@]}" || fail 'Dependency installation failed.'; fi
for c in python3 xfconf-query xdotool wmctrl; do command -v "$c" >/dev/null || fail "Required command missing after installation: $c"; done
# Backup only files we own/change.
mkdir -p "$SHARE/backup" "$HOME_DIR/.config/autostart" "$HOME_DIR/.config/picom" "$HOME_DIR/.themes" "$HOME_DIR/.local/share/icons" "$HOME_DIR/.cache/laintheme"
for f in "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml" "$HOME_DIR/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml"; do [[ -f "$f" ]] && cp -a "$f" "$SHARE/backup/$(basename "$f")"; done
# Native theme; no third-party theme installer can crash XFCE panel.
cp -a "$ROOT/theme/LAINTheme-Dark" "$HOME_DIR/.themes/"
cp -a "$ROOT/assets" "$SHARE/"
cp -f "$ROOT/theme.css" "$SHARE/theme.css"; cp -f "$ROOT/config/picom.conf" "$SHARE/picom.conf"; cp -f "$ROOT/config/keys.txt" "$SHARE/keys.txt"; cp -a "$ROOT/zsh" "$SHARE/"
cp -f "$ROOT/bin/"* "$BIN/"; chmod +x "$BIN/"*
printf '%s\n' "$PROFILE" > "$SHARE/profile"
# Use the native XFWM compositor in Lite. High uses picom only after a live health check.
xfconf-query -c xsettings -p /Net/ThemeName -n -t string -s LAINTheme-Dark 2>/dev/null || xfconf-query -c xsettings -p /Net/ThemeName -s LAINTheme-Dark || true
xfconf-query -c xsettings -p /Net/FontName -n -t string -s 'JetBrains Mono 10' 2>/dev/null || xfconf-query -c xsettings -p /Net/FontName -s 'JetBrains Mono 10' || true
if [[ -d /usr/share/icons/Papirus-Dark ]]; then xfconf-query -c xsettings -p /Net/IconThemeName -n -t string -s Papirus-Dark 2>/dev/null || xfconf-query -c xsettings -p /Net/IconThemeName -s Papirus-Dark || true; fi
xfconf-query -c xfwm4 -p /general/margin_top -n -t int -s 64 2>/dev/null || xfconf-query -c xfwm4 -p /general/margin_top -s 64 || true
xfconf-query -c xfwm4 -p /general/margin_bottom -n -t int -s 92 2>/dev/null || xfconf-query -c xfwm4 -p /general/margin_bottom -s 92 || true
xfconf-query -c xfwm4 -p /general/snap_to_windows -n -t bool -s true 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/snap_to_border -n -t bool -s true 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/wrap_workspaces -n -t bool -s false 2>/dev/null || true
# Four workspaces with explicit names when supported.
xfconf-query -c xfwm4 -p /general/workspace_count -n -t int -s 4 2>/dev/null || true
# Stop only the XFCE panel process itself; never use a recurring guard.
xfce4-panel --quit >/dev/null 2>&1 || true
# Autostart our shell and notification service.
cat > "$HOME_DIR/.config/autostart/laintheme-shell.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=LAINTheme Shell
Exec=$BIN/lain-shell --start
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF
cat > "$HOME_DIR/.config/autostart/laintheme-notify.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=LAINTheme Notifications
Exec=$BIN/lain-notifyd
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF
# Let our notification center own the freedesktop notification name.
mkdir -p "$HOME_DIR/.config/autostart"
cat > "$HOME_DIR/.config/autostart/xfce4-notifyd.desktop" <<'EOF'
[Desktop Entry]
Hidden=true
EOF
pkill -u "$USER" -x xfce4-notifyd 2>/dev/null || true
# Remove stale picom autostart from earlier versions.
rm -f "$HOME_DIR/.config/autostart/laintheme-picom.desktop"
if [[ "$PROFILE" == lite ]]; then
  # Disable stale user picom/compton autostarts from older Step2 installs, with backups.
  for f in "$HOME_DIR/.config/autostart/"*.desktop; do
    [[ -f "$f" ]] || continue
    if grep -Eiq '^[[:space:]]*Exec=.*(picom|compton)([[:space:]]|$)' "$f"; then
      cp -a "$f" "$SHARE/backup/$(basename "$f").disabled"
      rm -f "$f"
    fi
  done
  xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true 2>/dev/null || true
  pkill -u "$USER" -x picom 2>/dev/null || true
  pkill -u "$USER" -x compton 2>/dev/null || true
else
  xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true 2>/dev/null || true
  cat > "$HOME_DIR/.config/picom/laintheme.conf" <<EOF
$(cat "$ROOT/config/picom.conf")
EOF
  # Do not make a failed optional compositor prevent login. lain-compositor reverts to XFWM.
  xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true 2>/dev/null || true
  "$BIN/lain-compositor" start || log WARN 'High compositor unavailable; safely staying on XFWM compositor.'
fi
# Keyboard shortcuts through XFCE xfconf.
setkey(){ local k="$1" a="$2"; xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/$k" -n -t string -s "$a" 2>/dev/null || xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/$k" -s "$a" 2>/dev/null || true; }
setkey '<Super>space' "$BIN/laintheme launcher"; setkey '<Super>Return' "$BIN/laintheme terminal"; setkey '<Super>e' 'thunar'; setkey '<Super>w' "$BIN/lain-window close"; setkey '<Super>Up' "$BIN/lain-window maximize"; setkey '<Super>Down' "$BIN/lain-window minimize"; setkey '<Super>Left' "$BIN/lain-window snap-left"; setkey '<Super>Right' "$BIN/lain-window snap-right"; setkey '<Super><Shift>r' "$BIN/laintheme screenshot"; setkey '<Super><Shift>g' "$BIN/laintheme record"; setkey '<Super><Shift>l' "$BIN/laintheme lock"; setkey '<Super><Shift>c' "$BIN/laintheme control"; setkey '<Super><Shift>n' "$BIN/laintheme notifications"; setkey '<Super><Shift>p' "$BIN/laintheme power"
for n in {1..9}; do setkey "<Super>$n" "$BIN/lain-window workspace $n"; done
# Kill old shell/notification instances and start cleanly.
pkill -u "$USER" -f "$BIN/lain-shell" 2>/dev/null || true; pkill -u "$USER" -f "$BIN/lain-notifyd" 2>/dev/null || true
"$BIN/lain-notifyd" >/dev/null 2>&1 &
"$BIN/lain-shell" --start >/dev/null 2>&1 &
# Syntax check is part of installation, before success is reported.
bash -n "$BIN/lain-capture" "$BIN/lain-wifi" "$BIN/lain-compositor" "$ROOT/laintheme_install.sh"
python3 -m py_compile "$BIN/lain-shell" "$BIN/lain-window" "$BIN/lain-notifyd" "$BIN/laintheme"; rm -rf "$BIN/__pycache__"
log OK "LAINTheme installed: $PROFILE"
log OK 'Lite never starts picom; High has live compositor fallback to XFWM.'
log OK 'Backup: '"$SHARE/backup"

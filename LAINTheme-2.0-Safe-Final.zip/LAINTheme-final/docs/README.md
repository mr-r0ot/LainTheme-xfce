# LAINTheme 2.0

Native-first modern XFCE shell for Debian/Ubuntu/Linux Mint XFCE.

## Profiles

- **Lite**: no picom, native XFWM compositor, low overhead.
- **High**: optional picom blur/rounded corners; if picom fails its process is not kept alive and XFWM remains enabled.

## Install

```bash
chmod +x laintheme_install.sh
./laintheme_install.sh --lite
```

High:

```bash
./laintheme_install.sh --high
```

No WhiteSur is downloaded or installed.

## Safety

The installer backs up XFWM and Xsettings XML before changing them. It does not install a recurring panel-killer. The secure lock path delegates password validation to i3lock/PAM; LAINTheme never reads or stores the password.

## Commands

`laintheme status`, `diagnose`, `repair`, `profile lite`, `profile high`, `launcher`, `control`, `notifications`, `power`, `lock`, `screenshot`, `record`, `terminal`.

autoload -Uz compinit && compinit -d "$HOME/.cache/zsh/zcompdump" 2>/dev/null || true
setopt HIST_IGNORE_DUPS SHARE_HISTORY
PROMPT='%F{magenta}❯%f %F{cyan}%~%f %F{yellow}$(git branch --show-current 2>/dev/null)%f %(?.%F{green}✓%f.%F{red}✗%f) '
RPROMPT='%F{240}$(date +%H:%M:%S)%f'
alias ll='ls -lah --color=auto'; alias laintheme='$HOME/.local/bin/laintheme'; alias lainconfig='$HOME/.local/bin/lainconfig'
precmd(){ LAST_STATUS=$?; }

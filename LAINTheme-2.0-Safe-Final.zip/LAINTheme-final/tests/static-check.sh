#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo '[1] bash syntax'; bash -n laintheme_install.sh bin/lain-capture bin/lain-wifi bin/lain-compositor
echo '[2] python syntax'; python3 -m py_compile bin/lain-shell bin/lain-window bin/lain-notifyd bin/laintheme; rm -rf bin/__pycache__
echo '[3] no WhiteSur dependency'; ! grep -Rqi 'WhiteSur' laintheme_install.sh bin config theme docs || true
echo '[4] Lite never starts picom'; grep -q 'PROFILE.*high' bin/lain-compositor; grep -q -- '--lite' laintheme_install.sh
echo '[5] destructive panel guard absent'; ! grep -Rqi 'panel-guard' .
echo '[6] installer supports no-sudo environments when dependencies already exist'; grep -q 'pkexec' laintheme_install.sh
echo '[7] secure locker does not collect password'; grep -q 'PAM\|i3lock' bin/lain-lock
echo '[8] keybindings'; grep -q 'Super+Shift+R' config/keys.txt
echo 'STATIC CHECKS: PASS'

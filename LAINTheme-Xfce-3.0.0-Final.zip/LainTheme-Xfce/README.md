# LAINTheme-Xfce 3.0

LAINTheme-Xfce replaces the stock XFCE panel in an X11 session with one GTK3 shell: a multi-monitor top panel, grouped dock, launcher, control center, notification service and workspace OSD. It also installs a coordinated desktop, terminal, lock and LightDM appearance.

The implementation targets XFCE 4.18/4.20 on X11. Wayland, non-XFCE desktops and display managers other than LightDM GTK Greeter are intentionally outside the compatibility boundary.

## Install

```bash
chmod +x install.sh
./install.sh --profile lite
```

High profile:

```bash
./install.sh --profile high
```

Useful installation switches:

```text
--dry-run              Print all 11 stages without changing the system
--no-packages          Do not install missing distribution packages
--no-lightdm           Leave the system login greeter unchanged
--no-start             Apply files without replacing the panel in this session
--skip-shell-network   Do not attempt the time-limited Oh My Zsh download
```

The installer calls `apt update` only when a required Debian package is missing. Arch package installation uses `pacman --needed`. User and XFCE configuration is snapshotted before mutation; failures restore the transaction snapshot automatically.

## Delivered behavior

Top panel:

- one correctly positioned panel per monitor;
- EWMH `_NET_WM_STRUT_PARTIAL` in root coordinates;
- distribution icon, Applications launcher, nine workspace controls and `Desktop N`;
- CPU, RAM and disk HUD;
- overlay-centered clock and date;
- unified Wi-Fi, Bluetooth and battery status cluster;
- unread notification badge, Control Center and power menu;
- modal popovers that close on outside click.

Dock:

- one stable group for each pinned/running application;
- no periodic widget teardown or duplicate pinned/open icons;
- active, urgent and multi-window state;
- activate/minimize, per-window close and pin/unpin;
- launcher-to-dock drag and drop;
- monitor-local intellihide for fullscreen, maximized and overlapping windows;
- a three-pixel reveal edge while hidden.

Control Center:

- Wi-Fi power, rescan, password entry, connect and disconnect;
- Bluetooth power, scan, pair, PIN/passkey confirmation, trust, connect and disconnect;
- airplane mode, volume and brightness;
- screenshot and FFmpeg screen-recording start/stop;
- terminal and LAINTheme Settings launchers;
- asynchronous backend calls and visible backend errors.

Notifications:

- `org.freedesktop.Notifications` service at the standard object path;
- replacement IDs, persistent history, unread state and Clear All;
- notification action buttons and `ActionInvoked` signals;
- correct 1.3 method types and bounded history storage.

System integration:

- `Super+Z` opens only the LAIN launcher;
- conflicting bare-Super and `Super+Space` appfinder bindings are removed only when they invoke XFCE appfinder/menu;
- `Super+1..9` switches workspaces;
- `Ctrl+Alt+L` and XFCE `LockCommand` invoke the secure `i3lock` path;
- wallpaper is applied to every existing XFCE monitor/workspace property;
- LightDM GTK Greeter receives the lock background, font, clock and indicators;
- XFCE Terminal receives the palette, font and terminal art;
- Zsh receives Git state, exit state, duration, history, aliases, suggestions and highlighting;
- three small event sounds are installed as the `LAINTheme` sound theme.

## Profiles

`lite` keeps XFWM compositing and never starts Picom. `high` starts Picom through a supervised wrapper; if Picom is absent or exits, the wrapper restores XFWM compositing.

Change the next-session profile without reinstalling:

```bash
lainctl profile lite
lainctl profile high
```

## Maintenance

```bash
lainctl status
lainctl diagnose
lainctl repair
lainctl lock
lainctl uninstall
```

`repair` operates from a temporary source snapshot, preserving the original pre-install backup. Repeated repairs do not replace the base rollback state.

## Validation

Run the complete local suite:

```bash
./tools/test.sh
```

It checks Bash syntax, Python compilation, pure model tests, notification signatures, the release contract, image/audio integrity, dry-run behavior, isolated installation, repeated repair and exact uninstall restoration.

The panel geometry follows the [Freedesktop EWMH strut contract](https://specifications.freedesktop.org/wm/latest-single/), and the notification service follows the [Freedesktop Desktop Notifications 1.3 protocol](https://specifications.freedesktop.org/notification/1.3/). LightDM options follow the [LightDM GTK Greeter configuration schema](https://github.com/Xubuntu/lightdm-gtk-greeter/blob/master/data/lightdm-gtk-greeter.conf). Current Xfce Terminal settings account for the documented [1.1.0 migration to Xfconf](https://docs.xfce.org/apps/xfce4-terminal/advanced).

## Uninstall safety

The installer manages only its named files and explicitly selected XFCE properties. It does not run a persistent panel killer, delete unrelated autostarts or overwrite arbitrary Picom configuration. `uninstall.sh` restores the captured user files and the previous LightDM override, then starts the restored XFCE panel.

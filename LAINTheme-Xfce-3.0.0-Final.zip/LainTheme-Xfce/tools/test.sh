#!/usr/bin/env bash
set -Eeuo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"
printf '[1/5] Bash syntax\n'
find . -type f \( -name '*.sh' -o -path './bin/*' \) -print0 | while IFS= read -r -d '' file; do bash -n "$file"; done
printf '[2/5] Python compile\n'
python3 -m compileall -q src tools tests
printf '[3/5] Unit and contract tests\n'
PYTHONPATH=src python3 -m unittest discover -s tests -p 'test_*.py' -v
printf '[4/5] Isolated installer and rollback\n'
./tests/test_install.sh
printf '[5/5] Asset integrity\n'
python3 - <<'PY'
from pathlib import Path
from PIL import Image
for name, expected in [('wallpaper.png',(2560,1440)),('lock.png',(2560,1440)),('terminal-art.png',(900,540))]:
    with Image.open(Path('assets') / name) as image:
        assert image.size == expected and image.format == 'PNG'
print('asset-pass')
PY
printf '[DONE] all tests passed\n'

# Changelog

## 3.0.0

- Replaced the incremental 2.x panel implementation with a data-model-driven GTK3 shell.
- Added monitor-local top panels, EWMH partial struts and overlay-centered clocks.
- Replaced periodic Dock rebuilds with stable grouped application state.
- Added Launcher drag-and-drop, application pinning and `Super+Z` integration.
- Added asynchronous NetworkManager, BlueZ, audio, brightness, screenshot and recording backends.
- Added BlueZ PIN/passkey/confirmation agent support.
- Added a Freedesktop Notifications 1.3 service with actions and persistent history.
- Added secure i3lock and reversible LightDM GTK Greeter integration.
- Added deterministic desktop, lock and terminal assets plus a minimal sound theme.
- Added Lite/High compositor separation and Picom crash fallback.
- Added transactional install, update, repair, uninstall and original-state preservation.
- Added unit, contract, asset and isolated install/rollback tests.


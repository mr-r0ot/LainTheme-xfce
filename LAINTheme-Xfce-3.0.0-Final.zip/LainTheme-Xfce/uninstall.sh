#!/usr/bin/env bash
set -Eeuo pipefail

STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
STATE_DIR="$STATE_HOME/lain-theme"
CURRENT_BACKUP="$STATE_DIR/current-backup"
[[ -f "$CURRENT_BACKUP" ]] || { printf 'No active LAINTheme installation backup found.\n' >&2; exit 1; }
BACKUP_ROOT="$(<"$CURRENT_BACKUP")"
MANIFEST="$BACKUP_ROOT/manifest.tsv"
[[ -f "$MANIFEST" ]] || { printf 'Backup manifest is missing: %s\n' "$MANIFEST" >&2; exit 1; }

printf '[1/4] Stopping LAINTheme services\n'
systemctl --user stop lain-shell.service >/dev/null 2>&1 || true
if command -v gapplication >/dev/null 2>&1; then gapplication quit io.github.laintheme.XfceShell >/dev/null 2>&1 || true; fi

printf '[2/4] Restoring user configuration\n'
while IFS=$'\t' read -r kind path; do
  [[ -n "$path" ]] || continue
  saved="$BACKUP_ROOT/user/${path#/}"
  if [[ "$kind" == "E" ]]; then
    rm -rf -- "$path"
    mkdir -p "$(dirname "$path")"
    cp -a -- "$saved" "$path"
  else
    rm -rf -- "$path"
  fi
done <"$MANIFEST"

printf '[3/4] Restoring LightDM override\n'
system_backup="$BACKUP_ROOT/system"
if [[ -d "$system_backup" ]] && command -v sudo >/dev/null 2>&1; then
  greeter_conf=/etc/lightdm/lightdm-gtk-greeter.conf.d/90-lain-theme.conf
  system_wallpaper=/usr/local/share/backgrounds/lain-lock.png
  if [[ "$(<"$system_backup/greeter.state")" == E ]]; then sudo cp -a "$system_backup/greeter.conf" "$greeter_conf"; else sudo rm -f -- "$greeter_conf"; fi
  if [[ "$(<"$system_backup/wallpaper.state")" == E ]]; then sudo cp -a "$system_backup/lain-lock.png" "$system_wallpaper"; else sudo rm -f -- "$system_wallpaper"; fi
fi

printf '[4/4] Restoring XFCE session components\n'
if command -v xfdesktop >/dev/null 2>&1; then xfdesktop --reload >/dev/null 2>&1 || true; fi
systemctl --user daemon-reload >/dev/null 2>&1 || true
if command -v xfce4-panel >/dev/null 2>&1 && [[ -n "${DISPLAY:-}" ]]; then xfce4-panel >/dev/null 2>&1 & fi
rm -f -- "$CURRENT_BACKUP" "$STATE_DIR/install-state"
printf '[DONE] Previous XFCE configuration restored. Backup retained at %s\n' "$BACKUP_ROOT"

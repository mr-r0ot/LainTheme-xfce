# Acceptance matrix

This file is the project boundary. A release is code-complete only when every row has an implementation and an automated check where the build environment can exercise it.

| Area | Required outcome | Implementation | Automated evidence |
| --- | --- | --- | --- |
| Top panel | Thin top placement, centered time, full left/right controls | `PanelWindow`, one instance per monitor | Python parse, multi-monitor and strut contract tests |
| Work area | Maximized windows do not occupy the top panel area | EWMH partial strut; XFWM margins are not changed | Strut static contract |
| Launcher | Applications UI on `Super+Z`; no launcher on bare Super/Space | `LauncherPopover`, transactional XFConf binding | Shortcut contract and install rollback test |
| Workspaces | Nine clickable desktops and `Super+1..9` | panel buttons, `wmctrl`, XFWM bindings | Shortcut contract |
| Dock | Pinned/open grouping, activate, close, pin, DnD | `group_windows`, diff-driven `DockWindow` | Pure grouping and no-rebuild tests |
| Dock hide | Monitor-local fullscreen/maximize/overlap behavior | geometry-aware intellihide | Pure overlap tests |
| Wi-Fi | Power, scan, password, connect, disconnect, errors | NetworkManager `nmcli` backend | Python compile and backend isolation |
| Bluetooth | Power, scan, pair/trust/connect, PIN/passkey UI | BlueZ agent plus `bluetoothctl` backend | Agent contract test |
| Media controls | Volume, brightness, screenshot, recording toggle | PipeWire/PulseAudio, brightnessctl, screenshot backends, FFmpeg PID state | Python compile and command model tests |
| Notifications | Freedesktop API, history, unread, actions, clear | Gio DBus service and bounded JSON store | Signature and store unit tests |
| Lock | Real keyboard/pointer grab and XFCE lock command | `i3lock`, `lain-lock`, XFConf LockCommand | Installer contract |
| Login | Actual LightDM GTK Greeter appearance | reversible system override | Install transaction logic |
| Wallpaper | Desktop image on existing monitors/workspaces | enumerated XFCE backdrop properties | Installer contract and PNG test |
| Terminal | Zsh, prompt states, suggestions/highlighting, art | terminal profile and managed Zsh block | syntax and rollback tests |
| Profiles | Lite uses XFWM; High supervises Picom with fallback | profile file and compositor wrapper | release contract |
| Safety | 11 visible stages, fast dependency path, exact rollback | transactional installer/uninstaller | isolated install/repair/uninstall test |

Compatibility boundary:

- XFCE on X11;
- GTK3 and an EWMH-compliant window manager, normally XFWM4;
- NetworkManager for Wi-Fi and BlueZ for Bluetooth;
- LightDM GTK Greeter for system login theming.

Wayland and other desktop/display-manager stacks are excluded rather than handled through unverified compatibility branches.


from __future__ import annotations

import ast
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class ReleaseContractTests(unittest.TestCase):
    def text(self, path: str) -> str:
        return (ROOT / path).read_text(encoding="utf-8")

    def test_every_python_file_parses(self):
        for path in (ROOT / "src").rglob("*.py"):
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    def test_installer_has_exactly_eleven_visible_steps(self):
        calls = re.findall(r'^step\s+(\d+)\s+"', self.text("install.sh"), re.M)
        self.assertEqual(calls, [str(number) for number in range(1, 12)])

    def test_shortcut_contract(self):
        installer = self.text("install.sh")
        self.assertIn("/commands/custom/<Super>z", installer)
        self.assertIn("lain-launcher", installer)
        self.assertIn("workspace_${workspace}_key", installer)
        self.assertNotIn("/commands/custom/<Super>space' -n", installer)

    def test_no_destructive_panel_loop(self):
        all_shell = "\n".join(path.read_text(encoding="utf-8") for path in ROOT.rglob("*.sh"))
        self.assertNotIn("pkill -f", all_shell)
        self.assertNotIn("xfce4-panel -r", all_shell)
        self.assertNotIn("while true", all_shell)

    def test_notification_signature(self):
        source = self.text("src/lain_shell/notifications.py")
        signature = re.findall(r'<arg direction="in" type="([^"]+)"', source)
        self.assertEqual(signature[:8], ["s", "u", "s", "s", "s", "as", "a{sv}", "i"])
        self.assertIn("ToastWindow", self.text("src/lain_shell/app.py"))

    def test_bluetooth_agent_supports_pin_and_confirmation(self):
        source = self.text("src/lain_shell/bluez_agent.py")
        self.assertIn("KeyboardDisplay", source)
        self.assertIn("RequestPinCode", source)
        self.assertIn("RequestPasskey", source)
        self.assertIn("RequestConfirmation", source)

    def test_multimonitor_construction_and_strut(self):
        app = self.text("src/lain_shell/app.py")
        x11 = self.text("src/lain_shell/x11.py")
        self.assertIn("for monitor in monitors:", app)
        self.assertIn("_NET_WM_STRUT_PARTIAL", x11)
        self.assertIn("monitor.x + monitor.width - 1", x11)

    def test_dock_is_diff_driven(self):
        ui = self.text("src/lain_shell/ui.py")
        self.assertIn("if fingerprint == self.fingerprint", ui)
        self.assertNotIn("timeout_add(900", ui)
        self.assertIn("pinned.insert(insert_at, desktop_id)", ui)

    def test_shell_has_failure_supervision(self):
        service = self.text("config/lain-shell.service")
        self.assertIn("Restart=on-failure", service)
        self.assertIn("RestartSec=2", service)

    def test_lite_never_starts_picom(self):
        session = self.text("bin/lain-session-start")
        self.assertIn("profile.json", session)
        self.assertRegex(session, r'profile.*high')
        self.assertNotRegex(session, r'picom\s*&')

    def test_no_legacy_theme_dependency(self):
        banned = "white" + "sur"
        for path in ROOT.rglob("*"):
            if path.is_file() and path.suffix not in {".png", ".zip", ".pyc"}:
                self.assertNotIn(banned, path.read_text(encoding="utf-8", errors="ignore").lower())

    def test_required_assets(self):
        for name in ("wallpaper.png", "lock.png", "terminal-art.png"):
            path = ROOT / "assets" / name
            self.assertGreater(path.stat().st_size, 1024)
        for name in ("desktop-login.wav", "message-new-instant.wav", "bell-terminal.wav"):
            path = ROOT / "assets/sounds/LAINTheme/stereo" / name
            self.assertGreater(path.stat().st_size, 1024)


if __name__ == "__main__":
    unittest.main()

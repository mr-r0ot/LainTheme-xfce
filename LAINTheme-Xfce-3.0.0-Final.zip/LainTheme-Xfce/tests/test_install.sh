#!/usr/bin/env bash
set -Eeuo pipefail

root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
test_root="$(mktemp -d)"
trap 'rm -rf -- "$test_root"' EXIT
export HOME="$test_root/home"
export XDG_CONFIG_HOME="$HOME/.config"
export XDG_DATA_HOME="$HOME/.local/share"
export XDG_STATE_HOME="$HOME/.local/state"
export XDG_CURRENT_DESKTOP=XFCE
export XDG_SESSION_TYPE=x11
unset DISPLAY
mkdir -p "$HOME" "$XDG_CONFIG_HOME/autostart" "$XDG_CONFIG_HOME/xfce4/terminal"
printf 'original-zshrc\n' >"$HOME/.zshrc"
printf 'original-terminal\n' >"$XDG_CONFIG_HOME/xfce4/terminal/terminalrc"
printf '[Desktop Entry]\nName=Original Panel\n' >"$XDG_CONFIG_HOME/autostart/xfce4-panel.desktop"

dry_output="$test_root/dry.out"
"$root/install.sh" --profile lite --dry-run --no-packages --no-lightdm --no-start --skip-shell-network >"$dry_output"
[[ "$(grep -Ec '^\[[0-9]{2}/11\]' "$dry_output")" == 11 ]]
[[ "$(<"$HOME/.zshrc")" == original-zshrc ]]

before="$test_root/before"
mkdir -p "$before"
cp -a "$HOME/.zshrc" "$XDG_CONFIG_HOME/autostart/xfce4-panel.desktop" "$XDG_CONFIG_HOME/xfce4/terminal/terminalrc" "$before/"

"$root/install.sh" --profile high --no-packages --no-lightdm --no-start --skip-shell-network >"$test_root/install.out"
test -x "$HOME/.local/bin/lain-shell"
test -x "$HOME/.local/bin/lain-settings"
test -s "$XDG_DATA_HOME/lain-theme/assets/wallpaper.png"
grep -q '"name":"high"' "$XDG_CONFIG_HOME/lain-theme/profile.json"
grep -q '^# BEGIN LAINTHEME$' "$HOME/.zshrc"

"$HOME/.local/bin/lainctl" repair high --no-start >/dev/null 2>&1 || {
  printf 'repair command failed\n' >&2
  exit 1
}
test -s "$XDG_DATA_HOME/lain-theme/install.sh"

"$HOME/.local/bin/lainctl" uninstall >"$test_root/uninstall.out"
cmp "$before/.zshrc" "$HOME/.zshrc"
cmp "$before/xfce4-panel.desktop" "$XDG_CONFIG_HOME/autostart/xfce4-panel.desktop"
cmp "$before/terminalrc" "$XDG_CONFIG_HOME/xfce4/terminal/terminalrc"
test ! -e "$HOME/.local/bin/lain-shell"
printf 'install-rollback-pass\n'

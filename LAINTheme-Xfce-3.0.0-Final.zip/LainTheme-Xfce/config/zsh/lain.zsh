# LAINTheme prompt and shell integration. No framework is required.
autoload -Uz colors && colors
zmodload zsh/datetime 2>/dev/null || true
setopt prompt_subst hist_ignore_all_dups share_history auto_cd interactive_comments
HISTFILE="${XDG_STATE_HOME:-$HOME/.local/state}/zsh/history"
mkdir -p "${HISTFILE:h}"
HISTSIZE=10000
SAVEHIST=10000

typeset -g LAIN_CMD_STARTED=0
lain_preexec() { LAIN_CMD_STARTED=$EPOCHREALTIME }
lain_precmd() {
  local code=$?
  local branch="" duration=""
  if command git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    branch=" %F{141}$(command git branch --show-current 2>/dev/null)%f"
    [[ -n "$(command git status --porcelain 2>/dev/null)" ]] && branch+="%F{203}*%f"
  fi
  if (( LAIN_CMD_STARTED > 0 )); then
    local elapsed=$(( EPOCHREALTIME - LAIN_CMD_STARTED ))
    (( elapsed >= 1 )) && duration=" %F{244}${elapsed}s%f"
  fi
  local status=""
  (( code != 0 )) && status=" %F{203}exit:${code}%f"
  PROMPT="%F{81}╭─%f %F{111}%n%f@%F{147}%m%f %F{75}%~%f${branch}${duration}${status}\n%F{81}╰─λ%f "
  LAIN_CMD_STARTED=0
}
autoload -Uz add-zsh-hook
add-zsh-hook preexec lain_preexec
add-zsh-hook precmd lain_precmd

alias ll='ls -alF --color=auto'
alias la='ls -A --color=auto'
alias grep='grep --color=auto'
alias update='sudo apt update && sudo apt upgrade'

[[ -r /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh ]] && source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh
[[ -r /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh ]] && source /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh
[[ -r /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh ]] && source /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
[[ -r /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh ]] && source /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh

if [[ -o interactive && -t 1 && -z "${LAIN_FETCH_SHOWN:-}" ]]; then
  export LAIN_FETCH_SHOWN=1
  art="${XDG_DATA_HOME:-$HOME/.local/share}/lain-theme/assets/terminal-art.png"
  command -v chafa >/dev/null 2>&1 && [[ -f "$art" ]] && chafa --size 42x18 "$art"
  if command -v fastfetch >/dev/null 2>&1; then fastfetch
  elif command -v neofetch >/dev/null 2>&1; then neofetch --off
  fi
fi

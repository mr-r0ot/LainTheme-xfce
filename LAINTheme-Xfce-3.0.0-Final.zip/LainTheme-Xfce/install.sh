#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROFILE="lite"
DRY_RUN=0
INSTALL_PACKAGES=1
INSTALL_LIGHTDM=1
START_NOW=1
OH_MY_ZSH=1

while (($#)); do
  case "$1" in
    --profile) PROFILE="${2:-}"; shift 2 ;;
    --profile=*) PROFILE="${1#*=}"; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    --no-packages) INSTALL_PACKAGES=0; shift ;;
    --no-lightdm) INSTALL_LIGHTDM=0; shift ;;
    --no-start) START_NOW=0; shift ;;
    --skip-shell-network) OH_MY_ZSH=0; shift ;;
    -h|--help)
      printf 'Usage: %s [--profile lite|high] [--dry-run] [--no-packages] [--no-lightdm] [--no-start] [--skip-shell-network]\n' "$0"
      exit 0 ;;
    *) printf 'Unknown option: %s\n' "$1" >&2; exit 2 ;;
  esac
done

[[ "$PROFILE" == "lite" || "$PROFILE" == "high" ]] || { printf 'Profile must be lite or high.\n' >&2; exit 2; }

CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
BIN_HOME="$HOME/.local/bin"
DATA_DIR="$DATA_HOME/lain-theme"
CONFIG_DIR="$CONFIG_HOME/lain-theme"
STATE_DIR="$STATE_HOME/lain-theme"
AUTOSTART_DIR="$CONFIG_HOME/autostart"
BACKUP_ROOT="$STATE_DIR/backups/$(date +%Y%m%d-%H%M%S)-$$"
MANIFEST="$BACKUP_ROOT/manifest.tsv"
CURRENT_BACKUP="$STATE_DIR/current-backup"
INSTALL_STATE="$STATE_DIR/install-state"
PREVIOUS_BACKUP=""
if [[ -f "$CURRENT_BACKUP" ]]; then
  candidate="$(<"$CURRENT_BACKUP")"
  [[ -f "$candidate/manifest.tsv" ]] && PREVIOUS_BACKUP="$candidate"
fi
ROLLBACK_ARMED=0

step() { printf '\n[%02d/11] %s\n' "$1" "$2"; }
note() { printf '         %s\n' "$*"; }
run_mutation() {
  if ((DRY_RUN)); then printf '         DRY-RUN:'; printf ' %q' "$@"; printf '\n'; else "$@"; fi
}

backup_path() {
  local path="$1"
  local relative="${path#/}"
  local saved="$BACKUP_ROOT/user/$relative"
  if [[ -e "$path" || -L "$path" ]]; then
    printf 'E\t%s\n' "$path" >>"$MANIFEST"
    mkdir -p "$(dirname "$saved")"
    cp -a -- "$path" "$saved"
  else
    printf 'M\t%s\n' "$path" >>"$MANIFEST"
  fi
}

restore_user_backup() {
  local kind path saved
  [[ -f "$MANIFEST" ]] || return 0
  while IFS=$'\t' read -r kind path; do
    [[ -n "$path" ]] || continue
    saved="$BACKUP_ROOT/user/${path#/}"
    if [[ "$kind" == "E" ]]; then
      rm -rf -- "$path"
      mkdir -p "$(dirname "$path")"
      cp -a -- "$saved" "$path"
    else
      rm -rf -- "$path"
    fi
  done <"$MANIFEST"
}

restore_system_backup() {
  local system_backup="$BACKUP_ROOT/system"
  [[ -d "$system_backup" ]] || return 0
  local greeter_conf=/etc/lightdm/lightdm-gtk-greeter.conf.d/90-lain-theme.conf
  local system_wallpaper=/usr/local/share/backgrounds/lain-lock.png
  if [[ -f "$system_backup/greeter.state" ]]; then
    if [[ "$(<"$system_backup/greeter.state")" == E && -f "$system_backup/greeter.conf" ]]; then sudo cp -a "$system_backup/greeter.conf" "$greeter_conf"
    else sudo rm -f -- "$greeter_conf"
    fi
  fi
  if [[ -f "$system_backup/wallpaper.state" ]]; then
    if [[ "$(<"$system_backup/wallpaper.state")" == E && -f "$system_backup/lain-lock.png" ]]; then sudo cp -a "$system_backup/lain-lock.png" "$system_wallpaper"
    else sudo rm -f -- "$system_wallpaper"
    fi
  fi
}

rollback_on_error() {
  local code=$?
  trap - ERR
  if ((ROLLBACK_ARMED && !DRY_RUN)); then
    printf '\n[ROLLBACK] Installation failed; restoring the captured user state.\n' >&2
    restore_system_backup || true
    restore_user_backup || true
    if [[ -n "$PREVIOUS_BACKUP" ]]; then printf '%s\n' "$PREVIOUS_BACKUP" >"$CURRENT_BACKUP"; else rm -f -- "$CURRENT_BACKUP"; fi
  fi
  exit "$code"
}
trap rollback_on_error ERR

step 1 "Preflight and target validation"
[[ -f "$PROJECT_ROOT/src/lain_shell/app.py" ]] || { note "Invalid release: shell source is missing"; exit 1; }
[[ -f "$PROJECT_ROOT/assets/wallpaper.png" ]] || { note "Invalid release: wallpaper is missing"; exit 1; }
if [[ "${XDG_CURRENT_DESKTOP:-XFCE}" != *XFCE* && "${XDG_CURRENT_DESKTOP:-XFCE}" != *Xfce* ]]; then
  note "Warning: this release targets XFCE/X11; installation continues for the next XFCE login."
fi
if [[ "${XDG_SESSION_TYPE:-x11}" != "x11" ]]; then
  note "Warning: the shell will stay inactive outside an X11 session."
fi
note "Profile: $PROFILE"

step 2 "Transactional backup"
if ((DRY_RUN)); then
  note "Would snapshot managed user files under $BACKUP_ROOT"
else
  mkdir -p "$BACKUP_ROOT" "$STATE_DIR"
  : >"$MANIFEST"
  for path in \
    "$DATA_DIR" "$CONFIG_DIR" "$DATA_HOME/sounds/LAINTheme" \
    "$BIN_HOME/lain-shell" "$BIN_HOME/lain-launcher" "$BIN_HOME/lain-terminal" \
    "$BIN_HOME/lain-lock" "$BIN_HOME/lain-session-start" "$BIN_HOME/lain-compositor" "$BIN_HOME/lain-settings" "$BIN_HOME/lainctl" \
    "$AUTOSTART_DIR/lain-shell.desktop" "$AUTOSTART_DIR/xfce4-panel.desktop" \
    "$CONFIG_HOME/systemd/user/lain-shell.service" \
    "$CONFIG_HOME/xfce4/terminal/terminalrc" "$HOME/.zshrc" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-keyboard-shortcuts.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-terminal.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml" \
    "$CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml"; do
    backup_path "$path"
  done
  ROLLBACK_ARMED=1
fi

step 3 "Dependencies (missing packages only)"
install_debian_packages() {
  local packages=(python3 python3-gi python3-xlib gir1.2-gtk-3.0 wmctrl xdotool network-manager bluez brightnessctl ffmpeg xfce4-screenshooter i3lock chafa zsh zsh-autosuggestions zsh-syntax-highlighting fonts-jetbrains-mono libnotify-bin)
  [[ "$PROFILE" == "high" ]] && packages+=(picom)
  [[ -d /etc/lightdm && "$INSTALL_LIGHTDM" == 1 ]] && packages+=(lightdm-gtk-greeter)
  local missing=() package
  for package in "${packages[@]}"; do dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q 'install ok installed' || missing+=("$package"); done
  if ((${#missing[@]})); then
    note "Installing ${#missing[@]} missing packages"
    run_mutation sudo apt-get update -qq
    run_mutation sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${missing[@]}"
  else
    note "All required packages already installed; apt update skipped"
  fi
}
install_arch_packages() {
  local packages=(python python-gobject python-xlib gtk3 wmctrl xdotool networkmanager bluez brightnessctl ffmpeg xfce4-screenshooter i3lock chafa zsh zsh-autosuggestions zsh-syntax-highlighting ttf-jetbrains-mono libnotify)
  [[ "$PROFILE" == "high" ]] && packages+=(picom)
  local missing=() package
  for package in "${packages[@]}"; do pacman -Q "$package" >/dev/null 2>&1 || missing+=("$package"); done
  ((${#missing[@]})) && run_mutation sudo pacman -S --needed --noconfirm "${missing[@]}" || note "All required packages already installed"
}
if ((INSTALL_PACKAGES)); then
  if command -v apt-get >/dev/null 2>&1; then install_debian_packages
  elif command -v pacman >/dev/null 2>&1; then install_arch_packages
  else note "Unsupported package manager; diagnose will report any missing runtime command"
  fi
else note "Package installation disabled"
fi

step 4 "Atomic application files"
if ((DRY_RUN)); then
  note "Would install shell, assets and commands into user directories"
else
  staging="$DATA_DIR.staging-$$"
  rm -rf -- "$staging"
  mkdir -p "$staging" "$BIN_HOME"
  cp -a "$PROJECT_ROOT/src" "$PROJECT_ROOT/assets" "$PROJECT_ROOT/config" "$PROJECT_ROOT/bin" "$PROJECT_ROOT/install.sh" "$PROJECT_ROOT/uninstall.sh" "$staging/"
  [[ -d "$PROJECT_ROOT/oh-my-zsh" ]] && cp -a "$PROJECT_ROOT/oh-my-zsh" "$staging/" || true
  rm -rf -- "$DATA_DIR"
  mv -- "$staging" "$DATA_DIR"
  install -m 0755 "$PROJECT_ROOT"/bin/* "$BIN_HOME/"
  install -m 0755 "$PROJECT_ROOT/bin/lainctl" "$BIN_HOME/lainctl"
  mkdir -p "$DATA_HOME/sounds"
  cp -a "$PROJECT_ROOT/assets/sounds/LAINTheme" "$DATA_HOME/sounds/"
fi

step 5 "Lite/High compositor policy"
if ((DRY_RUN)); then
  note "Would write $PROFILE profile and compositor policy"
else
  mkdir -p "$CONFIG_DIR"
  printf '{"name":"%s"}\n' "$PROFILE" >"$CONFIG_DIR/profile.json"
  install -m 0644 "$PROJECT_ROOT/config/picom.conf" "$CONFIG_DIR/picom.conf"
  if command -v xfconf-query >/dev/null 2>&1; then
    if [[ "$PROFILE" == "lite" ]]; then
      xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s true >/dev/null 2>&1 || true
    fi
  fi
fi

step 6 "Panel replacement and autostart"
if ((DRY_RUN)); then
  note "Would disable only the stock XFCE panel autostart and enable LAINTheme Shell"
else
  mkdir -p "$AUTOSTART_DIR"
  install -m 0644 "$PROJECT_ROOT/config/autostart/lain-shell.desktop" "$AUTOSTART_DIR/lain-shell.desktop"
  install -m 0644 "$PROJECT_ROOT/config/autostart/xfce4-panel.desktop" "$AUTOSTART_DIR/xfce4-panel.desktop"
  mkdir -p "$CONFIG_HOME/systemd/user"
  sed "s|@LAIN_SHELL@|$BIN_HOME/lain-shell|g" "$PROJECT_ROOT/config/lain-shell.service" >"$CONFIG_HOME/systemd/user/lain-shell.service"
  systemctl --user daemon-reload >/dev/null 2>&1 || true
fi

step 7 "Workspaces and conflict-free shortcuts"
if ((DRY_RUN)); then
  note "Would bind Super+Z to LAIN launcher and Ctrl+Alt+L to LAIN lock"
elif command -v xfconf-query >/dev/null 2>&1; then
  xfconf-query -c xfwm4 -p /general/workspace_count -n -t int -s 9 >/dev/null 2>&1 || true
  shortcut_properties="$(xfconf-query -c xfce4-keyboard-shortcuts -l 2>/dev/null || true)"
  while IFS= read -r property; do
    [[ -n "$property" ]] || continue
    value="$(xfconf-query -c xfce4-keyboard-shortcuts -p "$property" 2>/dev/null || true)"
    case "$property" in
      *\<Super\>*space*|*\<Super\>)
        [[ "$value" == *xfce4-appfinder* || "$value" == *xfce4-popup-applicationsmenu* ]] && xfconf-query -c xfce4-keyboard-shortcuts -p "$property" -r >/dev/null 2>&1 || true ;;
    esac
  done <<<"$shortcut_properties"
  xfconf-query -c xfce4-keyboard-shortcuts -p '/commands/custom/<Super>z' -n -t string -s 'lain-launcher' >/dev/null 2>&1 || true
  xfconf-query -c xfce4-keyboard-shortcuts -p '/commands/custom/<Primary><Alt>l' -n -t string -s 'lain-lock' >/dev/null 2>&1 || true
  for workspace in {1..9}; do
    xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Super>$workspace" -n -t string -s "workspace_${workspace}_key" >/dev/null 2>&1 || true
  done
  xfconf-query -c xfce4-session -p /general/LockCommand -n -t string -s 'lain-lock' >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Net/SoundThemeName -n -t string -s 'LAINTheme' >/dev/null 2>&1 || true
  xfconf-query -c xsettings -p /Net/EnableEventSounds -n -t bool -s true >/dev/null 2>&1 || true
fi

step 8 "Desktop wallpaper and terminal profile"
if ((DRY_RUN)); then
  note "Would apply wallpaper to every existing XFCE monitor/workspace property"
else
  terminal_dir="$CONFIG_HOME/xfce4/terminal"
  mkdir -p "$terminal_dir"
  sed "s|@TERMINAL_ART@|$DATA_DIR/assets/terminal-art.png|g" "$PROJECT_ROOT/config/xfce-terminal/terminalrc" >"$terminal_dir/terminalrc"
  if command -v xfconf-query >/dev/null 2>&1; then
    wallpaper_properties="$(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep '/last-image$' || true)"
    [[ -n "$wallpaper_properties" ]] || wallpaper_properties=/backdrop/screen0/monitor0/workspace0/last-image
    while IFS= read -r property; do
      [[ -n "$property" ]] || continue
      xfconf-query -c xfce4-desktop -p "$property" -n -t string -s "$DATA_DIR/assets/wallpaper.png" >/dev/null 2>&1 || true
      style_property="${property%/last-image}/image-style"
      xfconf-query -c xfce4-desktop -p "$style_property" -n -t int -s 5 >/dev/null 2>&1 || true
    done <<<"$wallpaper_properties"
    xfdesktop --reload >/dev/null 2>&1 || true
    # Xfce Terminal 1.1+ uses xfconf; terminalrc remains the older-version fallback.
    xfconf-query -c xfce4-terminal -p /font-name -n -t string -s 'JetBrains Mono 11' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /color-foreground -n -t string -s '#E8EAF2' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /color-background -n -t string -s '#080A12' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /background-mode -n -t string -s 'TERMINAL_BACKGROUND_IMAGE' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /background-image-file -n -t string -s "$DATA_DIR/assets/terminal-art.png" >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /background-image-style -n -t string -s 'TERMINAL_BACKGROUND_STYLE_SCALED' >/dev/null 2>&1 || true
    xfconf-query -c xfce4-terminal -p /background-darkness -n -t double -s 0.86 >/dev/null 2>&1 || true
  fi
fi

step 9 "Zsh, prompt and optional Oh My Zsh"
if ((DRY_RUN)); then
  note "Would add one managed source line to .zshrc"
else
  mkdir -p "$CONFIG_DIR/zsh"
  install -m 0644 "$PROJECT_ROOT/config/zsh/lain.zsh" "$CONFIG_DIR/zsh/lain.zsh"
  if ((OH_MY_ZSH)) && command -v git >/dev/null 2>&1 && [[ ! -d "$DATA_DIR/oh-my-zsh/.git" ]]; then
    note "Trying shallow Oh My Zsh install (20-second limit)"
    timeout 20 git clone --depth=1 https://github.com/ohmyzsh/ohmyzsh.git "$DATA_DIR/oh-my-zsh" >/dev/null 2>&1 || note "Network unavailable; packaged shell integration remains active"
  fi
  touch "$HOME/.zshrc"
  sed -i '/^# BEGIN LAINTHEME$/,/^# END LAINTHEME$/d' "$HOME/.zshrc"
  {
    printf '\n# BEGIN LAINTHEME\n'
    printf 'export ZSH="${XDG_DATA_HOME:-$HOME/.local/share}/lain-theme/oh-my-zsh"\n'
    printf 'if [[ -r "$ZSH/oh-my-zsh.sh" ]]; then ZSH_THEME=""; plugins=(git); source "$ZSH/oh-my-zsh.sh"; fi\n'
    printf 'source "${XDG_CONFIG_HOME:-$HOME/.config}/lain-theme/zsh/lain.zsh"\n'
    printf '# END LAINTHEME\n'
  } >>"$HOME/.zshrc"
fi

step 10 "Secure lock and LightDM greeter"
if ((DRY_RUN)); then
  note "Would install LightDM GTK greeter override with rollback metadata"
elif ((INSTALL_LIGHTDM)) && [[ -d /etc/lightdm ]] && command -v sudo >/dev/null 2>&1; then
  system_backup="$BACKUP_ROOT/system"
  mkdir -p "$system_backup"
  greeter_conf=/etc/lightdm/lightdm-gtk-greeter.conf.d/90-lain-theme.conf
  system_wallpaper=/usr/local/share/backgrounds/lain-lock.png
  if sudo test -e "$greeter_conf"; then sudo cp -a "$greeter_conf" "$system_backup/greeter.conf"; printf 'E\n' >"$system_backup/greeter.state"; else printf 'M\n' >"$system_backup/greeter.state"; fi
  if sudo test -e "$system_wallpaper"; then sudo cp -a "$system_wallpaper" "$system_backup/lain-lock.png"; printf 'E\n' >"$system_backup/wallpaper.state"; else printf 'M\n' >"$system_backup/wallpaper.state"; fi
  sudo install -d -m 0755 /etc/lightdm/lightdm-gtk-greeter.conf.d /usr/local/share/backgrounds
  sudo install -m 0644 "$PROJECT_ROOT/assets/lock.png" "$system_wallpaper"
  printf '[greeter]\nbackground=%s\nuser-background=false\ntheme-name=Adwaita-dark\nicon-theme-name=Adwaita\nfont-name=JetBrains Mono 11\nclock-format=%%A  %%H:%%M\nindicators=~host;~spacer;~clock;~spacer;~session;~language;~a11y;~power\n' "$system_wallpaper" | sudo tee "$greeter_conf" >/dev/null
  sudo chown -R "$(id -u):$(id -g)" "$system_backup" 2>/dev/null || true
else
  note "LightDM not detected or disabled; session lock is installed, greeter was not modified"
fi

step 11 "Validation and session activation"
if ((DRY_RUN)); then
  note "Dry run complete; no files were changed"
  trap - ERR
  exit 0
fi
if [[ -n "$PREVIOUS_BACKUP" ]]; then
  # Preserve the first pre-install snapshot across upgrades and repairs.
  while IFS=$'\t' read -r kind path; do
    grep -Fq $'\t'"$path" "$PREVIOUS_BACKUP/manifest.tsv" || printf 'M\t%s\n' "$path" >>"$PREVIOUS_BACKUP/manifest.tsv"
  done <"$MANIFEST"
  ACTIVE_BACKUP="$PREVIOUS_BACKUP"
  rm -rf -- "$BACKUP_ROOT"
else
  ACTIVE_BACKUP="$BACKUP_ROOT"
fi
printf '%s\n' "$ACTIVE_BACKUP" >"$CURRENT_BACKUP"
cat >"$INSTALL_STATE" <<EOF
PROFILE=$PROFILE
BACKUP_ROOT=$ACTIVE_BACKUP
VERSION=3.0.0
EOF
chmod 600 "$INSTALL_STATE"
if ((START_NOW)) && [[ -n "${DISPLAY:-}" ]]; then
  "$BIN_HOME/lain-session-start" >/dev/null 2>&1 &
  sleep 1
fi
if ! "$BIN_HOME/lainctl" diagnose --quiet; then
  note "Installed, but runtime diagnostics found issues. Run: lainctl diagnose"
else
  note "Runtime diagnostics passed"
fi
ROLLBACK_ARMED=0
trap - ERR
printf '\n[DONE] LAINTheme-Xfce 3.0.0 installed with profile %s.\n' "$PROFILE"

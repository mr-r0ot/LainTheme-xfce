"""LAINTheme XFCE shell."""

__version__ = "3.0.0"


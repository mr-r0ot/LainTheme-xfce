# Acceptance matrix

This file is the project boundary. A release is code-complete only when every row has an implementation and an automated check where the build environment can exercise it.

| Area | Required outcome | Implementation | Automated evidence |
| --- | --- | --- | --- |
| Top panel | Thin top placement, centered time, working first-click controls | unconstrained mapped-state popovers, one `PanelWindow` per monitor | callback, lifecycle, multi-monitor and strut contract tests |
| Work area | Maximized windows do not occupy the top panel area | EWMH partial strut; XFWM margins are not changed | Strut static contract |
| Launcher | Applications UI on `Super+Z`; no launcher on bare Super/Space | `LauncherPopover`, transactional XFConf binding | Shortcut contract and install rollback test |
| Workspaces | Nine clickable desktops and `Super+1..9` | panel buttons, `wmctrl`, XFWM bindings | Shortcut contract |
| Dock | Pinned/open grouping, activate, close, pin, DnD, large Papirus icons | `group_windows`, diff-driven `DockWindow`, explicit pixel size | grouping, size and no-rebuild tests |
| Dock hide | Monitor-local fullscreen/maximize/overlap behavior | geometry-aware intellihide | Pure overlap tests |
| Wi-Fi | Power, scan, password, connect, disconnect, errors | NetworkManager `nmcli` backend | Python compile and backend isolation |
| Bluetooth | Power, scan, pair/trust/connect, PIN/passkey UI | BlueZ agent plus `bluetoothctl` backend | Agent contract test |
| Media controls | Volume, brightness, screenshot, recording toggle | PipeWire/PulseAudio, brightnessctl, screenshot backends, FFmpeg PID state | Python compile and command model tests |
| Notifications | Freedesktop API, history, unread, actions, clear | Gio DBus service and bounded JSON store | Signature and store unit tests |
| Lock | Real display-manager seat lock and secure fallback | LightDM `dm-tool lock`, i3lock, XFConf LockCommand | order and installer contracts |
| Login | Actual LightDM GTK Greeter appearance | explicit seat greeter plus reversible system theme/config | fake-root install/uninstall transaction |
| Wallpaper | Desktop image on existing monitors/workspaces | enumerated XFCE backdrop properties | Installer contract and PNG test |
| Terminal | isolated Zsh/Oh My Zsh, prompt states, suggestions/highlighting, reference art | private framework, replacement zshrc and terminal profile | isolation, syntax and rollback tests |
| Visual stack | Exact reference GTK/XFWM theme, Papirus-Dark and JetBrains Mono | user/system theme copies, XFConf and Fontconfig | release and isolated-install contracts |
| Profiles | Lite uses XFWM; High supervises Picom with fallback | profile file and compositor wrapper | release contract |
| Safety | 11 visible stages, fast dependency path, exact rollback | transactional installer/uninstaller | isolated install/repair/uninstall test |

Compatibility boundary:

- XFCE on X11;
- GTK3 and an EWMH-compliant window manager, normally XFWM4;
- NetworkManager for Wi-Fi and BlueZ for Bluetooth;
- LightDM GTK Greeter for system login theming.

Wayland and other desktop/display-manager stacks are excluded rather than handled through unverified compatibility branches.

from __future__ import annotations

import json

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from .config import CONFIG_DIR, Profile, UserConfig, ensure_runtime_dirs


class SettingsWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="LAINTheme Settings")
        ensure_runtime_dirs()
        self.config = UserConfig.load()
        self.profile = Profile.load()
        self.set_default_size(430, 320)
        self.set_border_width(18)
        self.set_position(Gtk.WindowPosition.CENTER)
        grid = Gtk.Grid(column_spacing=18, row_spacing=16)
        self.add(grid)
        title = Gtk.Label()
        title.set_markup("<span size='x-large' weight='bold'>LAINTheme</span>\nXFCE Shell settings")
        title.set_xalign(0)
        grid.attach(title, 0, 0, 2, 1)
        grid.attach(Gtk.Label(label="Profile", xalign=0), 0, 1, 1, 1)
        self.profile_combo = Gtk.ComboBoxText()
        self.profile_combo.append("lite", "Lite · XFWM compositor")
        self.profile_combo.append("high", "High · Picom and extended motion")
        self.profile_combo.set_active_id(self.profile.name)
        grid.attach(self.profile_combo, 1, 1, 1, 1)
        grid.attach(Gtk.Label(label="Dock auto-hide", xalign=0), 0, 2, 1, 1)
        self.autohide = Gtk.Switch(active=self.config.dock_autohide)
        self.autohide.set_halign(Gtk.Align.START)
        grid.attach(self.autohide, 1, 2, 1, 1)
        grid.attach(Gtk.Label(label="Workspaces", xalign=0), 0, 3, 1, 1)
        self.workspaces = Gtk.SpinButton.new_with_range(1, 12, 1)
        self.workspaces.set_value(self.config.workspaces)
        grid.attach(self.workspaces, 1, 3, 1, 1)
        note = Gtk.Label(label="Profile and workspace changes take effect at the next login.", xalign=0)
        note.set_line_wrap(True)
        grid.attach(note, 0, 4, 2, 1)
        save = Gtk.Button(label="Save settings")
        save.connect("clicked", self._save)
        grid.attach(save, 1, 5, 1, 1)

    def _save(self, *_):
        self.config.dock_autohide = self.autohide.get_active()
        self.config.workspaces = self.workspaces.get_value_as_int()
        self.config.save()
        (CONFIG_DIR / "profile.json").write_text(
            json.dumps({"name": self.profile_combo.get_active_id()}), encoding="utf-8"
        )
        dialog = Gtk.MessageDialog(
            transient_for=self, modal=True, message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK, text="Settings saved",
        )
        dialog.format_secondary_text("Log out and back in to apply every change.")
        dialog.run()
        dialog.destroy()


def main() -> int:
    window = SettingsWindow()
    window.connect("destroy", Gtk.main_quit)
    window.show_all()
    Gtk.main()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


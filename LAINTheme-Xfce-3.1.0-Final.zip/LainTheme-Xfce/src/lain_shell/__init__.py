"""LAINTheme XFCE shell."""

__version__ = "3.1.0"

from __future__ import annotations

import html
import os
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, Pango  # noqa: E402

from . import system, x11
from .command import available, run, spawn
from .config import ASSET_DIR, Profile, UserConfig
from .desktop import DesktopApp, app_metadata
from .models import AppGroup, Monitor, Window, group_windows, overlaps
from .notifications import NotificationStore


def icon_image(name: str, size: int = 18) -> Gtk.Image:
    if name and Path(name).is_file():
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(name, size, size, True)
            return Gtk.Image.new_from_pixbuf(pixbuf)
        except GLib.Error:
            pass
    image = Gtk.Image.new_from_icon_name(name or "application-x-executable", Gtk.IconSize.BUTTON)
    image.set_pixel_size(size)
    return image


def icon_button(icon: str, tooltip: str, callback: Callable | None = None, css_class: str = "icon-button") -> Gtk.Button:
    button = Gtk.Button()
    button.add(icon_image(icon))
    button.set_tooltip_text(tooltip)
    button.get_style_context().add_class(css_class)
    if callback:
        button.connect("clicked", callback)
    return button


def text_button(text: str, callback: Callable | None = None, css_class: str = "text-button") -> Gtk.Button:
    button = Gtk.Button(label=text)
    button.get_style_context().add_class(css_class)
    if callback:
        button.connect("clicked", callback)
    return button


class AsyncWorker:
    def __init__(self, workers: int = 4):
        self.pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="lain")

    def submit(self, function: Callable, callback: Callable | None = None,
               error: Callable | None = None) -> None:
        future = self.pool.submit(function)

        def finished(done):
            try:
                value = done.result()
            except Exception as exc:  # runtime backends must not crash GTK
                if error:
                    GLib.idle_add(error, exc)
                return
            if callback:
                GLib.idle_add(callback, value)

        future.add_done_callback(finished)

    def shutdown(self) -> None:
        self.pool.shutdown(wait=False, cancel_futures=True)


class ManagedPopover(Gtk.Popover):
    def __init__(self, relative_to: Gtk.Widget):
        super().__init__(relative_to=relative_to)
        self.set_modal(True)
        self.set_position(Gtk.PositionType.BOTTOM)
        # A panel is only a few pixels high. WINDOW confinement makes a large
        # popover appear clipped or completely absent on XFCE/X11 docks.
        self.set_constrain_to(Gtk.PopoverConstraint.NONE)
        self.get_style_context().add_class("lain-popover")

    def toggle(self) -> None:
        # show_all() makes child widgets visible during construction, but the
        # popover is not necessarily mapped. get_visible() therefore consumed
        # the first click as a no-op popdown on some GTK3/XFCE combinations.
        if self.get_mapped():
            self.popdown()
        else:
            self.popup()


class ErrorBanner(Gtk.Revealer):
    def __init__(self):
        super().__init__()
        self.set_transition_type(Gtk.RevealerTransitionType.SLIDE_DOWN)
        self.label = Gtk.Label(xalign=0)
        self.label.set_line_wrap(True)
        self.label.get_style_context().add_class("error-banner")
        self.add(self.label)

    def show_error(self, message: str) -> None:
        self.label.set_text(message.strip() or "Operation failed")
        self.set_reveal_child(True)
        GLib.timeout_add_seconds(8, self._hide)

    def _hide(self) -> bool:
        self.set_reveal_child(False)
        return GLib.SOURCE_REMOVE


class LauncherPopover(ManagedPopover):
    def __init__(self, relative_to: Gtk.Widget, apps: dict[str, DesktopApp],
                 config: UserConfig, changed: Callable[[], None]):
        super().__init__(relative_to)
        self.apps = apps
        self.config = config
        self.changed = changed
        self.search = Gtk.SearchEntry(placeholder_text="Search applications")
        self.search.connect("search-changed", self._filter)
        self.flow = Gtk.FlowBox()
        self.flow.set_selection_mode(Gtk.SelectionMode.NONE)
        self.flow.set_max_children_per_line(5)
        self.flow.set_min_children_per_line(5)
        self.flow.set_row_spacing(8)
        self.flow.set_column_spacing(8)
        self.flow.set_filter_func(self._filter_item)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_size_request(520, 440)
        scroller.add(self.flow)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_border_width(12)
        box.pack_start(self.search, False, False, 0)
        box.pack_start(scroller, True, True, 0)
        self.add(box)
        for app in apps.values():
            self.flow.add(self._app_button(app))
        self.connect("show", lambda *_: (self.search.set_text(""), self.search.grab_focus()))
        self.show_all()

    def _app_button(self, app: DesktopApp) -> Gtk.Button:
        button = Gtk.Button()
        button.app = app
        button.set_size_request(92, 86)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        content.pack_start(icon_image(app.icon, 38), False, False, 0)
        label = Gtk.Label(label=app.name, max_width_chars=12)
        label.set_ellipsize(Pango.EllipsizeMode.END)
        content.pack_start(label, False, False, 0)
        button.add(content)
        button.get_style_context().add_class("app-button")
        button.set_tooltip_text(app.comment or app.name)
        button.connect("clicked", lambda *_: (app.launch(), self.popdown()))
        button.connect("button-press-event", self._context_menu, app)
        targets = [Gtk.TargetEntry.new("application/x-lain-desktop-id", Gtk.TargetFlags.SAME_APP, 0)]
        button.drag_source_set(Gdk.ModifierType.BUTTON1_MASK, targets, Gdk.DragAction.COPY)
        button.connect("drag-data-get", self._drag_data, app.desktop_id)
        return button

    @staticmethod
    def _drag_data(_widget, _context, selection, _info, _time, desktop_id: str) -> None:
        selection.set_text(desktop_id, -1)

    def _context_menu(self, _button, event, app: DesktopApp):
        if event.button != 3:
            return False
        menu = Gtk.Menu()
        pinned = app.desktop_id in self.config.pinned
        item = Gtk.MenuItem(label="Unpin from Dock" if pinned else "Pin to Dock")

        def toggle(*_):
            if pinned:
                self.config.pinned.remove(app.desktop_id)
            else:
                self.config.pinned.append(app.desktop_id)
            self.config.save()
            self.changed()

        item.connect("activate", toggle)
        menu.append(item)
        menu.show_all()
        menu.popup_at_pointer(event)
        return True

    def _filter(self, *_):
        self.flow.invalidate_filter()

    def _filter_item(self, child) -> bool:
        query = self.search.get_text().strip().casefold()
        app = child.get_child().app
        return not query or query in app.name.casefold() or query in app.comment.casefold()


class ControlCenterPopover(ManagedPopover):
    def __init__(self, relative_to: Gtk.Widget, worker: AsyncWorker):
        super().__init__(relative_to)
        self.worker = worker
        self.error = ErrorBanner()
        self.wifi_toggle = Gtk.ToggleButton(label="Wi-Fi")
        self.bt_toggle = Gtk.ToggleButton(label="Bluetooth")
        self.airplane_toggle = Gtk.ToggleButton(label="Airplane")
        for button in (self.wifi_toggle, self.bt_toggle, self.airplane_toggle):
            button.get_style_context().add_class("quick-tile")
        self.wifi_toggle.connect("toggled", self._toggle_wifi)
        self.bt_toggle.connect("toggled", self._toggle_bluetooth)
        self.airplane_toggle.connect("toggled", self._toggle_airplane)
        self.wifi_list = Gtk.ListBox()
        self.bt_list = Gtk.ListBox()
        self.volume_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 150, 1)
        self.brightness_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 1, 100, 1)
        self.volume_scale.set_draw_value(False)
        self.brightness_scale.set_draw_value(False)
        self.volume_scale.connect("value-changed", self._volume_changed)
        self.brightness_scale.connect("value-changed", self._brightness_changed)
        self._loading = False
        self._slider_source = 0
        self.add(self._layout())
        self.connect("show", lambda *_: self.refresh())
        self.show_all()

    def _layout(self) -> Gtk.Widget:
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        outer.set_border_width(14)
        outer.set_size_request(430, -1)
        heading = Gtk.Label()
        heading.set_markup("<b>Control Center</b>")
        heading.set_xalign(0)
        outer.pack_start(heading, False, False, 0)
        outer.pack_start(self.error, False, False, 0)
        tiles = Gtk.Grid(column_spacing=8, row_spacing=8)
        tiles.attach(self.wifi_toggle, 0, 0, 1, 1)
        tiles.attach(self.bt_toggle, 1, 0, 1, 1)
        tiles.attach(self.airplane_toggle, 2, 0, 1, 1)
        outer.pack_start(tiles, False, False, 0)
        outer.pack_start(self._slider_row("audio-volume-high-symbolic", "Volume", self.volume_scale), False, False, 0)
        outer.pack_start(self._slider_row("display-brightness-symbolic", "Brightness", self.brightness_scale), False, False, 0)
        notebook = Gtk.Notebook()
        notebook.set_size_request(-1, 235)
        for listing, label in ((self.wifi_list, "Networks"), (self.bt_list, "Devices")):
            scroll = Gtk.ScrolledWindow()
            scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            scroll.add(listing)
            notebook.append_page(scroll, Gtk.Label(label=label))
        outer.pack_start(notebook, True, True, 0)
        actions = Gtk.Grid(column_spacing=8, row_spacing=8)
        action_data = [
            ("Screenshot", "camera-photo-symbolic", lambda *_: self._run(system.take_screenshot, self._show_result)),
            ("Record", "media-record-symbolic", self._record),
            ("Terminal", "utilities-terminal-symbolic", lambda *_: spawn(["lain-terminal"])),
            ("Settings", "emblem-system-symbolic", lambda *_: spawn(["lain-settings"])),
        ]
        for index, (label, icon, callback) in enumerate(action_data):
            button = Gtk.Button(label=label, image=icon_image(icon))
            if label == "Record":
                self.record_button = button
            button.set_always_show_image(True)
            button.connect("clicked", callback)
            actions.attach(button, index % 2, index // 2, 1, 1)
        outer.pack_start(actions, False, False, 0)
        return outer

    @staticmethod
    def _slider_row(icon: str, label: str, scale: Gtk.Scale) -> Gtk.Widget:
        row = Gtk.Box(spacing=9)
        row.pack_start(icon_image(icon), False, False, 0)
        text = Gtk.Label(label=label, width_chars=9, xalign=0)
        row.pack_start(text, False, False, 0)
        row.pack_start(scale, True, True, 0)
        return row

    def _run(self, function: Callable, callback: Callable | None = None) -> None:
        self.worker.submit(function, callback, lambda exc: self.error.show_error(str(exc)))

    def refresh(self) -> None:
        if self._loading:
            return
        self._loading = True
        self._set_sensitive(False)

        def collect():
            return {
                "wifi": system.wifi_enabled(),
                "bluetooth": system.bluetooth_enabled(),
                "airplane": system.airplane_enabled(),
                "volume": system.volume(),
                "brightness": system.brightness(),
                "recording": system.recording_active(),
                "networks": system.scan_wifi() if system.wifi_enabled() else [],
                "devices": system.scan_bluetooth(4) if system.bluetooth_enabled() else [],
            }

        self.worker.submit(collect, self._apply_state, self._refresh_error)

    def _set_sensitive(self, enabled: bool) -> None:
        self.wifi_toggle.set_sensitive(enabled)
        self.bt_toggle.set_sensitive(enabled)
        self.airplane_toggle.set_sensitive(enabled)

    def _apply_state(self, state: dict) -> bool:
        self.wifi_toggle.handler_block_by_func(self._toggle_wifi)
        self.bt_toggle.handler_block_by_func(self._toggle_bluetooth)
        self.airplane_toggle.handler_block_by_func(self._toggle_airplane)
        self.wifi_toggle.set_active(state["wifi"])
        self.bt_toggle.set_active(state["bluetooth"])
        self.airplane_toggle.set_active(state["airplane"])
        self.wifi_toggle.handler_unblock_by_func(self._toggle_wifi)
        self.bt_toggle.handler_unblock_by_func(self._toggle_bluetooth)
        self.airplane_toggle.handler_unblock_by_func(self._toggle_airplane)
        self.volume_scale.set_value(state["volume"])
        self.brightness_scale.set_value(state["brightness"])
        self.record_button.set_label("Stop recording" if state["recording"] else "Record")
        self._fill_wifi(state["networks"])
        self._fill_bluetooth(state["devices"])
        self._loading = False
        self._set_sensitive(True)
        return GLib.SOURCE_REMOVE

    def _refresh_error(self, exc: Exception) -> bool:
        self._loading = False
        self._set_sensitive(True)
        self.error.show_error(str(exc))
        return GLib.SOURCE_REMOVE

    def _clear_list(self, listing: Gtk.ListBox) -> None:
        for child in listing.get_children():
            listing.remove(child)

    def _fill_wifi(self, networks) -> None:
        self._clear_list(self.wifi_list)
        if not networks:
            self.wifi_list.add(Gtk.Label(label="No networks found", margin=15))
        for network in networks:
            row = Gtk.ListBoxRow()
            box = Gtk.Box(spacing=8, margin=8)
            box.pack_start(icon_image("network-wireless-signal-excellent-symbolic"), False, False, 0)
            label = Gtk.Label(label=network.ssid, xalign=0)
            label.set_tooltip_text(network.security)
            box.pack_start(label, True, True, 0)
            box.pack_start(Gtk.Label(label=f"{network.signal}%"), False, False, 0)
            action = text_button("Disconnect" if network.active else "Connect")
            action.connect("clicked", self._wifi_action, network)
            box.pack_start(action, False, False, 0)
            row.add(box)
            self.wifi_list.add(row)
        self.wifi_list.show_all()

    def _wifi_action(self, _button, network) -> None:
        if network.active:
            self._run(system.disconnect_wifi, lambda *_: self.refresh())
            return
        password = ""
        if network.security and network.security != "Open":
            dialog = Gtk.Dialog(title=f"Connect to {network.ssid}", transient_for=self.get_toplevel(), modal=True)
            dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
            dialog.add_button("Connect", Gtk.ResponseType.OK)
            entry = Gtk.Entry(visibility=False, input_purpose=Gtk.InputPurpose.PASSWORD)
            entry.set_activates_default(True)
            entry.set_placeholder_text("Password")
            entry.set_margin_top(12)
            entry.set_margin_bottom(12)
            entry.set_margin_start(12)
            entry.set_margin_end(12)
            dialog.get_content_area().add(entry)
            dialog.set_default_response(Gtk.ResponseType.OK)
            dialog.show_all()
            response = dialog.run()
            password = entry.get_text()
            dialog.destroy()
            if response != Gtk.ResponseType.OK:
                return
        self._run(lambda: system.connect_wifi(network.ssid, password), self._result_then_refresh)

    def _fill_bluetooth(self, devices) -> None:
        self._clear_list(self.bt_list)
        if not devices:
            self.bt_list.add(Gtk.Label(label="No devices found", margin=15))
        for device in devices:
            row = Gtk.ListBoxRow()
            box = Gtk.Box(spacing=8, margin=8)
            box.pack_start(icon_image("bluetooth-active-symbolic"), False, False, 0)
            box.pack_start(Gtk.Label(label=device.name, xalign=0), True, True, 0)
            state = "Connected" if device.connected else "Paired" if device.paired else "Available"
            box.pack_start(Gtk.Label(label=state), False, False, 0)
            action = text_button("Disconnect" if device.connected else "Connect")
            function = (lambda address=device.address: system.disconnect_bluetooth(address)) if device.connected else (lambda address=device.address: system.connect_bluetooth(address))
            action.connect("clicked", lambda _button, fn=function: self._run(fn, self._result_then_refresh))
            box.pack_start(action, False, False, 0)
            row.add(box)
            self.bt_list.add(row)
        self.bt_list.show_all()

    def _result_then_refresh(self, result) -> bool:
        if not result.ok:
            self.error.show_error(result.stderr)
        self.refresh()
        return GLib.SOURCE_REMOVE

    def _show_result(self, result) -> bool:
        if not result.ok:
            self.error.show_error(result.stderr)
        return GLib.SOURCE_REMOVE

    def _toggle_wifi(self, button) -> None:
        if not self._loading:
            self._run(lambda: system.set_wifi(button.get_active()), self._result_then_refresh)

    def _toggle_bluetooth(self, button) -> None:
        if not self._loading:
            self._run(lambda: system.set_bluetooth(button.get_active()), self._result_then_refresh)

    def _toggle_airplane(self, button) -> None:
        if not self._loading:
            self._run(lambda: system.set_airplane(button.get_active()), self._result_then_refresh)

    def _volume_changed(self, scale) -> None:
        self._debounce_slider(lambda: system.set_volume(scale.get_value()))

    def _brightness_changed(self, scale) -> None:
        self._debounce_slider(lambda: system.set_brightness(scale.get_value()))

    def _debounce_slider(self, callback: Callable) -> None:
        if self._loading:
            return
        if self._slider_source:
            GLib.source_remove(self._slider_source)
        self._slider_source = GLib.timeout_add(120, self._apply_slider, callback)

    def _apply_slider(self, callback: Callable) -> bool:
        self._slider_source = 0
        self._run(callback, self._show_result)
        return GLib.SOURCE_REMOVE

    def _record(self, *_):
        self._run(system.stop_recording if system.recording_active() else system.start_recording, self._result_then_refresh)


class NotificationPopover(ManagedPopover):
    def __init__(self, relative_to: Gtk.Widget, store: NotificationStore,
                 changed: Callable[[], None], invoke_action: Callable[[int, str], None],
                 clear_all: Callable[[], None]):
        super().__init__(relative_to)
        self.store = store
        self.changed = changed
        self.invoke_action = invoke_action
        self.clear_all = clear_all
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_border_width(12)
        header = Gtk.Box(spacing=8)
        title = Gtk.Label()
        title.set_markup("<b>Notifications</b>")
        title.set_xalign(0)
        header.pack_start(title, True, True, 0)
        header.pack_start(text_button("Clear all", self._clear), False, False, 0)
        outer.pack_start(header, False, False, 0)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_size_request(390, 430)
        self.listing = Gtk.ListBox()
        self.listing.set_selection_mode(Gtk.SelectionMode.NONE)
        scroll.add(self.listing)
        outer.pack_start(scroll, True, True, 0)
        self.add(outer)
        self.connect("show", self._shown)
        self.refresh()

    def _shown(self, *_):
        self.store.mark_read()
        self.changed()

    def refresh(self) -> None:
        for child in self.listing.get_children():
            self.listing.remove(child)
        if not self.store.items:
            self.listing.add(Gtk.Label(label="You're all caught up", margin=30))
        for notice in reversed(self.store.items):
            row = Gtk.ListBoxRow()
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, margin=10)
            header = Gtk.Box(spacing=8)
            header.pack_start(icon_image(notice.app_icon or "dialog-information-symbolic"), False, False, 0)
            summary = Gtk.Label(xalign=0)
            summary.set_markup(f"<b>{html.escape(notice.summary)}</b>")
            summary.set_ellipsize(Pango.EllipsizeMode.END)
            header.pack_start(summary, True, True, 0)
            header.pack_start(Gtk.Label(label=time.strftime("%H:%M", time.localtime(notice.created))), False, False, 0)
            box.pack_start(header, False, False, 0)
            body = Gtk.Label(label=notice.body, xalign=0)
            body.set_line_wrap(True)
            body.set_max_width_chars(46)
            box.pack_start(body, False, False, 0)
            if notice.actions:
                actions = Gtk.Box(spacing=6)
                for key, label in zip(notice.actions[0::2], notice.actions[1::2]):
                    action = text_button(label)
                    action.connect(
                        "clicked",
                        lambda _button, nid=notice.id, action_key=key: self.invoke_action(nid, action_key),
                    )
                    actions.pack_start(action, False, False, 0)
                box.pack_start(actions, False, False, 0)
            row.add(box)
            self.listing.add(row)
        self.show_all()

    def _clear(self, *_):
        self.clear_all()


class PowerPopover(ManagedPopover):
    def __init__(self, relative_to: Gtk.Widget):
        super().__init__(relative_to)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5, margin=8)
        commands = [
            ("Lock", "system-lock-screen-symbolic", ["lain-lock"]),
            ("Log out", "system-log-out-symbolic", ["xfce4-session-logout", "--logout"]),
            ("Suspend", "media-playback-pause-symbolic", ["systemctl", "suspend"]),
            ("Restart", "system-reboot-symbolic", ["systemctl", "reboot"]),
            ("Shut down", "system-shutdown-symbolic", ["systemctl", "poweroff"]),
        ]
        for label, icon, command in commands:
            button = Gtk.Button(label=label, image=icon_image(icon))
            button.set_always_show_image(True)
            button.set_alignment(0.0, 0.5)
            button.connect("clicked", lambda _button, cmd=command: spawn(cmd))
            box.pack_start(button, False, False, 0)
        self.add(box)
        self.show_all()


class ToastWindow(Gtk.Window):
    def __init__(self, monitor: Monitor, panel_height: int):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.monitor = monitor
        self.panel_height = panel_height
        self.set_name("lain-toast")
        self.set_type_hint(Gdk.WindowTypeHint.NOTIFICATION)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_accept_focus(False)
        self.set_default_size(360, -1)
        self.content = Gtk.Box(spacing=10, margin=12)
        self.add(self.content)
        self.hide_source = 0
        self.connect("button-press-event", lambda *_: self.hide())

    def show_notice(self, notice, expire_timeout: int) -> None:
        for child in self.content.get_children():
            self.content.remove(child)
        self.content.pack_start(icon_image(notice.app_icon or "dialog-information-symbolic", 28), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        summary = Gtk.Label(xalign=0)
        summary.set_markup(f"<b>{html.escape(notice.summary)}</b>")
        summary.set_ellipsize(Pango.EllipsizeMode.END)
        body = Gtk.Label(label=notice.body, xalign=0)
        body.set_line_wrap(True)
        body.set_max_width_chars(42)
        text.pack_start(summary, False, False, 0)
        if notice.body:
            text.pack_start(body, False, False, 0)
        self.content.pack_start(text, True, True, 0)
        self.show_all()
        _minimum, natural = self.get_preferred_size()
        width = max(360, natural.width)
        self.move(
            self.monitor.x + self.monitor.width - width - 14,
            self.monitor.y + self.panel_height + 12,
        )
        if self.hide_source:
            GLib.source_remove(self.hide_source)
        duration = 5000 if expire_timeout <= 0 else max(1200, min(15000, expire_timeout))
        self.hide_source = GLib.timeout_add(duration, self._hide)

    def _hide(self) -> bool:
        self.hide_source = 0
        self.hide()
        return GLib.SOURCE_REMOVE


class PanelWindow(Gtk.Window):
    def __init__(self, shell, monitor: Monitor):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.shell = shell
        self.monitor = monitor
        self.edge_margin = 5
        self.set_title("LAINTheme Top Panel")
        self.set_name("lain-top-panel")
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.stick()
        self.set_default_size(monitor.width - self.edge_margin * 2, shell.config.panel_height)
        self.move(monitor.x + self.edge_margin, monitor.y + self.edge_margin)
        overlay = Gtk.Overlay()
        left_right = Gtk.Box(spacing=8)
        left_right.set_margin_start(8)
        left_right.set_margin_end(8)
        self.left = Gtk.Box(spacing=4)
        self.right = Gtk.Box(spacing=4)
        left_right.pack_start(self.left, False, False, 0)
        left_right.pack_end(self.right, False, False, 0)
        overlay.add(left_right)
        self.clock = Gtk.Label()
        self.clock.set_halign(Gtk.Align.CENTER)
        self.clock.set_valign(Gtk.Align.CENTER)
        self.clock.set_sensitive(False)
        self.clock.get_style_context().add_class("clock")
        overlay.add_overlay(self.clock)
        overlay.set_overlay_pass_through(self.clock, True)
        self.add(overlay)
        self._build_left()
        self._build_right()
        self.connect("realize", self._realized)
        self.show_all()

    def _build_left(self):
        distro = icon_button(
            "distributor-logo", "System Settings",
            lambda *_: spawn(["xfce4-settings-manager"]),
        )
        self.left.pack_start(distro, False, False, 0)
        apps_button = text_button("Applications", css_class="applications-button")
        self.launcher = LauncherPopover(apps_button, self.shell.apps, self.shell.config, self.shell.pinned_changed)
        apps_button.connect("clicked", lambda *_: self.launcher.toggle())
        self.left.pack_start(apps_button, False, False, 0)
        separator = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        self.left.pack_start(separator, False, False, 4)
        self.workspace_box = Gtk.Box(spacing=1)
        self.workspace_buttons = []
        for index in range(self.shell.config.workspaces):
            button = Gtk.Button(label=str(index + 1))
            button.set_tooltip_text(f"Desktop {index + 1}")
            button.get_style_context().add_class("workspace-button")
            button.connect("clicked", lambda _button, target=index: x11.switch_workspace(target))
            self.workspace_box.pack_start(button, False, False, 0)
            self.workspace_buttons.append(button)
        self.left.pack_start(self.workspace_box, False, False, 0)
        self.workspace_label = Gtk.Label(label="Desktop 1")
        self.workspace_label.get_style_context().add_class("workspace-label")
        self.left.pack_start(self.workspace_label, False, False, 4)
        self.metrics_label = Gtk.Label(label="CPU --  RAM --  DISK --")
        self.metrics_label.get_style_context().add_class("metrics")
        self.left.pack_start(self.metrics_label, False, False, 6)

    def _build_right(self):
        self.status_button = Gtk.Button()
        status_box = Gtk.Box(spacing=8)
        self.wifi_icon = icon_image("network-wireless-offline-symbolic")
        self.bt_icon = icon_image("bluetooth-disabled-symbolic")
        self.battery_label = Gtk.Label(label="--")
        status_box.pack_start(self.wifi_icon, False, False, 0)
        status_box.pack_start(self.bt_icon, False, False, 0)
        status_box.pack_start(self.battery_label, False, False, 0)
        self.status_button.add(status_box)
        self.status_button.get_style_context().add_class("status-cluster")
        self.status_control = ControlCenterPopover(self.status_button, self.shell.worker)
        self.status_button.connect("clicked", lambda *_: self.status_control.toggle())
        self.right.pack_start(self.status_button, False, False, 0)
        self.notify_button = icon_button("notification-symbolic", "Notifications")
        self.notify_badge = Gtk.Label()
        notify_overlay = Gtk.Overlay()
        notify_overlay.add(self.notify_button)
        self.notify_badge.set_halign(Gtk.Align.END)
        self.notify_badge.set_valign(Gtk.Align.START)
        self.notify_badge.get_style_context().add_class("notification-badge")
        notify_overlay.add_overlay(self.notify_badge)
        notifications = NotificationPopover(
            self.notify_button,
            self.shell.notification_store,
            self.shell.notifications_changed,
            self.shell.notification_server.invoke_action,
            self.shell.notification_server.dismiss_all,
        )
        self.notify_button.connect("clicked", lambda *_: (notifications.refresh(), notifications.toggle()))
        self.notification_popover = notifications
        self.right.pack_start(notify_overlay, False, False, 0)
        cc_button = icon_button("emblem-system-symbolic", "Control Center")
        self.control_center = ControlCenterPopover(cc_button, self.shell.worker)
        cc_button.connect("clicked", lambda *_: self.control_center.toggle())
        self.right.pack_start(cc_button, False, False, 0)
        power_button = icon_button("system-shutdown-symbolic", "Power")
        self.power_menu = PowerPopover(power_button)
        power_button.connect("clicked", lambda *_: self.power_menu.toggle())
        self.right.pack_start(power_button, False, False, 0)

    def _realized(self, *_):
        self.move(self.monitor.x + self.edge_margin, self.monitor.y + self.edge_margin)
        x11.set_strut(
            self.get_window(), self.monitor,
            top=self.shell.config.panel_height + self.edge_margin,
        )

    def update_clock(self) -> None:
        self.clock.set_markup(time.strftime("<b>%H:%M</b>  %a %d %b"))

    def update_workspace(self, active: int) -> None:
        self.workspace_label.set_text(f"Desktop {active + 1}")
        for index, button in enumerate(self.workspace_buttons):
            context = button.get_style_context()
            if index == active:
                context.add_class("active")
            else:
                context.remove_class("active")

    def update_metrics(self, value: system.Metrics, wifi: bool, bluetooth: bool) -> None:
        self.metrics_label.set_text(f"CPU {value.cpu_percent:02}%  RAM {value.memory_percent:02}%  DISK {value.disk_percent:02}%")
        self.wifi_icon.set_from_icon_name("network-wireless-signal-excellent-symbolic" if wifi else "network-wireless-offline-symbolic", Gtk.IconSize.BUTTON)
        self.bt_icon.set_from_icon_name("bluetooth-active-symbolic" if bluetooth else "bluetooth-disabled-symbolic", Gtk.IconSize.BUTTON)
        battery = "AC" if value.battery_percent is None else f"{value.battery_percent}%{'+' if value.charging else ''}"
        self.battery_label.set_text(battery)

    def update_notifications(self, count: int) -> None:
        self.notify_badge.set_text(str(min(count, 99)) if count else "")


class DockWindow(Gtk.Window):
    TARGETS = [Gtk.TargetEntry.new("application/x-lain-desktop-id", Gtk.TargetFlags.SAME_APP, 0)]

    def __init__(self, shell, monitor: Monitor):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.shell = shell
        self.monitor = monitor
        self.set_title("LAINTheme Dock")
        self.set_name("lain-dock")
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.stick()
        self.box = Gtk.Box(spacing=5, margin=5)
        self.add(self.box)
        self.drag_dest_set(Gtk.DestDefaults.ALL, self.TARGETS, Gdk.DragAction.COPY)
        self.connect("drag-data-received", self._drop)
        self.connect("enter-notify-event", lambda *_: self.show_dock())
        self.connect("leave-notify-event", self._left)
        self.fingerprint = None
        self.hidden = False
        self._hide_source = 0
        self.show_all()
        GLib.idle_add(self._position)

    def _position(self) -> bool:
        width = max(54, self.box.get_preferred_width()[1])
        height = self.shell.config.dock_height
        self.resize(width, height)
        x = self.monitor.x + (self.monitor.width - width) // 2
        y = self.monitor.y + self.monitor.height - (3 if self.hidden else height + 5)
        self.move(x, y)
        if self.get_realized():
            x11.clear_strut(self.get_window())
        return GLib.SOURCE_REMOVE

    def update(self, groups: list[AppGroup]) -> None:
        fingerprint = tuple((group.key, group.pinned, group.active, group.urgent, tuple(w.xid for w in group.windows)) for group in groups)
        if fingerprint == self.fingerprint:
            return
        self.fingerprint = fingerprint
        for child in self.box.get_children():
            self.box.remove(child)
        for group in groups:
            self.box.pack_start(self._group_button(group), False, False, 0)
        self.box.show_all()
        GLib.idle_add(self._position)

    def _group_button(self, group: AppGroup) -> Gtk.Button:
        button = Gtk.Button()
        button.desktop_id = group.desktop_id
        button.add(icon_image(group.icon, 48))
        button.set_tooltip_text(group.name + (f" · {len(group.windows)} windows" if group.windows else ""))
        context = button.get_style_context()
        context.add_class("dock-app")
        if group.active:
            context.add_class("active")
        if group.urgent:
            context.add_class("urgent")
        button.connect("clicked", self._activate, group)
        button.connect("button-press-event", self._menu, group)
        if group.desktop_id:
            button.drag_source_set(Gdk.ModifierType.BUTTON1_MASK, self.TARGETS, Gdk.DragAction.COPY)
            button.connect("drag-data-get", self._drag_data, group.desktop_id)
        return button

    @staticmethod
    def _drag_data(_widget, _context, selection, _info, _time, desktop_id: str) -> None:
        selection.set_text(desktop_id, -1)

    def _activate(self, _button, group: AppGroup) -> None:
        if group.windows:
            active = next((window for window in group.windows if window.active), None)
            if active and len(group.windows) == 1:
                run(["xdotool", "windowminimize", str(active.xid)], timeout=2)
            else:
                target = next((window for window in group.windows if not window.active), group.windows[0])
                x11.activate_window(target.xid)
        elif group.desktop_id in self.shell.apps:
            self.shell.apps[group.desktop_id].launch()

    def _menu(self, _button, event, group: AppGroup):
        if event.button != 3:
            return False
        menu = Gtk.Menu()
        if group.windows:
            for window in group.windows:
                item = Gtk.MenuItem(label=f"Close: {window.title[:40]}")
                item.connect("activate", lambda _item, xid=window.xid: x11.close_window(xid))
                menu.append(item)
        if group.desktop_id:
            pinned = group.desktop_id in self.shell.config.pinned
            item = Gtk.MenuItem(label="Unpin from Dock" if pinned else "Pin to Dock")
            item.connect("activate", lambda *_: self.shell.toggle_pin(group.desktop_id))
            menu.append(item)
        menu.show_all()
        menu.popup_at_pointer(event)
        return True

    def _drop(self, _widget, _context, x, _y, selection, _info, _time) -> None:
        desktop_id = selection.get_text()
        if not desktop_id or desktop_id not in self.shell.apps:
            return
        pinned = self.shell.config.pinned
        if desktop_id in pinned:
            pinned.remove(desktop_id)
        insert_at = len(pinned)
        pinned_index = 0
        for child in self.box.get_children():
            child_id = getattr(child, "desktop_id", None)
            if not child_id or child_id == desktop_id or child_id not in pinned:
                continue
            allocation = child.get_allocation()
            if x < allocation.x + allocation.width // 2:
                insert_at = pinned_index
                break
            pinned_index += 1
        pinned.insert(insert_at, desktop_id)
        self.shell.config.save()
        self.shell.pinned_changed()

    def apply_intellihide(self, hide: bool) -> None:
        if not self.shell.config.dock_autohide:
            hide = False
        if hide and not self.hidden:
            if self._hide_source:
                GLib.source_remove(self._hide_source)
            self._hide_source = GLib.timeout_add(self.shell.profile.dock_hide_delay_ms, self._hide_now)
        elif not hide:
            if self._hide_source:
                GLib.source_remove(self._hide_source)
                self._hide_source = 0
            self.show_dock()

    def _hide_now(self) -> bool:
        self._hide_source = 0
        self.hidden = True
        self._position()
        return GLib.SOURCE_REMOVE

    def show_dock(self) -> None:
        self.hidden = False
        self._position()

    def _left(self, *_):
        if self.shell.config.dock_autohide and self.shell.dock_should_hide(self.monitor):
            self.apply_intellihide(True)
        return False


CSS = b"""
@define-color bg rgba(10, 12, 20, .94);
@define-color bg2 rgba(22, 25, 39, .96);
@define-color fg #e8eaf2;
@define-color muted #8b91a7;
@define-color accent #8c7bff;
@define-color cyan #59d7e5;
* { font-family: "JetBrains Mono", "Noto Sans", sans-serif; }
#lain-top-panel, #lain-dock, #lain-toast { background: @bg; color: @fg; border: 1px solid rgba(255,255,255,.09); }
#lain-top-panel { border-radius: 11px; }
#lain-dock { border-radius: 16px; }
#lain-toast { border-radius: 13px; }
button { color: @fg; background: transparent; border: 0; box-shadow: none; text-shadow: none; }
button:hover { background: rgba(255,255,255,.09); }
.icon-button, .text-button, .applications-button, .status-cluster { min-height: 26px; border-radius: 8px; padding: 1px 8px; }
.applications-button { color: @cyan; font-weight: bold; }
.workspace-button { min-width: 17px; min-height: 17px; padding: 0; margin: 5px 0; border-radius: 10px; color: @muted; font-size: 0; background: rgba(255,255,255,.12); }
.workspace-button.active { min-width: 28px; background: @accent; }
.workspace-label, .metrics { color: @muted; font-size: 10px; }
.clock { font-size: 12px; }
.notification-badge { min-width: 14px; min-height: 14px; border-radius: 8px; background: #ef5f7a; color: white; font-size: 8px; font-weight: bold; }
.lain-popover contents { background: @bg2; color: @fg; border: 1px solid rgba(255,255,255,.12); border-radius: 13px; }
.quick-tile { min-width: 115px; min-height: 50px; border-radius: 11px; background: rgba(255,255,255,.07); }
.quick-tile:checked { background: @accent; color: white; }
.error-banner { color: #ff9aaa; background: rgba(239,95,122,.15); border-radius: 8px; padding: 7px; }
.app-button { border-radius: 11px; }
.dock-app { min-width: 62px; min-height: 62px; border-radius: 17px; }
.dock-app.active { background: rgba(140,123,255,.2); border-bottom: 3px solid @accent; }
.dock-app.urgent { background: rgba(239,95,122,.25); }
scale trough { background: rgba(255,255,255,.12); border-radius: 5px; min-height: 5px; }
scale highlight { background: @accent; border-radius: 5px; }
"""


def install_css() -> None:
    provider = Gtk.CssProvider()
    override = ASSET_DIR / "shell.css"
    if override.exists():
        provider.load_from_path(str(override))
    else:
        provider.load_from_data(CSS)
    screen = Gdk.Screen.get_default()
    Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

from __future__ import annotations

import os
import signal
import sys
from pathlib import Path

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402

from . import x11
from .bluez_agent import BluezAgent
from .config import APP_ID, Profile, UserConfig, ensure_runtime_dirs
from .desktop import app_metadata, load_apps
from .models import Monitor, Window, group_windows, overlaps
from .notifications import NotificationServer, NotificationStore
from .system import bluetooth_enabled, metrics, wifi_enabled
from .ui import AsyncWorker, DockWindow, PanelWindow, ToastWindow, install_css


class WorkspaceOSD(Gtk.Window):
    def __init__(self, profile: Profile):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.profile = profile
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_accept_focus(False)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.label = Gtk.Label()
        self.label.set_margin_top(18)
        self.label.set_margin_bottom(18)
        self.label.set_margin_start(30)
        self.label.set_margin_end(30)
        self.label.get_style_context().add_class("clock")
        self.add(self.label)
        self.hide_source = 0

    def display(self, workspace: int) -> None:
        self.label.set_markup(f"<b>Desktop {workspace + 1}</b>")
        self.show_all()
        if self.hide_source:
            GLib.source_remove(self.hide_source)
        delay = 800 if self.profile.name == "high" else 450
        self.hide_source = GLib.timeout_add(delay, self._hide)

    def _hide(self) -> bool:
        self.hide_source = 0
        self.hide()
        return GLib.SOURCE_REMOVE


class Shell(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        ensure_runtime_dirs()
        self.profile = Profile.load()
        self.config = UserConfig.load()
        self.apps = load_apps()
        self.worker = AsyncWorker()
        self.notification_store = NotificationStore()
        self.notification_server = NotificationServer(self.notification_store, self._notification_from_thread)
        self.bluez_agent = BluezAgent(lambda: self.panels[0] if self.panels else None)
        self.panels: list[PanelWindow] = []
        self.docks: list[DockWindow] = []
        self.windows: list[Window] = []
        self.last_workspace = -1
        self.last_status = None
        self.refreshing_windows = False
        self.refreshing_status = False
        self.osd = None
        self.toast = None
        self.connect("activate", self._activate)
        self.connect("shutdown", self._shutdown)

    def do_command_line(self, command_line):
        arguments = command_line.get_arguments()[1:]
        self.activate()
        if "--launcher" in arguments:
            GLib.idle_add(self.show_launcher)
        return 0

    def show_launcher(self) -> bool:
        if self.panels:
            self.panels[0].launcher.toggle()
        return GLib.SOURCE_REMOVE

    def _activate(self, *_):
        if self.panels:
            return
        install_css()
        self.osd = WorkspaceOSD(self.profile)
        monitors = self._monitors()
        if not monitors:
            self.quit()
            return
        for monitor in monitors:
            panel = PanelWindow(self, monitor)
            panel.set_application(self)
            self.panels.append(panel)
            dock = DockWindow(self, monitor)
            dock.set_application(self)
            self.docks.append(dock)
        primary = next((monitor for monitor in monitors if monitor.primary), monitors[0])
        self.toast = ToastWindow(primary, self.config.panel_height)
        self.notification_server.start()
        self.bluez_agent.start()
        self.notifications_changed()
        self._tick_clock()
        self._tick_workspace()
        self._tick_windows()
        self._tick_status()

    @staticmethod
    def _monitors() -> list[Monitor]:
        display = Gdk.Display.get_default()
        primary = display.get_primary_monitor() if display else None
        output: list[Monitor] = []
        if not display:
            return output
        for index in range(display.get_n_monitors()):
            item = display.get_monitor(index)
            geometry = item.get_geometry()
            output.append(Monitor(
                index, geometry.x, geometry.y,
                geometry.width, geometry.height,
                item == primary,
            ))
        return output

    def _tick_clock(self) -> bool:
        for panel in self.panels:
            panel.update_clock()
        GLib.timeout_add(1000, self._tick_clock)
        return GLib.SOURCE_REMOVE

    def _tick_workspace(self) -> bool:
        workspace = x11.active_workspace()
        if workspace != self.last_workspace:
            if self.last_workspace >= 0 and self.osd:
                self.osd.display(workspace)
            self.last_workspace = workspace
            for panel in self.panels:
                panel.update_workspace(workspace)
        GLib.timeout_add(350, self._tick_workspace)
        return GLib.SOURCE_REMOVE

    def _tick_windows(self) -> bool:
        if not self.refreshing_windows:
            self.refreshing_windows = True
            self.worker.submit(x11.list_windows, self._apply_windows, self._window_error)
        GLib.timeout_add(self.profile.poll_ms, self._tick_windows)
        return GLib.SOURCE_REMOVE

    def _window_error(self, _exc) -> bool:
        self.refreshing_windows = False
        return GLib.SOURCE_REMOVE

    def _apply_windows(self, windows: list[Window]) -> bool:
        self.refreshing_windows = False
        self.windows = windows
        metadata = app_metadata(self.apps)
        for dock in self.docks:
            visible = [window for window in windows if self._window_on_monitor(window, dock.monitor)]
            dock.update(group_windows(visible, self.config.pinned, metadata))
            dock.apply_intellihide(any(
                overlaps(window, dock.monitor, self.config.panel_height, self.config.dock_height)
                and (window.fullscreen or window.maximized or window.active)
                for window in visible
            ))
        return GLib.SOURCE_REMOVE

    @staticmethod
    def _window_on_monitor(window: Window, monitor: Monitor) -> bool:
        if window.geometry is None:
            return monitor.primary
        x, y, width, height = window.geometry
        center_x = x + width // 2
        center_y = y + height // 2
        return (
            monitor.x <= center_x < monitor.x + monitor.width
            and monitor.y <= center_y < monitor.y + monitor.height
        )

    def dock_should_hide(self, monitor: Monitor) -> bool:
        return any(
            self._window_on_monitor(window, monitor)
            and overlaps(window, monitor, self.config.panel_height, self.config.dock_height)
            and (window.fullscreen or window.maximized or window.active)
            for window in self.windows
        )

    def _tick_status(self) -> bool:
        if not self.refreshing_status:
            self.refreshing_status = True

            def collect():
                return metrics(), wifi_enabled(), bluetooth_enabled()

            self.worker.submit(collect, self._apply_status, self._status_error)
        GLib.timeout_add(3000, self._tick_status)
        return GLib.SOURCE_REMOVE

    def _status_error(self, _exc) -> bool:
        self.refreshing_status = False
        return GLib.SOURCE_REMOVE

    def _apply_status(self, state) -> bool:
        self.refreshing_status = False
        self.last_status = state
        for panel in self.panels:
            panel.update_metrics(*state)
        return GLib.SOURCE_REMOVE

    def pinned_changed(self) -> None:
        self._apply_windows(self.windows)

    def toggle_pin(self, desktop_id: str) -> None:
        if desktop_id in self.config.pinned:
            self.config.pinned.remove(desktop_id)
        else:
            self.config.pinned.append(desktop_id)
        self.config.save()
        self.pinned_changed()

    def _notification_from_thread(self, notice, expire_timeout: int) -> None:
        GLib.idle_add(self._apply_notification, notice, expire_timeout)

    def _apply_notification(self, notice, expire_timeout: int) -> bool:
        self.notifications_changed()
        if notice is not None and self.toast is not None:
            self.toast.show_notice(notice, expire_timeout)
        return GLib.SOURCE_REMOVE

    def notifications_changed(self) -> bool:
        count = self.notification_store.unread_count
        for panel in self.panels:
            panel.update_notifications(count)
            panel.notification_popover.refresh()
        return GLib.SOURCE_REMOVE

    def _shutdown(self, *_):
        self.bluez_agent.stop()
        self.notification_server.stop()
        self.worker.shutdown()


def main(argv: list[str] | None = None) -> int:
    if os.environ.get("XDG_SESSION_TYPE", "x11").lower() != "x11":
        print("LAINTheme Shell requires an XFCE X11 session.", file=sys.stderr)
        return 2
    if not os.environ.get("DISPLAY"):
        print("LAINTheme Shell: no active X11 display; exiting without restart.", file=sys.stderr)
        return 0
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    return Shell().run(argv or sys.argv)

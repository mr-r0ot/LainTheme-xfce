#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo '[1/8] Bash syntax'
bash -n laintheme_install.sh bin/lain-window bin/lain-wifi bin/lain-capture

echo '[2/8] Python syntax'
python3 -m py_compile bin/laintheme bin/lain-shell bin/lain-lock bin/lain-notifyd bin/lain-window
rm -rf bin/__pycache__

echo '[3/8] Zsh syntax'
if command -v zsh >/dev/null 2>&1; then zsh -n zsh/.zshrc zsh/.zshrc-high; fi

echo '[4/8] Help parser'
bash laintheme_install.sh --help >/tmp/laintheme-help.txt
grep -q -- '--lite|--high' /tmp/laintheme-help.txt

echo '[5/8] Regression: old unbound positional-argument bug absent'
! grep -q 'set -- \$spec' laintheme_install.sh

echo '[6/8] Regression: destructive panel guard absent'
! grep -q 'panel-guard' laintheme_install.sh
! grep -q 'sleep 2; xfce4-panel --quit' laintheme_install.sh

echo '[7/8] Required independent theme installers are hard failures'
grep -q 'WhiteSur GTK installation failed' laintheme_install.sh
grep -q 'WhiteSur icon installation failed' laintheme_install.sh
grep -q 'WhiteSur cursor build/install failed' laintheme_install.sh

echo '[8/8] Profile branching is set -e safe'
grep -q 'if \[\[ "\$MODE" == high \]\]; then PKGS+=(picom mesa-utils); fi' laintheme_install.sh

echo 'STATIC CHECKS: PASS'

export PATH="$HOME/.local/bin:$PATH"
export EDITOR=${EDITOR:-nano}; HISTSIZE=10000; SAVEHIST=10000; setopt HIST_IGNORE_DUPS SHARE_HISTORY AUTO_CD
PROMPT='%F{141}%n%f@%F{109}%m%f %F{245}%~%f'
_lain_git(){ git rev-parse --is-inside-work-tree >/dev/null 2>&1 || return; local b=$(git branch --show-current 2>/dev/null); local d=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' '); [[ -z $b ]] && b='detached'; print -r -- "%F{109}[$b${${d:+:$d}}]%f" }
_lain_preexec(){ _LAIN_START=$EPOCHREALTIME; }
_lain_precmd(){ local s=$?;local d=0;[[ -n $_LAIN_START ]]&&d=$(printf '%.2fs' $((EPOCHREALTIME-_LAIN_START)));PROMPT="%F{141}%n%f@%F{109}%m%f %F{245}%~%f $(_lain_git) %(?..%F{203}[%?]%f )%F{245}${d}%f $ ";return $s;}
precmd_functions+=(_lain_precmd);preexec_functions+=(_lain_preexec)
alias ll='ls -lah --color=auto';alias la='ls -A --color=auto';alias c='clear';alias lainconfig='laintheme';alias lltheme='laintheme';alias logout='command -v canberra-gtk-play >/dev/null 2>&1&&canberra-gtk-play -i desktop-logout >/dev/null 2>&1||true;xfce4-session-logout --logout'
[[ -f "$HOME/.zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh" ]]&&source "$HOME/.zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh";[[ -f "$HOME/.zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh" ]]&&source "$HOME/.zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh"

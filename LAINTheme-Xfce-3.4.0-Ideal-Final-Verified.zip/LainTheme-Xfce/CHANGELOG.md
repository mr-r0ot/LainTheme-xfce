# Changelog

## 3.2.0

- Removed the custom lower GTK dock; Plank is now the only bottom dock.
- Restored XFWM4 titlebar controls and applied the correct XFWM4 theme channel.
- Replaced panel-confined GTK popovers with root-positioned popup windows.
- Preserved user-editable assets under `~/Pictures/LAINTheme` and Plank dconf in rollback.

## 3.3.0

- Eww is now the primary Top Bar with independent control, notification and power windows.
- sxhkd owns launcher, workspace, terminal, clipboard and lock shortcuts.
- Added Dunst, Rofi, Kitty, CopyQ, Blueman, btop and feh/swww integration.

## 3.1.0

- Fixed top-panel popovers being confined to panel height and first-click no-op behavior.
- Kept strong popover references and passed pointer events through the centered clock overlay.
- Applied the exact 2.6 `LAINTheme-Dark`, `Papirus-Dark`, JetBrains Mono and terminal-art visual stack.
- Enlarged theme icons to 48px and Dock targets to 62px/78px.
- Replaced rather than appended `.zshrc`; Oh My Zsh is private to the project and rollback restores the prior file.
- Added explicit LightDM GTK Greeter seat selection, system theme installation and complete system rollback.
- Made LightDM the real lock UI through `dm-tool lock`, with core i3lock fallback.
- Added precise 2.x autostart/process migration and PID-owned Picom lifecycle control.
- Added a fake-root LightDM install/uninstall integration test.

## 3.0.0

- Replaced the incremental 2.x panel implementation with a data-model-driven GTK3 shell.
- Added monitor-local top panels, EWMH partial struts and overlay-centered clocks.
- Replaced periodic Dock rebuilds with stable grouped application state.
- Added Launcher drag-and-drop, application pinning and `Super+Z` integration.
- Added asynchronous NetworkManager, BlueZ, audio, brightness, screenshot and recording backends.
- Added BlueZ PIN/passkey/confirmation agent support.
- Added a Freedesktop Notifications 1.3 service with actions and persistent history.
- Added secure i3lock and reversible LightDM GTK Greeter integration.
- Added deterministic desktop, lock and terminal assets plus a minimal sound theme.
- Added Lite/High compositor separation and Picom crash fallback.
- Added transactional install, update, repair, uninstall and original-state preservation.
- Added unit, contract, asset and isolated install/rollback tests.
## 3.4.0

- Replaced the unreliable Eww startup path with an X11 readiness gate, daemon
  ping, parser reload gate, active-window verification, persistent log, and
  explicit failure (no hidden GTK fallback).
- Corrected Eww 0.6 command ordering and `active-windows` API; removed invalid
  `calc(...)` geometry and unsupported popup window type.
- Added deterministic `lain-workspace` switching/moving using wmctrl and
  xdotool, plus status/action helpers for all Top Bar controls.
- Debian installs build pinned official Eww v0.6.0 with the X11 feature when no
  distro package exists; Arch uses its packaged Eww.
- Preserved dark XFCE theme, Papirus-Dark icons, JetBrains Mono sizes, and
  Plank-only dock behavior.
